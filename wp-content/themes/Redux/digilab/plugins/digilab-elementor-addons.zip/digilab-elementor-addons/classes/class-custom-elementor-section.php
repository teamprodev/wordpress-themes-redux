<?php

if( !defined( 'ABSPATH' ) ) exit;

use Elementor\Utils;
use Elementor\Repeater;
use Elementor\Element_Base;
use Elementor\Elementor_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Responsive\Responsive;
use Elementor\Widget_Base;
use Elementor\Group_Control_Background;
use \Elementor\Group_Control_Border;

class Digilab_Section_Parallax {

    private static $instance = null;

    public function __construct(){
        // section register settings
        add_action('elementor/element/section/section_structure/after_section_end',array($this,'register_change_section_structure'), 10 );
        add_action('elementor/element/section/section_structure/after_section_end',array($this,'section_parallax_controls'), 10 );
        add_action('elementor/element/section/section_structure/after_section_end',array($this,'digilab_add_particle_effect_to_section'), 10 );
        add_action('elementor/element/section/section_structure/after_section_end',array($this,'digilab_add_vegas_slider_to_section'), 10 );
        add_action('elementor/element/section/section_layout/before_section_end',array($this,'register_change_section_indent_structure'), 10 );
        add_action('elementor/element/section/section_background_overlay/before_section_end',array($this,'register_add_section_overlay_width'), 10 );
        add_action('elementor/frontend/section/before_render',array($this,'digilab_custom_attr_to_section'), 10);
        //add_action('elementor/frontend/section/before_render',array($this,'before_render'), 10);

        // column register settings and before render column functions
        add_action('elementor/element/column/layout/after_section_end',array($this,'register_change_column_width'), 10 );
    }
    /*****   START PARALLAX CONTROLS   ******/
    public function section_parallax_controls( $element ) {
        $element->start_controls_section( 'digilab_parallax_section',
            [
                'label' => esc_html__( 'Digilab Parallax', 'digilab' ),
                'tab' => Controls_Manager::TAB_LAYOUT
            ]
        );
        $element->add_control( 'digilab_parallax_switcher',
            [
                'label' => esc_html__( 'Enable Parallax', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-parallax jarallax parallax-',
            ]
        );
        $element->add_control( 'digilab_parallax_update',
            [
                'label' => '<div class="elementor-update-preview" style="background-color: #fff;display: block;"><div class="elementor-update-preview-button-wrapper" style="display:block;"><button class="elementor-update-preview-button elementor-button elementor-button-success" style="background: #d30c5c; margin: 0 auto; display:block;">Apply Changes</button></div><div class="elementor-update-preview-title" style="display:block;text-align:center;margin-top: 10px;">Update changes to pages</div></div>',
                'type' => Controls_Manager::RAW_HTML,
                'condition' => ['digilab_parallax_switcher' => 'yes'],
            ]
        );
        $element->add_control( 'digilab_parallax_type',
            [
                'label' => esc_html__( 'Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'condition' => ['digilab_parallax_switcher' => 'yes'],
                'default' => 'scroll',
                'options' => [
                    'scroll' => esc_html__( 'Scroll', 'digilab' ),
                    'scroll-opacity' => esc_html__( 'Scroll with Opacity', 'digilab' ),
                    'opacity' => esc_html__( 'Fade', 'digilab' ),
                    'scale' => esc_html__( 'Zoom', 'digilab' ),
                    'scale-opacity'  => esc_html__( 'Zoom with Fade', 'digilab' )
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_bg_size',
            [
                'label' => esc_html__( 'Image Size', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'auto',
                'condition' => ['digilab_parallax_switcher' => 'yes'],
                'options' => [
                    'auto' => esc_html__( 'Auto', 'digilab' ),
                    'cover' => esc_html__( 'Cover', 'digilab' ),
                    'contain' => esc_html__( 'Contain', 'digilab' )
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_speed',
            [
                'label' => esc_html__( 'Parallax Speed', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => -1,
                'max' => 2,
                'step' => 0.1,
                'default' => 0.2,
                'condition'  => ['digilab_parallax_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_parallax_mobile_support',
            [
                'label' => esc_html__( 'Parallax on Mobile Devices', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-mobile-parallax-',
                'condition'  => ['digilab_parallax_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_add_parallax_video',
            [
                'label' => esc_html__( 'Use Background Video', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-parallax-video-',
                'condition'  => ['digilab_parallax_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_local_video_format',
            [
                'label' => esc_html__( 'Video Format', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => 'external',
                'options' => [
                    'external' => esc_html__( 'External (Youtube,Vimeo)', 'digilab' ),
                    'mp4' => esc_html__( 'Local MP4', 'digilab' ),
                    'webm' => esc_html__( 'Local Webm', 'digilab' ),
                    'ogv' => esc_html__( 'Local Ogv', 'digilab' ),
                ],
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_parallax_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_add_parallax_video',
                            'operator' => '==', // it accepts:  =,==, !=,!==,  in, !in etc.
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_video_url',
            [
                'label' => esc_html__( 'Video URL', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => 'https://www.youtube.com/watch?v=AeeE6PyU-dQ',
                'description' => esc_html__( 'YouTube/Vimeo link, or link to video file (mp4 is recommended).', 'digilab' ),
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_parallax_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_add_parallax_video',
                            'operator' => '==', // it accepts:  =,==, !=,!==,  in, !in etc.
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_video_start_time',
            [
                'label' => esc_html__( 'Start Time', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'placeholder' => '10',
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_parallax_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_add_parallax_video',
                            'operator' => '==', // it accepts:  =,==, !=,!==,  in, !in etc.
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_video_end_time',
            [
                'label' => esc_html__( 'End Time', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'placeholder' => '70',
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_parallax_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_add_parallax_video',
                            'operator' => '==', // it accepts:  =,==, !=,!==,  in, !in etc.
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_video_volume',
            [
                'label' => esc_html__( 'Video Volume', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'placeholder' => '0',
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_parallax_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_add_parallax_video',
                            'operator' => '==', // it accepts:  =,==, !=,!==,  in, !in etc.
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->add_control( 'digilab_parallax_video_play_once',
            [
                'label' => esc_html__( 'Play Once', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'digilab' ),
                'label_off' => esc_html__( 'No', 'digilab' ),
                'return_value' => 'yes',
                'default' => 'no',
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_parallax_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_add_parallax_video',
                            'operator' => '==', // it accepts:  =,==, !=,!==,  in, !in etc.
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->end_controls_section();
    }

    /*****   START COLUMN CONTROLS   ******/
    public function register_change_column_width( $element ) {
        $element->start_controls_section('digilab_section_column_width_settings',
            [
                'label' => esc_html__( 'Digilab Custom Column', 'digilab' ),
                'tab' => Controls_Manager::TAB_LAYOUT
            ]
        );
        $element->add_responsive_control( 'digilab_column_width',
            [
                'label' => esc_html__( 'Change Column Width', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'selectors' => ['{{WRAPPER}}' => 'width: {{VALUE}}%!important;'],
            ]
        );
        $element->end_controls_section();
    }
    /*****   END COLUMN CONTROLS   ******/

    /*****   START CONTROLS SECTION   ******/
    public function register_change_section_structure( $element ) {
        $element->start_controls_section('digilab_section_structure_settings',
            [
                'label' => esc_html__( 'Digilab Structure', 'digilab' ),
                'tab' => Controls_Manager::TAB_LAYOUT
            ]
        );
        $element->add_control('digilab_section_structure_switcher',
            [
                'label' => esc_html__( 'Enable Digilab Structure', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'tf-structure tf-structure-',
            ]
        );
        $element->end_controls_section();
    }
    /*****   END COLUMN CONTROLS   ******/

    /*****   START CONTROLS SECTION   ******/
    public function register_change_section_indent_structure( $element ) {
        $element->add_control( 'digilab_section_indent',
            [
                'label' => esc_html__( 'Section Indent', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block'  => 'true',
                'default' => '',
                'prefix_class' => 'tf-section ',
                'separator' => 'before',
                'options' => [
                    '' => esc_html__( 'Default', 'digilab' ),
                    'default-padding' => esc_html__( 'Indent Top and Bottom', 'digilab' ),
                    'default-padding pt-0' => esc_html__( 'Indent Bottom No Top', 'digilab' ),
                    'default-padding pb-0' => esc_html__( 'Indent Top No Bottom', 'digilab' ),
                ]
            ]
        );
    }
    /*****   END COLUMN CONTROLS   ******/

    /*****   START CONTROLS SECTION   ******/
    public function register_add_section_overlay_width( $element ) {
        $element->add_control( 'digilab_section_overlay_heading',
            [
                'label' => esc_html__( 'DIGILAB OVERLAY EXTRA', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_width',
            [
                'label' => esc_html__( 'Width', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 4000,
                        'step' => 5
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-background-overlay' => 'width: {{SIZE}}{{UNIT}};'
                ],
                'separator' => 'before'
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_height',
            [
                'label' => esc_html__( 'Height', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 4000,
                        'step' => 5
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-background-overlay' => 'height: {{SIZE}}{{UNIT}};'
                ]
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_top_position',
            [
                'label' => esc_html__( 'Top Position', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 4000,
                        'step' => 5
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-background-overlay' => 'top: {{SIZE}}{{UNIT}};bottom:auto;'
                ],
                'separator' => 'before'
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_bottom_position',
            [
                'label' => esc_html__( 'Bottom Position', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 4000,
                        'step' => 5
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-background-overlay' => 'bottom: {{SIZE}}{{UNIT}};top:auto;'
                ]
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_left_position',
            [
                'label' => esc_html__( 'Left Position', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 4000,
                        'step' => 5
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-background-overlay' => 'left: {{SIZE}}{{UNIT}};'
                ]
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_right_position',
            [
                'label' => esc_html__( 'Right Position', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 4000,
                        'step' => 5
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-background-overlay' => 'right: {{SIZE}}{{UNIT}};left:auto;'
                ]
            ]
        );
        $element->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'digilab_section_overlay_border',
                'label' => esc_html__( 'Border', 'digilab' ),
                'selector' => '{{WRAPPER}} .elementor-background-overlay'
            ]
        );
        $element->add_responsive_control( 'digilab_section_overlay_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'digilab' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => [ '{{WRAPPER}} .elementor-background-overlay' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-left-radius: {{BOTTOM}}{{UNIT}};border-bottom-right-radius: {{LEFT}}{{UNIT}};'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => ''
                ]
            ]
        );
    }
    /*****   END COLUMN CONTROLS   ******/

    /*****   START CONTROLS SECTION   ******/
    public function digilab_add_particle_effect_to_section( $element ) {
        $element->start_controls_section('digilab_particles_settings',
            [
                'label' => esc_html__( 'Digilab Particles Effect', 'digilab' ),
                'tab' => Controls_Manager::TAB_LAYOUT,
            ]
        );
        $element->add_control( 'digilab_particles_type',
            [
                'label' => esc_html__( 'Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => esc_html__( 'None', 'digilab' ),
                    'default' => esc_html__( 'default', 'digilab' ),
                    'nasa' => esc_html__( 'nasa', 'digilab' ),
                    'bubble' => esc_html__( 'bubble', 'digilab' ),
                    'snow' => esc_html__( 'snow', 'digilab' ),
                ],
                //'prefix_class' => 'digilab-particles particles-',
            ]
        );
        $element->add_control( 'digilab_particles_options_heading',
            [
                'label' => esc_html__( 'Particles Options', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition'  => ['digilab_particles_type!' => 'none']
            ]
        );

        $element->add_control( 'digilab_particles_shape',
            [
                'label' => esc_html__( 'Shape Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'circle',
                'options' => [
                    'circle' => esc_html__( 'circle', 'digilab' ),
                    'edge' => esc_html__( 'edge', 'digilab' ),
                    'triangle' => esc_html__( 'triangle', 'digilab' ),
                    'polygon' => esc_html__( 'polygon', 'digilab' ),
                    'star' => esc_html__( 'star', 'digilab' ),
                ],
                'condition'  => ['digilab_particles_type!' => 'none']
            ]
        );
        $element->add_control( 'digilab_particles_number',
            [
                'label' => esc_html__( 'Number', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
                'condition'  => ['digilab_particles_type!' => 'none']
            ]
        );
        $element->add_control( 'digilab_particles_color',
            [
                'label' => esc_html__( 'Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#fff',
                'condition'  => ['digilab_particles_type!' => 'none']
            ]
        );
        $element->add_control( 'digilab_particles_opacity',
            [
                'label' => esc_html__( 'Opacity', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0.1,
                'max' => 1,
                'step' => 0.1,
                'default' => 0.4,
                'condition'  => ['digilab_particles_type!' => 'none']
            ]
        );
        $element->add_control( 'digilab_particles_size',
            [
                'label' => esc_html__( 'Size', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 1000,
                'step' => 1,
                'default' => 160,
                'condition'  => ['digilab_particles_type!' => 'none']
            ]
        );
        $element->end_controls_section();
    }
    /*****   END COLUMN CONTROLS   ******/

    /*****   START CONTROLS SECTION   ******/
    public function digilab_add_vegas_slider_to_section( $element ) {
        $element->start_controls_section('digilab_vegas_settings',
            [
                'label' => esc_html__( 'Digilab Vegas Slider', 'digilab' ),
                'tab' => Controls_Manager::TAB_LAYOUT,
            ]
        );
        $element->add_control( 'digilab_vegas_switcher',
            [
                'label' => esc_html__( 'Enable Background Slider', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-vegas-slider vegas-',
            ]
        );
        $element->add_control( 'digilab_vegas_images',
            [
                'label' => __( 'Add Images', 'digilab' ),
                'type' => Controls_Manager::GALLERY,
                'default' => [],
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_options_heading',
            [
                'label' => esc_html__( 'Slider Options', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition'  => ['digilab_vegas_images!' => '']
            ]
        );
        $element->add_control( 'digilab_vegas_animation_type',
            [
                'label' => esc_html__( 'Animation Type', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'default' => ['kenburns'],
                'options' => [
                    'kenburns' => esc_html__( 'kenburns', 'digilab' ),
                    'kenburnsUp' => esc_html__( 'kenburnsUp', 'digilab' ),
                    'kenburnsDown' => esc_html__( 'kenburnsDown', 'digilab' ),
                    'kenburnsLeft' => esc_html__( 'kenburnsLeft', 'digilab' ),
                    'kenburnsRight' => esc_html__( 'kenburnsRight', 'digilab' ),
                    'kenburnsUpLeft' => esc_html__( 'kenburnsUpLeft', 'digilab' ),
                    'kenburnsUpRight' => esc_html__( 'kenburnsUpRight', 'digilab' ),
                    'kenburnsDownLeft' => esc_html__( 'kenburnsDownLeft', 'digilab' ),
                    'kenburnsDownRight' => esc_html__( 'kenburnsDownRight', 'digilab' ),
                ],
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_transition_type',
            [
                'label' => esc_html__( 'Transition Type', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'default' => ['zoomIn','slideLeft','slideRight'],
                'options' => [
                    'fade' => esc_html__( 'fade', 'digilab' ),
                    'fade2' => esc_html__( 'fade2', 'digilab' ),
                    'slideLeft' => esc_html__( 'slideLeft', 'digilab' ),
                    'slideLeft2' => esc_html__( 'slideLeft2', 'digilab' ),
                    'slideRight' => esc_html__( 'slideRight', 'digilab' ),
                    'slideRight2' => esc_html__( 'slideRight2', 'digilab' ),
                    'slideUp' => esc_html__( 'slideUp', 'digilab' ),
                    'slideUp2' => esc_html__( 'slideUp2', 'digilab' ),
                    'slideDown' => esc_html__( 'slideDown', 'digilab' ),
                    'slideDown2' => esc_html__( 'slideDown2', 'digilab' ),
                    'zoomIn' => esc_html__( 'zoomIn', 'digilab' ),
                    'zoomIn2' => esc_html__( 'zoomIn2', 'digilab' ),
                    'zoomOut' => esc_html__( 'zoomOut', 'digilab' ),
                    'zoomOut2' => esc_html__( 'zoomOut2', 'digilab' ),
                    'swirlLeft' => esc_html__( 'swirlLeft', 'digilab' ),
                    'swirlLeft2' => esc_html__( 'swirlLeft2', 'digilab' ),
                    'swirlRight' => esc_html__( 'swirlRight', 'digilab' ),
                    'swirlRight2' => esc_html__( 'swirlRight2', 'digilab' ),
                    'burn' => esc_html__( 'burn', 'digilab' ),
                    'burn2' => esc_html__( 'burn2', 'digilab' ),
                    'blur' => esc_html__( 'blur', 'digilab' ),
                    'blur2' => esc_html__( 'blur2', 'digilab' ),
                    'flash' => esc_html__( 'flash', 'digilab' ),
                    'flash2' => esc_html__( 'flash2', 'digilab' ),
                ],
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_overlay_type',
            [
                'label' => esc_html__( 'Overlay Image Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'prefix_class' => 'digilab-vegas-overlay vegas-overlay-',
                'options' => [
                    'none' => esc_html__( 'None', 'digilab' ),
                    '01' => esc_html__( 'Overlay 1', 'digilab' ),
                    '02' => esc_html__( 'Overlay 2', 'digilab' ),
                    '03' => esc_html__( 'Overlay 3', 'digilab' ),
                    '04' => esc_html__( 'Overlay 4', 'digilab' ),
                    '05' => esc_html__( 'Overlay 5', 'digilab' ),
                    '06' => esc_html__( 'Overlay 6', 'digilab' ),
                    '07' => esc_html__( 'Overlay 7', 'digilab' ),
                    '08' => esc_html__( 'Overlay 8', 'digilab' ),
                    '09' => esc_html__( 'Overlay 9', 'digilab' ),
                ],
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_delay',
            [
                'label' => esc_html__( 'Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'default' => 7000,
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_duration',
            [
                'label' => esc_html__( 'Transition Duration', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'default' => 2000,
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_shuffle',
            [
                'label' => esc_html__( 'Enable Shuffle', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'condition'  => ['digilab_vegas_switcher' => 'yes']
            ]
        );
        $element->add_control( 'digilab_vegas_timer',
            [
                'label' => esc_html__( 'Enable Timer', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'condition'  => ['digilab_vegas_switcher' => 'yes'],
                'selectors'  => ['{{WRAPPER}} .vegas-timer' => 'display:block!important;'],
            ]
        );
        $element->add_control( 'digilab_vegas_timer_size',
            [
                'label' => esc_html__( 'Timer Height', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 5,
                'selectors'  => ['{{WRAPPER}} .vegas-timer' => 'height:{{VALUE}};'],
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_vegas_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_vegas_timer',
                            'operator' => '==',
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->add_control( 'digilab_vegas_timer_color',
            [
                'label' => esc_html__( 'Timer Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#000',
                'selectors'  => ['{{WRAPPER}} .vegas-timer-progress' => 'background-color:{{VALUE}};'],
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'digilab_vegas_switcher',
                            'operator' => '==',
                            'value' => 'yes'
                        ],
                        [
                            'name' => 'digilab_vegas_timer',
                            'operator' => '==',
                            'value' => 'yes'
                        ]
                    ]
                ]
            ]
        );
        $element->end_controls_section();
    }

    public function digilab_custom_attr_to_section( $element ) {
        $data     = $element->get_data();
        $type     = $data['elType'];
        $settings = $data['settings'];
        $isInner  = $data['isInner'];// inner section

        if( 'section' === $element->get_name() ) {
            $gap = $element->get_settings('gap');
            $element->add_render_attribute( '_wrapper', 'class', 'digilab-gap-'.$gap );
        }

        // Particles Effect Options
        if( 'section' === $element->get_name() && 'none' !== $element->get_settings('digilab_particles_type') ) {

            $color   = $element->get_settings('digilab_particles_color');
            $type    = $element->get_settings('digilab_particles_type');
            $shape   = $element->get_settings('digilab_particles_shape');
            $number  = $element->get_settings('digilab_particles_number');
            $opacity = $element->get_settings('digilab_particles_opacity');
            $size    = $element->get_settings('digilab_particles_size');
            $size    = $size ? $size : 100;

            $element->add_render_attribute( '_wrapper', 'class', 'digilab-particles' );
            $element->add_render_attribute( '_wrapper', 'data-particles-settings', '{"type":"'.$type.'","color":"'.$color.'","shape":"'.$shape.'","number":'.$number.',"opacity":'.$opacity.',"size":'.$size.'}' );
            $element->add_render_attribute( '_wrapper', 'data-particles-id', $data['id'] );
        }
        // Vegas Slider Options
        if( 'section' === $element->get_name() && 'yes' === $element->get_settings('digilab_vegas_switcher') ) {
            $delay    = $element->get_settings('digilab_vegas_delay');
            $duration = $element->get_settings('digilab_vegas_duration');
            $timer    = $element->get_settings('digilab_vegas_timer');
            $shuffle  = $element->get_settings('digilab_vegas_shuffle');
            $overlay  = $element->get_settings('digilab_vegas_overlay_type');
            $images   = $element->get_settings('digilab_vegas_images');

            $transitions = $element->get_settings('digilab_vegas_transition_type');
            $transition = array();
            foreach ( $transitions as $trans ) {
                $transition[] =  '"'.$trans.'"';
            }
            $transition = implode(',', $transition);

            $animations = $element->get_settings('digilab_vegas_animation_type');
            $animation  = array();
            foreach ( $animations as $anim ) {
                $animation[] =  '"'.$anim.'"';
            }
            $animation = implode(',', $animation);

            $slides = array();
            foreach ( $images as $image ) {
                $slides[] =  '{"src":"'.$image['url'].'"}';
            }

            $element->add_render_attribute( '_wrapper', 'data-vegas-settings',  '{"slides":['.implode(',', $slides).'],"animation":['.$animation.'],"transition":['.$transition.'],"delay":'.$delay.',"duration":'.$duration.',"timer":"'.$timer.'","shuffle":"'.$shuffle.'","overlay":"'.$overlay.'"}' );

            $element->add_render_attribute( '_wrapper', 'data-vegas-id', $data['id'] );

        }
        // Parallax Effect Options
        if( 'section' === $element->get_name() && 'yes' === $element->get_settings('digilab_parallax_switcher') ) {
        $element->add_render_attribute( 'wrapper', 'class', $element->get_settings('digilab_section_indent') );
        $element->add_render_attribute( 'wrapper', 'class', $element->get_settings('digilab_section_outdent') );
        

            // Parallax attr
            $type   = $element->get_settings('digilab_parallax_type');
            $speed  = $element->get_settings('digilab_parallax_speed');
            $bgsize = $element->get_settings('digilab_parallax_bg_size');
            $mobile = $element->get_settings('digilab_parallax_mobile_support');
            $bgimg  = $element->get_settings('background_image');
            $bgimg  = $bgimg['url'];

            if ( 'yes' === $element->get_settings('digilab_add_parallax_video') && $element->get_settings('digilab_parallax_video_url') ) {

                if ( 'mp4' === $element->get_settings('digilab_local_video_format')) {
                    $videosrc = 'mp4:'.$element->get_settings('digilab_parallax_video_url');
                } elseif ( 'webm' === $element->get_settings('digilab_local_video_format')) {
                    $videosrc = 'webm:'.$element->get_settings('digilab_parallax_video_url');
                } elseif ( 'ogv' === $element->get_settings('digilab_local_video_format')) {
                    $videosrc = 'ogv:'.$element->get_settings('digilab_parallax_video_url');
                } else {
                    //$settings['background_video_link'] // elementor background video link
                    $videosrc = $element->get_settings('digilab_parallax_video_url');
                }

                $element->add_render_attribute( '_wrapper', 'data-jarallax data-video-src', $videosrc);

                if ( $element->get_settings('digilab_parallax_video_start_time') ) {
                $element->add_render_attribute( '_wrapper', 'data-video-start-time', $element->get_settings('digilab_parallax_video_start_time'));
                }
                if ( $element->get_settings('digilab_parallax_video_end_time') ) {
                $element->add_render_attribute( '_wrapper', 'data-video-end-time', $element->get_settings('digilab_parallax_video_end_time'));
                }
                if ( 'yes' === $element->get_settings('digilab_parallax_video_play_once') ) {
                $element->add_render_attribute( '_wrapper', 'data-jarallax-video-loop', 'false' );
                }
                if ( $element->get_settings('digilab_parallax_video_volume') ) {
                $element->add_render_attribute( '_wrapper', 'data-video-volume', $element->get_settings('digilab_parallax_video_volume') );
                }

            } else {
                $parallaxattr = '{"type":"'.$type.'","speed":"'.$speed.'","imgsize":"'.$bgsize.'","imgsrc":"'.$bgimg.'","mobile":"'.$mobile.'"}';
            $element->add_render_attribute( '_wrapper', 'data-digilab-parallax', $parallaxattr);
            }
            if( '0' !== $element->get_settings('digilab_section_column_structure_switcher') ) {
            $element->add_render_attribute( 'wrapper', 'class', $element->get_settings('digilab_section_change_column_structure') );
            }

        }

    }

    public static function get_instance() {
        if ( null == self::$instance ) {
            self::$instance = new self;
        }
        return self::$instance;
    }
}
Digilab_Section_Parallax::get_instance();
