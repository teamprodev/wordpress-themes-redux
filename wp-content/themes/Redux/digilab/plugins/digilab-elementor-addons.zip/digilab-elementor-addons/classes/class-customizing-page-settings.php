<?php

namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Core\Base\Document;
use Elementor\Core\Base\Module as BaseModule;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Core\DocumentTypes\PageBase as PageBase;
use Elementor\Modules\Library\Documents\Page as LibraryPageDocument;

if( !defined( 'ABSPATH' ) ) exit;

class Digilab_Customizing_Page_Settings {

    private static $instance = null;

    public static function get_instance() {
        if ( null == self::$instance ) {
            self::$instance = new Digilab_Customizing_Page_Settings();
        }
        return self::$instance;
    }

    public function __construct(){
        // custom option for elementor heading widget font size
        add_action( 'elementor/element/post/document_settings/before_section_end', [ $this,'digilab_add_page_settings' ], 10);
        //add_action( 'elementor/element/post/section_page_style/after_section_end',[ $this,'digilab_add_custom_settings_to_page_style_settings'], 10);

    }

    public function digilab_add_page_settings( $page )
    {

        if ( isset( $page ) && $page->get_id() > "" ){

            $digilab_post_type = get_post_type( $page->get_id() );
            $digilab_post_type = $digilab_post_type ? $digilab_post_type : false;

            if ( $digilab_post_type == 'page' || $digilab_post_type == 'post' || $digilab_post_type == 'elementor_library' || $digilab_post_type == 'revision' ) {

                $page->add_control( 'digilab_elementor_hide_page_header',
                    [
                        'label' => esc_html__( 'Hide Default Header', 'digilab' ),
                        'type' => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default' => 'no',
                        'separator' => 'before',
                        'conditions' => [
                            'relation' => 'or',
                            'terms' => [
                                [
                                    'name' => 'template',
                                    'operator' => '==',
                                    'value' => 'digilab-elementor-page.php'
                                ],
                                [
                                    'name' => 'template',
                                    'operator' => '==',
                                    'value' => 'elementor_header_footer'
                                ]
                            ]
                        ]
                    ]
                );
                $page->add_control( 'digilab_elementor_hide_page_footer',
                    [
                        'label' => esc_html__( 'Hide Default Footer', 'digilab' ),
                        'type' => Controls_Manager::SWITCHER,
                        'return_value' => 'yes',
                        'default' => 'no',
                        'separator' => 'before',
                        'conditions' => [
                            'relation' => 'or',
                            'terms' => [
                                [
                                    'name' => 'template',
                                    'operator' => '==',
                                    'value' => 'digilab-elementor-page.php'
                                ],
                                [
                                    'name' => 'template',
                                    'operator' => '==',
                                    'value' => 'elementor_header_footer'
                                ]
                            ]
                        ]
                    ]
                );
                $page->add_control( 'digilab_elementor_home_color',
                    [
                        'label' => __( 'Select Home Color', 'digilab' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'multiple' => true,
                        'options' => [
                            ''  => __( 'None', 'digilab' ),
                            'eastern-blue'  => __( 'Color 2', 'digilab' ),
                            'orange'  => __( 'Color 3', 'digilab' ),
                            'cornflower-blue'  => __( 'Color 4', 'digilab' ),
                        ],
                        'default' => 'color_1',
                        'separator' => 'before'
                    ]
                );
            }
        }
    }

    public function digilab_add_custom_css_to_page_settings( $page )
    {
        if( isset( $page ) && $page->get_id() > "" ) {

            $digilab_post_type = get_post_type( $page->get_id() );
            $digilab_post_type = $digilab_post_type ? $digilab_post_type : false;

            if ( $nt_post_type == 'page' || $nt_post_type == 'revision' ) {

                $page->start_controls_section( 'header_custom_css_controls_section',
                    [
                        'label' => esc_html__( 'WAVO Page Custom CSS', 'digilab' ),
                        'tab' => Controls_Manager::TAB_SETTINGS,
                    ]
                );
                $page->add_control( 'digilab_page_custom_css',
                    [
                        'label' => esc_html__( 'Custom CSS', 'digilab' ),
                        'type' => Controls_Manager::CODE,
                        'language' => 'css',
                        'rows' => 20,
                    ]
                );
                $page->end_controls_section();
            }
        }
    }

    public function digilab_page_registered_nav_menus()
    {
        $menus = wp_get_nav_menus();
        $options = array();
        if ( ! empty( $menus ) && ! is_wp_error( $menus ) ) {
            foreach ( $menus as $menu ) {
                $options[ $menu->slug ] = $menu->name;
            }
        }
        return $options;
    }
}
Digilab_Customizing_Page_Settings::get_instance();
