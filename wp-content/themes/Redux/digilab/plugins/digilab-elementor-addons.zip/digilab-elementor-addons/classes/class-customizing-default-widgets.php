<?php

namespace Elementor;

if( !defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Core\Base\Document;
use Elementor\Core\Base\Module as BaseModule;
use Elementor\Plugin;
use Elementor\Utils;
use Elementor\Element_Base;
use Elementor\Core\DocumentTypes\PageBase as PageBase;
use Elementor\Modules\Library\Documents\Page as LibraryPageDocument;

class digilab_Customizing_Default_Widgets {

    private static $instance = null;

    public static function get_instance() {
        if ( null == self::$instance ) {
            self::$instance = new digilab_Customizing_Default_Widgets();
        }
        return self::$instance;
    }

    public function __construct(){
        // custom option for elementor heading widget font size
        //add_action( 'elementor/element/button/section_button/before_section_end', [ $this,'digilab_add_custom_type_to_button']);
        //add_action( 'elementor/element/social-icons/section_social_icon/before_section_end', [ $this,'digilab_add_custom_type_to_social_icons']);
        add_action( 'elementor/element/heading/section_title/after_section_end', [ $this,'digilab_add_transform_to_heading']);
        add_action( 'elementor/element/heading/section_title/before_section_end', [ $this,'digilab_add_line_to_before_heading']);        
        add_action( 'elementor/element/image/section_image/after_section_end', [ $this,'digilab_add_custom_controls_to_image']);        
        add_action('elementor/frontend/widget/before_render',array($this,'digilab_add_custom_attr_to_widget'), 10);
    }


    public function digilab_add_line_to_before_heading( $widget )
    {
        $widget->add_control( 'digilab_heading_before_line_switcher',
            [
                'label' => esc_html__( 'Digilab Line Before', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-headig-line heading-has-line-',
                'selectors' => ['{{WRAPPER}}.digilab-headig-line .elementor-heading-title' => 'padding-left: 70px;' ],
                'condition' => ['digilab_heading_split_switcher' => 'yes'],
                'separator' => 'before'
            ]
        );
        $widget->add_responsive_control( 'digilab_heading_before_line_vertical',
            [
                'label' => esc_html__( 'Vertical Position ( % )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 45,
                'selectors' => [ '{{WRAPPER}}.digilab-headig-line .elementor-heading-title::after' => 'bottom:{{SIZE}}%;' ],
                'condition' => [ 'digilab_heading_before_line_switcher' => 'yes' ],
            ]
        );
        $widget->add_control( 'digilab_heading_before_line_color',
            [
                'label' => esc_html__( 'Line Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}}.digilab-headig-line .elementor-heading-title::after' => 'background-color: {{VALUE}};' ],
                'condition'  => ['digilab_heading_before_line_switcher' => 'yes']
            ]
        );
    }
    /*
    public function digilab_add_custom_type_to_button( $widget )
    {
        $controls = $widget->get_controls();
        $controls['button_type']['options'] += [
            'theme-btn-curve' => esc_html__( 'Theme Button Dark', 'digilab' ),
            'theme-btn-lit' => esc_html__( 'Theme Button Light', 'digilab' ),
        ];
        $widget->update_control('button_type', $controls['button_type']);
    }
    */
    /*
    public function digilab_add_custom_type_to_social_icons( $widget )
    {
        $controls = $widget->get_controls();
        $controls['shape']['options'] += [
            'no-shape' => esc_html__( 'No Shape', 'digilab' ),
        ];
        $widget->update_control('shape', $controls['shape']);
    }
    */
    public function digilab_add_transform_to_heading( $widget )
    {
        $widget->start_controls_section( 'heading_css_transform_controls_section',
            [
                'label' => esc_html__( 'Digilab CSS Transform', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $widget->add_control( 'heading_css_transform_type',
            [
                'label' => esc_html__( 'Transform Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'translate',
                'options' => [
                    'translate' => esc_html__( 'translate', 'digilab' ),
                    'scale' => esc_html__( 'scale', 'digilab' ),
                    'rotate' => esc_html__( 'rotate', 'digilab' ),
                    'skew' => esc_html__( 'skew', 'digilab' ),
                    'custom' => esc_html__( 'custom', 'digilab' ),
                ],
                'prefix_class' => 'digilab-transform transform-type-',
            ]
        );
        $widget->add_control( 'heading_css_transform_translate_heading',
            [
                'label' => esc_html__( 'Translate', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'heading_css_transform_type' => 'translate' ]
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_translate_xy',
            [
                'label' => esc_html__( 'Translate 2D ( X,Y )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'Xpx,Ypx',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-translate .elementor-heading-title' => 'transform:translate( {{VALUE}} );'],
                'condition' => [ 'heading_css_transform_type' => 'translate' ]
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_translate_xyz',
            [
                'label' => esc_html__( 'Translate 3D ( X,Y,Z )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'Xpx,Ypx,Zpx',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-translate.has-translate-xyz .elementor-heading-title' => 'transform:translate3d( {{VALUE}} );'],
                'prefix_class' => 'has-translate-xyz translate-xyz-',
                'condition' => [ 'heading_css_transform_type' => 'translate' ]
            ]
        );
        // Scale
        $widget->add_control( 'heading_css_transform_scale_heading',
            [
                'label' => esc_html__( 'Scale', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'heading_css_transform_type' => 'scale' ],
                'separator' => 'before'
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_scale_xy',
            [
                'label' => esc_html__( 'Scale 2D ( X,Y )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'Xpx,Ypx',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-translate .elementor-heading-title' => 'transform:scale( {{VALUE}} );'],
                'condition' => [ 'heading_css_transform_type' => 'scale' ]
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_scale_xyz',
            [
                'label' => esc_html__( 'Scale 3D ( X,Y,Z )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'Xpx,Ypx,Zpx',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-scale.has-scale-xyz .elementor-heading-title' => 'transform:scale3d( {{VALUE}} );'],
                'prefix_class' => 'has-scale-xyz scale-xyz-',
                'condition' => [ 'heading_css_transform_type' => 'scale' ]
            ]
        );
        // Rotate
        $widget->add_control( 'heading_css_transform_rotate_heading',
            [
                'label' => esc_html__( 'Rotate', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'heading_css_transform_type' => 'scale' ],
                'separator' => 'before'
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_rotate_xy',
            [
                'label' => esc_html__( 'Rotate 2D ( X,Y )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'Xdeg,Ydeg',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-rotate .elementor-heading-title' => 'transform:rotate( {{VALUE}} );'],
                'condition' => [ 'heading_css_transform_type' => 'rotate' ]
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_rotate_xyz',
            [
                'label' => esc_html__( 'Rotate 3D ( X,Y,Z )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => '0,0,0',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-rotate.has-rotate-xyz .elementor-heading-title' => 'transform:translate3d( {{VALUE}}deg );'],
                'prefix_class' => 'has-rotate-xyz rotate-xyz-',
                'condition' => [ 'heading_css_transform_type' => 'rotate' ]
            ]
        );
		// Skew
        $widget->add_control( 'heading_css_transform_skew_heading',
            [
                'label' => esc_html__( 'Skew', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'heading_css_transform_type' => 'skew' ]
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_skew_xy',
            [
                'label' => esc_html__( 'Skew 2D ( X,Y )', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => 'Xdeg,Ydeg',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-skew .elementor-heading-title' => 'transform:skew( {{VALUE}} );'],
                'condition' => [ 'heading_css_transform_type' => 'skew' ]
            ]
        );
        // Custom
        $widget->add_control( 'heading_css_transform_custom_heading',
            [
                'label' => esc_html__( 'Custom Transform', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [ 'heading_css_transform_type' => 'custom' ]
            ]
        );
        $widget->add_responsive_control( 'heading_css_transform_custom_xy',
            [
                'label' => esc_html__( 'Transform', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => 'rotate(Xdeg,Ydeg) translate(Xpx,Ypx) scale(X,Y)',
                'selectors' => [ '{{WRAPPER}}.digilab-transform.transform-type-custom .elementor-heading-title' => 'transform:( {{VALUE}} );'],
                'condition' => [ 'heading_css_transform_type' => 'custom' ]
            ]
        );
        $widget->end_controls_section();

        $widget->start_controls_section( 'digilab_heading_css_stroke_controls_section',
            [
                'label' => esc_html__( 'Digilab CSS Stroke', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $widget->add_control( 'digilab_heading_css_stroke_switcher',
            [
                'label' => esc_html__( 'Enable Stroke', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-stroke digilab-has-stroke-',
            ]
        );
        $widget->add_control( 'digilab_heading_css_stroke_type',
            [
                'label' => esc_html__( 'Stroke Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'full',
                'options' => [
                    'full' => esc_html__( 'Full Text', 'digilab' ),
                    'part' => esc_html__( 'Part of Text', 'digilab' ),
                ],
                'prefix_class' => 'digilab-has-stroke-type stroke-type-',
                'condition'  => ['digilab_heading_css_stroke_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_heading_css_stroke_note',
            [
                'label' => esc_html__( 'Important Note', 'digilab' ),
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__( 'Please add part of text in <b> your text </b>', 'digilab' ),
                'content_classes' => 'digilab-message',
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                            [
                                'name' => 'digilab_heading_css_stroke_switcher',
                                'operator' => '==',
                                'value' => 'yes'
                            ],
                            [
                                'name' => 'digilab_heading_css_stroke_type',
                                'operator' => '==',
                                'value' => 'part'
                            ]
                    ]
                ]
            ]
        );
        $widget->add_control( 'digilab_heading_css_stroke_width',
            [
                'label' => esc_html__( 'Stroke Width', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 20,
                'step' => 1,
                'default' => 1,
                'selectors' => [
                    '{{WRAPPER}}.digilab-stroke.stroke-type-full .elementor-heading-title' => '-webkit-text-stroke-width: {{SIZE}}px;color:transparent;',
                    '{{WRAPPER}}.digilab-stroke.stroke-type-part .elementor-heading-title b' => '-webkit-text-stroke-width: {{SIZE}}px;color:transparent;',
                ],
                'condition'  => ['digilab_heading_css_stroke_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_heading_css_stroke_color',
            [
                'label' => esc_html__( 'Stroke Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}}.digilab-stroke.stroke-type-full .elementor-heading-title' => '-webkit-text-stroke-color: {{VALUE}};',
                    '{{WRAPPER}}.digilab-stroke.stroke-type-part .elementor-heading-title b' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
                'condition'  => ['digilab_heading_css_stroke_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_heading_css_stroke_fill_color',
            [
                'label' => esc_html__( 'Fill Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => 'transparent',
                'selectors' => [
                    '{{WRAPPER}}.digilab-stroke.stroke-type-full .elementor-heading-title' => '-webkit-text-fill-color: {{VALUE}};',
                    '{{WRAPPER}}.digilab-stroke.stroke-type-part .elementor-heading-title b' => '-webkit-text-fill-color: {{VALUE}};',
                ],
                'condition'  => ['digilab_heading_css_stroke_switcher' => 'yes']
            ]
        );
        $widget->end_controls_section();

        $widget->start_controls_section( 'digilab_heading_parallax_controls_section',
            [
                'label' => esc_html__( 'Digilab Parallax', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $widget->add_control( 'digilab_heading_parallax_switcher',
            [
                'label' => esc_html__( 'Enable Parallax', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-headig-parallax heading-has-parallax-',
            ]
        );
        $widget->add_control( 'digilab_heading_parallax_note',
            [
                'label' => esc_html__( 'Important Note', 'digilab' ),
                'type' => Controls_Manager::RAW_HTML,
                'raw' => esc_html__( 'This option only works if there is a background image.Please add background image before.', 'digilab' ),
                'content_classes' => 'digilab-message',
                'condition'  => ['digilab_heading_parallax_switcher' => 'yes']
            ]
        );
        $widget->end_controls_section();
    }

    public function digilab_add_custom_controls_to_image( $widget )
    {

        $widget->start_controls_section( 'digilab_image_parallax_controls_section',
            [
                'label' => esc_html__( 'Digilab Parallax', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [ 'image[url]!' => '' ],
            ]
        );
        $widget->add_control( 'digilab_image_parallax_switcher',
            [
                'label' => esc_html__( 'Enable Parallax', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'prefix_class' => 'digilab-image-parallax image-has-parallax-',
            ]
        );
        $widget->add_control( 'digilab_image_parallax_overflow',
            [
                'label' => esc_html__( 'Overflow', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'condition'  => ['digilab_image_parallax_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_image_parallax_orientation',
            [
                'label' => esc_html__( 'Orientation', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'up',
                'options' => [
                    'up' => esc_html__( 'up', 'digilab' ),
                    'right' => esc_html__( 'right', 'digilab' ),
                    'down' => esc_html__( 'down', 'digilab' ),
                    'left' => esc_html__( 'left', 'digilab' ),
                    'up left' => esc_html__( 'up left', 'digilab' ),
                    'up right' => esc_html__( 'up right', 'digilab' ),
                    'down left' => esc_html__( 'down left', 'digilab' ),
                    'left right' => esc_html__( 'left right', 'digilab' ),
                ],
                'condition'  => ['digilab_image_parallax_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_image_parallax_scale',
            [
                'label' => esc_html__( 'Scale', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 0.1,
                'default' => 1.2,
                'description'=> esc_html__( 'need to be above 1.0', 'digilab' ),
                'condition'  => ['digilab_image_parallax_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_image_parallax_delay',
            [
                'label' => esc_html__( 'Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 0.1,
                'default' => 0.4,
                'description'=> esc_html__( 'the delay is in second', 'digilab' ),
                'condition'  => ['digilab_image_parallax_switcher' => 'yes']
            ]
        );
        $widget->add_control( 'digilab_image_parallax_maxtransition',
            [
                'label' => esc_html__( 'Max Transition ( % )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 99,
                'step' => 1,
                'default' => 0,
                'description'=> esc_html__( 'it should be a percentage between 1 and 99', 'digilab' ),
                'condition'  => ['digilab_image_parallax_switcher' => 'yes']
            ]
        );
        $widget->end_controls_section();
    }

    public function digilab_add_custom_attr_to_widget( $widget )
    {
        if( 'image' === $widget->get_name() ) {
            if( 'yes' == $widget->get_settings('digilab_image_parallax_switcher') ) {
                $mydata = array();
                $overflow = $widget->get_settings('digilab_image_parallax_overflow');
                $orientation = $widget->get_settings('digilab_image_parallax_orientation');
                $scale = $widget->get_settings('digilab_image_parallax_scale');
                $delay = $widget->get_settings('digilab_image_parallax_delay');
                $maxtrans = $widget->get_settings('digilab_image_parallax_maxtransition');

                $mydata[] .= $orientation ? '"orientation":"'.$orientation.'"' : '"orientation":"up"';
                $mydata[] .= 'yes' == $overflow ? '"overflow": true' : '"overflow": false';
                $mydata[] .= '' != $scale ? '"scale":'.$scale : '"scale":1.2';
                $mydata[] .= '' != $delay ? '"delay":'.$delay : '"delay":0.4';
                $mydata[] .= '' != $maxtrans ? '"maxtrans":'.$maxtrans : '"maxtrans":0';
                $parallaxattr = '{'.implode(',', $mydata ).'}';
                $widget->add_render_attribute( '_wrapper', 'data-image-parallax-settings', $parallaxattr);
            }
        }
    }

}
digilab_Customizing_Default_Widgets::get_instance();
