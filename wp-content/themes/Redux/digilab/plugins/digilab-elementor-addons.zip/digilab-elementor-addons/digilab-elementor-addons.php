<?php
/**
* Plugin Name: Digilab Elementor Addons
* Description: Premium & Advanced Essential Elements for Elementor
* Plugin URI:  http://themeforest.net/user/Themefora
* Version:     1.0.0
* Author:      Themefora
* Author URI:  https://themefora.com/
*/

/*
* Exit if accessed directly.
*/

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'DIGILAB_PLUGIN_FILE', __FILE__ );
define( 'DIGILAB_PLUGIN_BASENAME', plugin_basename(__FILE__) );
define( 'DIGILAB_PLUGIN_PATH', plugin_dir_path(__FILE__) );
define( 'DIGILAB_PLUGIN_URL', plugins_url('/', __FILE__) );

final class Digilab_Elementor_Addons
{

    /**
    * Plugin Version
    *
    * @since 1.0
    *
    * @var string The plugin version.
    */
    const VERSION = '1.0.0';

    /**
    * Minimum Elementor Version
    *
    * @since 1.0
    *
    * @var string Minimum Elementor version required to run the plugin.
    */
    const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

    /**
    * Minimum PHP Version
    *
    * @since 1.0
    *
    * @var string Minimum PHP version required to run the plugin.
    */
    const MINIMUM_PHP_VERSION = '5.6';

    /**
    * Instance
    *
    * @since 1.0
    *
    * @access private
    * @static
    *
    * @var Digilab_Elementor_Addons The single instance of the class.
    */
    private static $_instance = null;

    /**
    * Instance
    *
    * Ensures only one instance of the class is loaded or can be loaded.
    *
    * @since 1.0
    *
    * @access public
    * @static
    *
    * @return Digilab_Elementor_Addons An instance of the class.
    */
    public static function instance()
    {

        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
    * Constructor
    *
    * @since 1.0
    *
    * @access public
    */
    public function __construct()
    {
        add_action( 'init', [ $this, 'i18n' ] );
        add_action( 'plugins_loaded', [ $this, 'init' ] );
    }

    /**
    * Load Textdomain
    *
    * Load plugin localization files.
    *
    * Fired by `init` action hook.
    *
    * @since 1.0
    *
    * @access public
    */
    public function i18n()
    {
        load_plugin_textdomain( 'digilab' );
    }

    /**
    * Initialize the plugin
    *
    * Load the plugin only after Elementor (and other plugins) are loaded.
    * Checks for basic plugin requirements, if one check fail don't continue,
    * if all check have passed load the files required to run the plugin.
    *
    * Fired by `plugins_loaded` action hook.
    *
    * @since 1.0
    *
    * @access public
    */
    public function init()
    {
        // Check if Elementor is installed and activated
        if ( ! did_action( 'elementor/loaded' ) ) {
            add_action( 'admin_notices', [ $this, 'digilab_admin_notice_missing_main_plugin' ] );
            return;
        }
        // Check for required Elementor version
        if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
            add_action( 'admin_notices', [ $this, 'digilab_admin_notice_minimum_elementor_version' ] );
            return;
        }
        // Check for required PHP version
        if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
            add_action( 'admin_notices', [ $this, 'digilab_admin_notice_minimum_php_version' ] );
            return;
        }
        // register template name for the elementor saved templates
        add_filter( 'elementor/editor/localize_settings', [ $this,'digilab_register_template'],10,2 );

        /* Custom plugin helper functions */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-helpers-functions.php' );
        /* Elementor section parallax */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-custom-elementor-section.php' );
        /* Add custom controls to default widgets */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-customizing-default-widgets.php' );
        /* Add custom controls to page settings */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-customizing-page-settings.php' );
        /* Image resizer */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-image-resizer.php' );
        /* Digilab Elementor template */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-templater.php' );
        /* Custom metaboxes for gallery post type */
        require_once( DIGILAB_PLUGIN_PATH . '/classes/class-metaboxes-gallery.php' );
        /* includes/shortcodes/elementor */
        if ( ! get_option( 'disable_digilab_list_shortcodes' ) == 1 ) {
            require_once( DIGILAB_PLUGIN_PATH . '/classes/class-list-shortcodes.php' );
        }
        /* Admin template */
        require_once( DIGILAB_PLUGIN_PATH . '/templates/admin/admin.php' );

        // Categories registered
        add_action( 'elementor/elements/categories_registered', [ $this, 'digilab_add_widget_category' ] );
        // Widgets registered
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_single_widgets' ] );
        // Register Widget Styles
        add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'widget_styles' ] );
        // Register Widget Scripts
        add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'widget_scripts' ] );
        // Register Editor Scripts
        add_action('elementor/editor/after_enqueue_scripts', [ $this, 'admin_custom_scripts' ]);
        // Deregister Widget Scripts
        add_action( 'wp_print_styles', [ $this, 'dequeue_style' ], 100 );

    }

    public function dequeue_style() {
        if( is_page_template( 'digilab-elementor-page.php' ) || is_page_template( 'elementor_canvas' )  || is_page_template( 'elementor_header_footer' ) ){
            wp_dequeue_style( 'digilab-framework-style' );
        }
    }

    public function digilab_register_template( $localized_settings, $config )
    {
        $localized_settings = [
            'i18n' => [
                'my_templates' => esc_html__( 'Digilab Templates', 'digilab' )
            ]
        ];
        return $localized_settings;
    }

    public function admin_custom_scripts()
    {
        // Plugin custom css
        wp_enqueue_style( 'digilab-editor', DIGILAB_PLUGIN_URL. 'assets/front/css/plugin-editor.css' );
        wp_register_style( 'digilab-contact-form-7', DIGILAB_PLUGIN_URL. 'widgets/contact-form-7/style.css');
    }

    public function widget_styles()
    {
        // Plugin custom css
        wp_enqueue_style( 'jquery-ui', DIGILAB_PLUGIN_URL. 'assets/front/js/jquery-ui/jquery-ui.min.css' );
        wp_register_style( 'slick', DIGILAB_PLUGIN_URL. 'assets/front/js/slick/slick.css' );
        wp_register_style( 'slick-theme', DIGILAB_PLUGIN_URL. 'assets/front/js/slick/slick-theme.css' );
        wp_enqueue_style( 'digilab-vegas', DIGILAB_PLUGIN_URL. 'assets/front/js/vegas/vegas.css' );
        wp_enqueue_style( 'digilab-justified', DIGILAB_PLUGIN_URL. 'assets/front/js/justifiedGallery/justifiedGallery.min.css' );
        wp_enqueue_style( 'digilab-magnific', DIGILAB_PLUGIN_URL. 'assets/front/js/magnific/magnific-popup.css' );
        wp_enqueue_style( 'digilab-animated-headline', DIGILAB_PLUGIN_URL. 'assets/front/js/animated-headline/style.css');
        wp_enqueue_style( 'digilab-custom', DIGILAB_PLUGIN_URL. 'assets/front/css/custom.css' );
    }

    public function widget_scripts()
    {
        // Plugin custom scripts

        wp_enqueue_script( 'jquery-ui', DIGILAB_PLUGIN_URL. 'assets/front/js/jquery-ui/jquery-ui.min.js', [ 'jquery' ], self::VERSION, true);
        wp_register_script( 'slick', DIGILAB_PLUGIN_URL. 'assets/front/js/slick/slick.min.js', [ 'jquery' ], self::VERSION, true);
        wp_enqueue_script( 'digilab-isotope', DIGILAB_PLUGIN_URL. 'assets/front/js/isotope/isotope.min.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-justified', DIGILAB_PLUGIN_URL. 'assets/front/js/justifiedGallery/justifiedGallery.min.js', [ 'jquery' ], self::VERSION, true );
        // Parallax background and html elenments
        wp_enqueue_script( 'digilab-jarallax-video', DIGILAB_PLUGIN_URL. 'assets/front/js/jarallax/jarallax-video.min.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-jarallax', DIGILAB_PLUGIN_URL. 'assets/front/js/jarallax/jarallax.min.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-jarallax-fronted', DIGILAB_PLUGIN_URL. 'assets/front/js/jarallax/jarallax-fronted.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-particles', DIGILAB_PLUGIN_URL. 'assets/front/js/particles/particles.min.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-particles-frontend', DIGILAB_PLUGIN_URL. 'assets/front/js/particles/particles-frontend.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-vegas', DIGILAB_PLUGIN_URL. 'assets/front/js/vegas/vegas.min.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-vagas-frontend', DIGILAB_PLUGIN_URL. 'assets/front/js/vegas/vegas-frontend.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-simple-parallax', DIGILAB_PLUGIN_URL. 'assets/front/js/simpleParallax/simpleParallax.min.js', [ 'jquery' ], self::VERSION, true );
        wp_enqueue_script( 'digilab-magnific', DIGILAB_PLUGIN_URL. 'assets/front/js/magnific/magnific-popup.min.js', [ 'jquery' ], self::VERSION, true );
        wp_register_script( 'digilab-animated-headline', DIGILAB_PLUGIN_URL. 'assets/front/js/animated-headline/script.js', [ 'elementor-frontend' ], '1.0.0', true);
        wp_enqueue_script( 'digilab-animated-headline' );
        // custom-scripts
        wp_enqueue_script( 'digilab-addons-custom-scripts', DIGILAB_PLUGIN_URL. 'assets/front/js/custom-scripts.js', [ 'jquery' ], self::VERSION, true );
    }

    /**
    * Admin notice
    *
    * Warning when the site doesn't have Elementor installed or activated.
    *
    * @since 1.0
    *
    * @access public
    */
    public function digilab_admin_notice_missing_main_plugin()
    {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor */
            esc_html__( '%1$s requires %2$s to be installed and activated.', 'digilab' ),
            '<strong>' . esc_html__( 'Digilab Elementor Addons', 'digilab' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'digilab' ) . '</strong>'
        );
        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }

    /**
    * Admin notice
    *
    * Warning when the site doesn't have a minimum required Elementor version.
    *
    * @since 1.0
    *
    * @access public
    */
    public function digilab_admin_notice_minimum_elementor_version()
    {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
            esc_html__( '%1$s requires %2$s version %3$s or greater.', 'digilab' ),
            '<strong>' . esc_html__( 'Digilab Elementor Addons', 'digilab' ) . '</strong>',
            '<strong>' . esc_html__( 'Elementor', 'digilab' ) . '</strong>',
             self::MINIMUM_ELEMENTOR_VERSION
        );
        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }

    /**
    * Admin notice
    *
    * Warning when the site doesn't have a minimum required PHP version.
    *
    * @since 1.0
    *
    * @access public
    */
    public function digilab_admin_notice_minimum_php_version()
    {
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
        $message = sprintf(
            /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
            esc_html__( '%1$s requires %2$s version %3$s or greater.', 'digilab' ),
            '<strong>' . esc_html__( 'Digilab Elementor Addons', 'digilab' ) . '</strong>',
            '<strong>' . esc_html__( 'PHP', 'digilab' ) . '</strong>',
             self::MINIMUM_PHP_VERSION
        );
        printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
    }



    /**
    * Register Widgets Category
    *
    */
    public function digilab_add_widget_category( $elements_manager )
    {
        $elements_manager->add_category( 'digilab', [ 'title' => esc_html__( 'Digilab Addons', 'digilab' ) ] );
        $elements_manager->add_category( 'digilab-cpt', [ 'title' => esc_html__( 'Digilab CPT', 'digilab' ) ] );
        $elements_manager->add_category( 'digilab-post', [ 'title' => esc_html__( 'Digilab Post', 'digilab' ) ] );
    }

    public function digilab_widgets_list()
    {
        $list = array(
            array( 'name' => 'header-menu', 'class' => 'Digilab_Header_Menu' ),
            array( 'name' => 'footer-menu', 'class' => 'Digilab_Footer_Menu' ),
            array( 'name' => 'banner', 'class' => 'Digilab_Banner' ),
            array( 'name' => 'feature-box', 'class' => 'Digilab_Feature_Box' ),
            array( 'name' => 'choose-us-box', 'class' => 'Digilab_Choose_Us_Box' ),
            array( 'name' => 'blog-grid', 'class' => 'Digilab_Blog_Grid' ),
            array( 'name' => 'case-grid', 'class' => 'Digilab_Case_Grid' ),
            array( 'name' => 'page-hero', 'class' => 'Digilab_Page_Hero' ),
            array( 'name' => 'what-we-do', 'class' => 'Digilab_What_We_Do' ),
            array( 'name' => 'our-team', 'class' => 'Digilab_Our_Team' ),
            array( 'name' => 'process-area', 'class' => 'Digilab_Process_Area' ),
            array( 'name' => 'our-process-area', 'class' => 'Digilab_Our_Process_Area' ),
            array( 'name' => 'clients-area', 'class' => 'Digilab_Clients_Area' ),
            array( 'name' => 'our-pricing', 'class' => 'Digilab_Our_Pricing' ),
            array( 'name' => 'tabs-content', 'class' => 'Digilab_Tabs_Content' ),
            array( 'name' => 'testimonials-area', 'class' => 'Digilab_Testimonials_Area' ),
            array( 'name' => 'fun-factor-area', 'class' => 'Digilab_Fun_Factor_Area' ),
            array( 'name' => 'faq-area', 'class' => 'Digilab_Faq_Area' ),
            array( 'name' => 'progress-box', 'class' => 'Digilab_Progress_Box' ),
            array( 'name' => 'recent-post', 'class' => 'Digilab_Recent_Post' ),
            array( 'name' => 'footer-info-box', 'class' => 'Digilab_Footer_Info_Box' ),
            array( 'name' => 'button', 'class' => 'Digilab_Button' ),
            array( 'name' => 'animated-headline', 'class' => 'Digilab_Animated_Headline' ),
            array( 'name' => 'contact-form-7', 'class' => 'Digilab_Contact_Form_7' )
        );
        
        return $list;
    }


    /**
    * Init Widgets
    */
    public function init_widgets()
    {
        $widgets = $this->digilab_widgets_list();

        if ( ! empty( $widgets ) ) {

            foreach ( $widgets as $widget ) {

                $option = 'disable_'.str_replace( '-', '_', $widget[ 'name' ] );
                $path   = DIGILAB_PLUGIN_PATH . '/widgets/';
                $file   = $widget[ 'name' ] . '.php';
                $file   = isset( $widget[ 'subfolder' ] ) != '' ? $path.$widget[ 'subfolder' ] . '/' . $widget[ 'name' ]. '.php' : $path.$file;
                $class  = 'Elementor\\'.$widget[ 'class'] ;

                if ( ! get_option( $option ) == 1 ) {

                    if ( file_exists( $file ) ) {

                        require_once( $file );
                        \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new $class() );
                    }
                }
            }
        }
    }


    /**
    * Register Single Post Widgets
    */
    public function digilab_single_widgets_list()
    {
        $list = array(
            array( 'post-type' => 'projects', 'name' => 'project-next', 'class' => 'Digilab_Project_Next' ),
            array( 'post-type' => 'projects', 'name' => 'project-meta', 'class' => 'Digilab_Project_Meta' ),
            array( 'post-type' => 'post', 'name' => 'post-data', 'class' => 'Digilab_Post_Data' ),
        );
        return $list;
    }

    /**
    * Init Single Post Widgets
    */
    public function init_single_widgets()
    {
        $widgets = $this->digilab_single_widgets_list();
        global $post;
        $digilab_post_type = false;

        if ( ! empty( $widgets ) && !is_404()  && is_single() ) {
            $digilab_post_type = get_post_type( $post->ID );
            $count = 0;

            foreach ( $widgets as $widget ) {

                if ( $digilab_post_type == $widgets[ $count ][ 'post-type' ] ) {

                    $option = 'disable_'.str_replace( '-', '_', $widget[ 'name' ] );
                    $path   = DIGILAB_PLUGIN_PATH . '/widgets/';
                    $file   = $widget['name'] . '.php';
                    $file   = isset( $widget[ 'subfolder' ] ) != '' ? $path.$widget[ 'subfolder' ] . '/' . $widget[ 'name' ]. '.php' : $path.$file;
                    $class  = 'Elementor\\'.$widget[ 'class' ];

                    if ( ! get_option( $option ) == 1 ) {

                        if ( file_exists( $file ) ) {

                            require_once( $file );
                            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new $class() );
                        }
                    }
                }
                $count++;
            }
        }
    }

}
Digilab_Elementor_Addons::instance();
