<?php

/*
 *Template name: Digilab Elementor
 *Template Post Type: post, page, projects
*/
    get_header();

    $page_settings = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' )->get_model( get_the_ID() );
    $theCSS = $page_settings->get_settings( 'digilab_page_custom_css' );

    if ( FALSE === get_option('_digilab_elementor_page_custom_css') ) {
        add_option('_digilab_elementor_page_custom_css', $theCSS);
    } else {
        update_option('_digilab_elementor_page_custom_css', $theCSS);
    }

    // start page content
    if ( have_posts() ) :
        while ( have_posts() ) : the_post();
            the_content();
        endwhile;
    endif;

get_footer();
