<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Case_Grid extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-case-grid';
    }
    public function get_title() {
        return 'Case Grid (D)';
    }
    public function get_icon() {
        return 'eicon-posts-grid';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'tf_post_general',
            [
                'label' => esc_html__( 'General', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'column',
            [
                'label' => esc_html__( 'Column', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => '4',
                'options' => [
                    '' => esc_html__( 'Select Column', 'digilab' ),
                    '3' => esc_html__( '4 Column', 'digilab' ),
                    '4' => esc_html__( '3 Column', 'digilab' ),
                    '6' => esc_html__( '2 Column', 'digilab' )
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'tf_post_query',
            [
                'label' => esc_html__( 'Query', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'category_filter_heading',
            [
                'label' => esc_html__( 'Category Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );
        // Exclude Category
        $this->add_control( 'category_exclude',
            [
                'label' => esc_html__( 'Exclude Category', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_cpt_taxonomies( array ( 'taxonomy' => 'cases_cat','hide_empty' => true) ),
                'description' => 'Select Category(s) to Exclude',
            ]
        );
         // Tag Filter Heading
         $this->add_control( 'tag_filter_heading',
            [
                'label' => esc_html__( 'Tag Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );
        // Exclude Category
        $this->add_control( 'tags_exclude',
            [
                'label' => esc_html__( 'Exclude Tags', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_cpt_taxonomies( array ( 'taxonomy' => 'cases_tag', 'hide_empty' => true) ),
                'description' => 'Select Tags(s) to Exclude',
            ]
        );
        $this->add_control( 'author_filter_heading',
            [
                'label' => esc_html__( 'Author Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control( 'author_filter',
            [
                'label' => esc_html__( 'Author', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_users(),
                'description' => 'Select Author(s)'
            ]
        );

        $this->add_control( 'author_exclude_filter',
            [
                'label' => esc_html__( 'Exclude Author', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_users(),
                'description' => 'Select Author(s) to Exclude',
                'separator' => 'after'
            ]
        );       
        $this->add_control( 'post_filter_heading',
            [
                'label' => esc_html__( 'Post Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_control( 'post_other_heading',
            [
                'label' => esc_html__( 'Other Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_control('post_per_page',
            [
                'label' => esc_html__( 'Posts Per Page', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 1000,
                'default' => 6
            ]
        );

        $this->add_control( 'order',
            [
                'label' => esc_html__( 'Select Order', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => 'Ascending',
                    'DESC' => 'Descending'
                ],
                'default' => 'ASC'
            ]
        );
        
        $this->add_control( 'orderby',
            [
                'label' => esc_html__( 'Order By', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => 'None',
                    'ID' => 'Post ID',
                    'author' => 'Author',
                    'title' => 'Title',
                    'name' => 'Slug',
                    'date' => 'Date',
                    'modified' => 'Last Modified Date',
                    'parent' => 'Post Parent ID',
                    'rand' => 'Random',
                    'comment_count' => 'Number of Comments',
                ],
                'default' => 'none'
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'digilab_post_options',
            [
                'label' => esc_html__( 'Post Options', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'hidetitle',
            [
                'label' => esc_html__( 'Hide Title', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'hidecat',
            [
                'label' => esc_html__( 'Hide Category', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
                'separator' => 'before',
            ]
        );
        $this->add_control( 'hidemeta',
            [
                'label' => esc_html__( 'Hide Meta', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'before_author',
            [
                'label' => esc_html__( 'Before Author', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'By'
            ]
        );
        $this->add_control( 'hideexcerpt',
            [
                'label' => esc_html__( 'Hide Excerpt', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'excerpt_limit',
            [
                'label' => esc_html__( 'Excerpt Word Limit', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'default' => 20
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/


        $this->start_controls_section( 'post_box_style_section',
            [
                'label'=> esc_html__( 'Box Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_background( 'post_box_typo','{{WRAPPER}} case-studies-area case-items' );
        $this->digilab_style_padding( 'post_box_padding','{{WRAPPER}} case-studies-area case-items .title-blog' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_title_style_section',
            [
                'label'=> esc_html__( 'Title Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_title_typo','{{WRAPPER}} case-studies-area case-items .title-blog' );
        $this->digilab_style_color( 'post_title_color','{{WRAPPER}} case-studies-area case-items .title-blog' );
        $this->digilab_style_padding( 'post_title_padding','{{WRAPPER}} case-studies-area case-items .title-blog' );
        $this->digilab_style_margin( 'post_title_margin','{{WRAPPER}} case-studies-area case-items .title-blog' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_text_style_section',
            [
                'label'=> esc_html__( 'Excerpt Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_text_typo','{{WRAPPER}} .desc-blog' );
        $this->digilab_style_color( 'post_text_color','{{WRAPPER}} .desc-blog' );
        $this->digilab_style_padding( 'post_text_padding','{{WRAPPER}} .desc-blog' );
        $this->digilab_style_margin( 'post_text_margin','{{WRAPPER}} .desc-blog' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_meta_style_section',
            [
                'label'=> esc_html__( 'Author Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_meta_typo','{{WRAPPER}} case-studies-area case-items .meta .author a' );
        $this->digilab_style_color( 'post_meta_color','{{WRAPPER}} case-studies-area case-items .meta .author a' );
        $this->digilab_style_padding( 'post_meta_padding','{{WRAPPER}} case-studies-area case-items .meta .author a' );
        $this->digilab_style_margin( 'post_meta_margin','{{WRAPPER}} case-studies-area case-items .meta .author a' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_tags_style_section',
            [
                'label'=> esc_html__( 'Date Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_tags_typo','{{WRAPPER}} case-studies-area case-items .meta .date' );
        $this->digilab_style_color( 'post_tags_color','{{WRAPPER}} case-studies-area case-items .meta .date' );
        $this->digilab_style_padding( 'post_tags_padding','{{WRAPPER}} case-studies-area case-items .meta .date' );
        $this->digilab_style_margin( 'post_tags_margin','{{WRAPPER}} case-studies-area case-items .meta .date' );
        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $args = array (
            'post_type'   => array( 'cases' ),
            'post_status' => array( 'publish' ),
            'posts_per_page' => $settings['post_per_page'],            
            'order'       => $settings['order'],
            'orderby'     => $settings['orderby'],
            'tax_query'      => array(
                'relation' => 'OR',
                array(
                    'taxonomy' => 'cases_cat',
                    'field'    => 'id',
                    'terms'    => $settings['category_exclude'],
                    'operator' => 'NOT IN'
                ),
                array(
                    'taxonomy' => 'cases_tag',
                    'field'    => 'id',
                    'terms'    => $settings['tags_exclude'],
                    'operator' => 'NOT IN'
                )
            )            
        );
        
        $the_query = new \WP_Query( $args );

        if( $the_query->have_posts() ) {
            echo '<div class="case-studies-area circle-shape-right">';
                echo '<div class="container-off">';
                    echo '<div class="case-items">';
                        echo '<div class="row">';
                            while ( $the_query->have_posts() ) {
                                $the_query->the_post();
                                echo '<div class="single-item col-lg-'.$settings['column'].'">';
                                    echo '<div class="item wow fadeInUp" data-wow-delay="600ms">';

                                        if( has_post_thumbnail() ) {
                                            echo '<div class="thumb">';
                                                $image_id  = get_post_thumbnail_id();
                                                $id        = get_the_ID();
                                                $imagealt  = esc_attr( get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
                                                $imagealt  = $imagealt ? $imagealt : basename ( get_attached_file( $image_id ) );
                                                $image_url = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'thumbnail', $settings );

                                                if ( 'custom' == $settings['thumbnail_size'] ) {

                                                    $width  = $settings['thumbnail_custom_dimension']['width'];
                                                    $width  = $width ? ' width="'.$width.'"' : '';
                                                    $height = $settings['thumbnail_custom_dimension']['height'];
                                                    $height = $height ? ' height="'.$height.'"' : '';
                                                    $thumb  = '<img src="'.esc_url( $image_url ).'"'.$width.$height.' alt="'.$imagealt.'">';

                                                } else {

                                                    $thumb = get_the_post_thumbnail( $id, $settings['thumbnail_size'], array( 'class' => 'img-blog' ) );

                                                }

                                                echo $thumb;                                                    
                                                echo '<div class="overlay">';
                                                    echo '<a href="'.get_permalink().'"><i class="fas fa-link"></i></a>';
                                                echo '</div>';
                                            echo '</div>';
                                        }                                                            

                                        $id = get_the_id();                                            
                                        $cats = get_the_terms( $id, 'cases_cat' );

                                        echo '<div class="info">';

                                            if ( 'yes' == $settings['hidecat'] && $cats >= 1 ) {
                                                echo '<div class="cats">';
                                                    echo '<p>';
                                                        $cat_arr = [];
                                                        foreach ( $cats as $cat ) {                                                                                                                                
                                                            array_push($cat_arr, $cat->name);                                                            
                                                        }
                                                        $str = implode(', ', $cat_arr);
                                                        echo $str;
                                                    echo '</p>';
                                                echo '</div>';
                                            }

                                            if ( 'yes' != $settings[ 'hidetitle' ] ) {
                                                echo '<h5 class="title-blog"><a href="'.get_permalink().'">'.get_the_title().'</a></h5>';
                                            }

                                            if ( 'yes' != $settings[ 'hidemeta' ] ) {
                                                $by = '' != $settings[ 'before_author' ] ? $settings[ 'before_author' ] : '';
                                                echo '<div class="meta">';
                                                    $post_author = get_author_posts_url( get_the_author_meta( 'ID' ) );
                                                    echo '<ul>';
                                                        echo '<li><i class="fas fa-calendar-alt"></i> '.get_the_date().' </li>';
                                                        echo '<li>'.$by.' <a href="'.$post_author.'">'.get_the_author().'</a></li>';                                                        
                                                    echo '</ul>';
                                                echo '</div>';
                                            }

                                            if ( 'yes' != $settings[ 'hideexcerpt' ] ) {
                                                if ( has_excerpt() ){
                                                    echo '<p class="desc-blog">'.wp_trim_words( get_the_excerpt(), $settings['excerpt_limit'] ).'</p>';
                                                } else {
                                                    echo '<p class="desc-blog">'.wp_trim_words( trim( strip_tags( get_the_content() ) ), $settings['excerpt_limit'] ).'</p>';
                                                }
                                            }                                                
                                        echo '</div>';
                                    echo '</div>';
                                echo '</div>';
                            }
                            wp_reset_postdata();                            
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        } else {
            echo '<p class="text">' . esc_html__( 'No post found!', 'digilab' ) . '</p>';
        }
    }
}
