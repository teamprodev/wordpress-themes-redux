<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Footer_Info_Box extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-footer-info-box';
    }
    public function get_title() {
        return 'Footer Info Box (D)';
    }
    public function get_icon() {
        return 'eicon-checkbox';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    // Registering Controls
    protected function register_controls() {
        
        $this->start_controls_section('digilab_footer_info_settings',
            [
                'label' => esc_html__( 'Footer Info Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control( 'icon_color',
			[
				'label' => __( 'Icon Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
					'{{WRAPPER}} .icon i' => 'color: {{VALUE}}',
                ],
                'separator' => 'before'
			]
        );    

        $repeater->add_control( 'icon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-envelope',
                    'library' => 'solid'
                ]
            ]
        );

        $repeater->add_control( 'title',
            [
                'label' => __( 'Title', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Email:'
            ]
        );

        $repeater->add_control( 'title_color',
			[
				'label' => __( 'Title Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
					'{{WRAPPER}} .address .info h5' => 'color: {{VALUE}}',
                ],
                'separator' => 'after'
			]
        );   

        $repeater->add_control( 'description',
            [
                'label' => __( 'Description', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'support@themefora.com'
            ]
        );

        $repeater->add_control( 'description_color',
			[
				'label' => __( 'Description Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
					'{{WRAPPER}} .address .info span' => 'color: {{VALUE}}',
                ]                
			]
        );   

        $this->add_control(
			'list',
			[
				'label' => __( 'Repeater List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
                        'icon' => [ 'value' => 'fas fa-envelope', 'library' => 'solid' ],
						'title' => 'Email:',
						'description' => 'support@themefora.com'
                    ]
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();        
        ?>
            <div class="address">
                <ul>
                    <?php foreach( $settings['list'] as $row ) {
                            echo '<li>';
                                echo '<div class="icon">';
                                    Icons_Manager::render_icon( $row['icon'], [ 'aria-hidden' => 'true' ] );
                                echo '</div>';
                                echo '<div class="info">';
                                    echo '<h5 style="color: ' . $row['title_color'] . '">'.$row['title'].'</h5>';
                                    echo '<span style="color: ' . $row['description_color'] . '">'.$row['description'].'</span>';
                                echo '</div>';
                            echo '</li>';
                        }
                    ?>
                </ul>
            </div>
        <?php
    }
}
