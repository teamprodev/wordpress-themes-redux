<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Our_Team extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-our-team';
    }
    public function get_title() {
        return 'Our Team (D)';
    }
    public function get_icon() {
        return 'eicon-person';
    }
    public function get_style_depends() {
        return [ 'owl-theme','owl-carousel' ];
    }
    public function get_script_depends() {
        return [ 'owl-carousel' ];
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function _register_controls() {

        $this->start_controls_section( 'our_team_settings',
            [
                'label' => esc_html__( 'Our Team Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'design_option',
			[
				'label' => __( 'Design Option', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'default'  => __( 'Default', 'digilab' ),
					'carousel'  => __( 'Carousel', 'digilab' ),
                ],
                'default' => 'default'
			]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'image',
            [
                'label' => esc_html__( 'Image', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/team1.jpg', __DIR__ )]
            ]
        );

        $repeater->add_control( 'job',
            [
                'label' => __( 'Job', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Senior Marketer',
                'pleaceholder' => esc_html__( 'Enter job here', 'digilab' ),
                'label_block' => true
            ]
        );

        $repeater->add_control( 'name',
            [
                'label' => __( 'Name', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Jonathom Ahem',
                'pleaceholder' => esc_html__( 'Enter name here', 'digilab' ),
                'label_block' => true
            ]
        );

        $repeater->add_control( 'website_link',
			[
				'label' => __( 'Link', 'digilab' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'digilab' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true
				]
			]
		);

        $repeater->add_control( 'icon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-twitter',
                    'library' => 'solid'
                ],
            ]
        );        
        $repeater->add_control( 'link_title',
            [
                'label' => esc_html__( 'Link Title', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'https://twitter.com/themefora',
                'label_block' => true
            ]
        );
        $this->add_control(
			'list',
			[
				'label' => __( 'Repeater List', 'digilab' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'job' => 'Senior Marketer',
                        'name' => 'Jonathom Ahem',
                        'link' => 'twitter.com/themefora',
                        'link_title' => 'https://twitter.com/themefora',
					]
				],
				'title_field' => '{{{ name }}}'
			]
		);

        $this->end_controls_section();

        /** Slider Owl Settings ***/

        $this->start_controls_section( 'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Options', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => ['design_option' => 'carousel']
            ]
        );
        $this->add_control( 'items_md',
            [
                'label' => esc_html__( 'Per View ( Desktop )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 3
            ]
        );
        $this->add_control( 'items_sm',
            [
                'label' => esc_html__( 'Per View ( Tablet )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->add_control( 'items_xs',
            [
                'label' => esc_html__( 'Per View  ( Mobile )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'timeout',
            [
                'label' => esc_html__( 'Autoplay Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'loop',
            [
                'label' => esc_html__( 'Loop', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'                
            ]
        );
        $this->add_control( 'margin',
            [
                'label' => esc_html__( 'Space Between Items', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => ''
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $animate = \Elementor\Plugin::$instance->editor->is_edit_mode() ? '' : 'wow fadeInUp';

        $responsive = '"responsive":{"0":{"items":'.$settings['items_xs'].'},"768":{"items":'.$settings['items_sm'].'},"1024":{"items":'.$settings['items_md'].'}}';
        $data[] = $settings['speed'] ? '"speed": '.$settings['speed'] : '"speed":3000';
        $data[] = 'yes' == $settings['loop'] ? '"loop": true' : '"loop": false';        
        $data[] = 'yes' == $settings['dots'] ? '"dots": true' : '"dots": false';
        $data[] = 'yes' == $settings['autoplay'] ? '"autoplay": true' : '"autoplay": false';
        $data[] = $settings['timeout'] ? '"autoplayTimeout": '.$settings['timeout'] : '"autoplayTimeout": 5000';
        $data[] = $settings['margin'] ? '"margin": '.$settings['margin'] : '"margin": 30';
        $data[] = $responsive;
            
        echo ($settings['design_option'] === "default") ? '<div class="team-area">' : '<div class="team-area carousel-shadow">';  
            echo '<div class="container-off">';
                echo ($settings['design_option'] === "default") ? '<div class="team-items text-center">' : '<div data-owl-options=\'{'.implode( ', ', $data ).'}\' class="team-items '.$animate.' team-carousel owl-carousel owl-theme text-center digilab-carousel">'; 
                    echo ($settings['design_option'] === "default") ? '<div class="row justify-content-center">' : ''; 
                        foreach( $settings['list'] as $item ) {

                            echo ($settings['design_option'] === "default") ? '<div class="single-item col-lg-3 col-md-6">' : ''; 
                                echo ($settings['design_option'] === "default") ? '<div class="item '.$animate.'" data-wow-delay="500ms">' : '<div class="item">';                                    
                                    echo '<div class="thumb">';
                                        echo '<img src="'.$item['image']['url'].'" alt="'.$item['name'].'">';
                                    echo '</div>';
                                    echo '<div class="info">';
                                        echo '<span>'.$item['job'].'</span>';
                                        echo '<h4>'.$item['name'].'</h4>';
                                        
                                        if ( $item['website_link']['url'] ) {
                                            echo '<div class="contact">';
                                            
                                                $target = $item['website_link']['is_external'] ? ' target="_blank"' : '';
                    		                    $rel = $item['website_link']['nofollow'] ? ' rel="nofollow"' : '';
                    		                    
                                                echo '<a href="' . $item['website_link']['url'] . '"' . $target . $rel . '>';
                                                    if ( !empty( $item['icon'] ) ) {
                                                        Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] );
                                                    }
                                                    if ( !empty( $item['link_title'] ) ) {
                                                        echo $item['link_title'];
                                                    }
                                                echo '</a>';

                                            echo '</div>';
                                        } else {
                                            if ( !empty( $item['icon'] ) ) {
                                                echo '<div class="contact">';
                                                    Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] );
                                                echo '</div>';
                                            }
                                        }
                                    echo '</div>';
                                echo ($settings['design_option'] === "default") ? '</div>' : '';
                            echo '</div>';                                
                        }                            
                    echo ($settings['design_option'] === "default") ? '</div>' : ''; 
                echo '</div>';
            echo '</div>';
        echo '</div>';    
    }
}
