<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Footer_Menu extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-footer-menu';
    }
    public function get_title() {
        return 'Footer Menu (D)';
    }
    public function get_icon() {
        return 'eicon-download-button';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    // Registering Controls
    protected function register_controls() {
        
        $this->start_controls_section('digilab_footer_settings',
            [
                'label' => esc_html__( 'General Footer Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'footer_type',
			[
				'label' => __( 'Footer Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'type_1'  => __( 'Type 1', 'digilab' ),
					'type_2'  => __( 'Type 2', 'digilab' ),
                ],
                'default' => 'type_1'
			]
        );

        $this->add_control( 'show_copyright',
            [
                'label' => esc_html__( 'Show Copyright?', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'                
            ]
        );
        
        $this->add_control( 'footer_logo',
            [
                'label' => esc_html__( 'Footer Logo', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/logo-light.png', __DIR__ )],
            ]
        );
        
        $this->end_controls_section();
        
        $this->start_controls_section( 'footer_column_one',
            [
                'label' => esc_html__( 'Footer Column One', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'column_one',
			[
				'label' => __( 'Column Area', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<div class="address"> <ul> <li> <div class="icon"> <i class="flaticon-email"></i> </div> <div class="info"> <h5>Email:</h5> <span>support@themefora.com</span> </div> </li> <li> <div class="icon"> <i class="flaticon-call"></i> </div> <div class="info"> <h5>Phone:</h5> <span>+44-20-7328-4499</span> </div> </li> </ul> </div>', 'digilab' ),
				'placeholder' => __( 'Type your column area here', 'digilab' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section( 'footer_column_two',
            [
                'label' => esc_html__( 'Footer Column Two', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'column_two',
			[
				'label' => __( 'Column Area', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<div class="f-item link"> <h4 class="widget-title">Company</h4> <ul> <li> <a href="#">Home</a> </li> <li> <a href="#">About us</a> </li> <li> <a href="#">Compnay History</a> </li> <li> <a href="#">Features</a> </li> <li> <a href="#">Blog Page</a> </li> </ul> </div>', 'digilab' ),
				'placeholder' => __( 'Type your column area here', 'digilab' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section( 'footer_column_three',
            [
                'label' => esc_html__( 'Footer Column Three', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'column_three',
			[
				'label' => __( 'Column Area', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<div class="f-item link"> <h4 class="widget-title">Useful Link</h4> <ul> <li> <a href="#">Career</a> </li> <li> <a href="#">Leadership</a> </li> <li> <a href="#">Strategy</a> </li> <li> <a href="#">Services</a> </li> <li> <a href="#">History</a> </li> </ul> </div>', 'digilab' ),
				'placeholder' => __( 'Type your column area here', 'digilab' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section( 'footer_column_four',
            [
                'label' => esc_html__( 'Footer Column Four', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'column_four',
			[
				'label' => __( 'Column Area', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<div class="f-item recent-post"> <h4 class="widget-title">Latest News</h4> <div class="item"> <a href="#">Delighted prevailed supported too not remainder perpetual who furnished.</a> <span><i class="fas fa-calendar-alt"></i> 22 Aug, 2020 -  <a href="#">Admin</a></span> </div> <div class="item"> <a href="#">Speaking trifling an to unpacked moderate debating learnin management. </a> <span><i class="fas fa-calendar-alt"></i> 15 Nov, 2020 -  <a href="#">User</a></span> </div> </div>', 'digilab' ),
				'placeholder' => __( 'Type your column area here', 'digilab' ),
			]
		);

        $this->end_controls_section();

        $this->start_controls_section( 'footer_copyright',
            [
                'label' => esc_html__( 'Footer Copyright', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'copyright_text',
			[
				'label' => __( 'Copyright Text', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<p>Copyright &copy;  2020. Designed by <a href="https://themefora.com">themefora</a></p>', 'digilab' ),
                'placeholder' => __( 'Type your column area here', 'digilab' ),
                'seperator' => 'after'
			]
        );
        
        $this->add_control( 'copyright_right',
			[
				'label' => __( 'Copyright Right Area', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<ul> <li> <a href="#">Terms</a> </li> <li> <a href="#">Privacy</a> </li> <li> <a href="#">Support</a> </li> </ul>', 'digilab' ),
                'placeholder' => __( 'Type your column area here', 'digilab' )                
			]
		);

        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();        
        ?>

        <footer class="bg-dark text-light">

            <?php
                if( $settings['footer_type'] == "type_1" ) {
                    echo '<div class="svg-shape">';
                        echo '<svg xmlns="http://www.w3.org/2000/svg" class="gray" preserveAspectRatio="none" viewBox="0 0 1070 52">';
                            echo '<path d="M0,0S247,91,505,32c261.17-59.72,565-13,565-13V0Z"></path>';
                        echo '</svg>';
                    echo '</div>';
                }
            ?>

            <div class="container">
                <div class="f-items default-padding">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 item">
                            <div class="f-item about">
                                <img src="<?php echo esc_url( $settings['footer_logo']['url'] ); ?>" alt="Logo">
                                <?php echo $settings['column_one'] ;?>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-6 item">
                            <?php echo $settings['column_two'] ;?>
                        </div>

                        <div class="col-lg-2 col-md-6 item">
                            <?php echo $settings['column_three'] ;?>
                        </div>

                        <div class="col-lg-4 col-md-6 item">
                            <?php echo $settings['column_four'] ;?>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            if( $settings['show_copyright'] == "yes" ) { ?>                    
                <div class="footer-bottom">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <?php echo $settings['copyright_text']; ?>
                            </div>
                            <div class="col-md-6 text-right link">
                                <?php echo $settings['copyright_right']; ?> 
                            </div>
                        </div>
                    </div>
                </div>  
            <?php } ?>
        </footer> 
        <?php
    }
}
