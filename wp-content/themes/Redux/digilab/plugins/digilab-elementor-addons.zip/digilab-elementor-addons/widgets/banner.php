<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Banner extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-banner';
    }
    public function get_title() {
        return 'Banner (D)';
    }
    public function get_icon() {
        return 'eicon-slider-device';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    public function get_script_depends() {
        return [ 'YTPlayer','jquery-magnific-popup' ];
    }
    // Registering Controls
    protected function register_controls() {

        /*****   Banner Options   ******/
        $this->start_controls_section( 'digilab_backtotop_settings',
            [
                'label' => esc_html__( 'Banner Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'banner_type',
			[
				'label' => __( 'Banner Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'type_1'  => __( 'Type 1', 'digilab' ),
                    'type_2'  => __( 'Type 2', 'digilab' ),
                    'type_3'  => __( 'Type 3', 'digilab' ),
                    'type_4'  => __( 'Type 4', 'digilab' )                    
                ],
                'default' => 'type_1'
			]
        );
 
        $this->add_control( 'banner_image',
            [
                'label' => esc_html__( 'Banner Image', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [ 'url' => plugins_url( 'assets/front/img/2.png', __DIR__ ) ],
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'full',
                'condition' => [ 'banner_image[url]!' => '' ],
            ]
        );        

        $this->add_control( 'banner_moving_image',
            [
                'label' => esc_html__( 'Banner Moving Image', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [ 'url' => plugins_url( 'assets/front/img/speed-icon.png', __DIR__ ) ],
                'condition' => [ 'banner_type' => 'type_2' ]
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail2',
                'default' => 'full',
                'condition' => [ 'banner_moving_image[url]!' => '', 'banner_type' => 'type_2' ],
            ]
        );  

        $this->add_control( 'banner_title',
            [
                'label' => esc_html__( 'Banner Title', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => 'Generate More Traffic in your Website'                
            ]
        );

        $this->add_control( 'banner_description',
            [
                'label' => esc_html__( 'Banner Description', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => 'Contented continued any happiness instantly objection yet her allowance. Use correct day new brought tedious.',
                'condition' => [ 'banner_type!' => ['type_4'] ]
            ]
        );

        $this->add_control( 'button_text',
            [
                'label' => esc_html__( 'Button Text', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Get Started',
                'condition' => [ 'banner_type' => ['type_1', 'type_2', 'type_4'] ]
            ]
        );

        $this->add_control( 'button_link',
            [
                'label' => esc_html__( 'Button Link', 'digilab' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => ''
                ],
                'show_external' => true,
                'condition' => [ 'banner_type' => ['type_1', 'type_2', 'type_4'] ]
            ]
        );

        $this->add_control( 'video_link',
            [
                'label' => esc_html__( 'Video Link', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => '#',
                'condition' => [ 'banner_type' => 'type_3' ]
            ]
        );
        
        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        $elementid  = $this->get_id();

        $animate = \Elementor\Plugin::$instance->editor->is_edit_mode() ? '' : 'wow fadeInRight';

        $banner_title      = $this->get_settings( 'banner_title' );
        $banner_description = $this->get_settings( 'banner_description' );
        
        switch ($settings['banner_type']) {
            case 'type_1':
                $banner_class = 'banner-area with-fixed-nav';
                break;
            case 'type_2':
                $banner_class = 'banner-area with-fixed-nav heading-capitalized bg-gray-hard';
                break;
            case 'type_3':
                $banner_class = 'banner-area auto-height bg-cover-bottom';
                break;
            case 'type_4':
                    $banner_class = 'banner-area circle-shape text-center auto-height text-light heading-capitalized bg-gradient';
                    break;
            
            default:
                $banner_class = 'banner-area with-fixed-nav';
                break;
        }
        
        $image      = $this->get_settings( 'banner_image' );
        $image_url  = Group_Control_Image_Size::get_attachment_image_src( $image['id'], 'thumbnail', $settings );
        $imagealt   = esc_attr(get_post_meta($image['id'], '_wp_attachment_image_alt', true));
        $imagealt   = $imagealt ? $imagealt : basename ( get_attached_file( $image['id'] ) );
        $imageurl   = empty( $image_url ) ? $image['url'] : $image_url;

        $image_moving     = $this->get_settings( 'banner_moving_image' );
        $image_url        = Group_Control_Image_Size::get_attachment_image_src( $image_moving['id'], 'thumbnail2', $settings );
        $imagemovingalt   = esc_attr(get_post_meta($image_moving['id'], '_wp_attachment_image_alt', true));
        $imagemovingalt   = $imagemovingalt ? $imagemovingalt : basename ( get_attached_file( $image_moving['id'] ) );
        $imagemovingurl   = empty( $imagemovingurl ) ? $image_moving['url'] : $imagemovingurl;

        $href = $settings['banner_type'] != 'type_3' ? $settings['button_link']['url'] : '';

        $shape_class = ($settings['banner_type'] == 'type_1') ? 'shape-right-bottom shape opacity-default' : 'shape-left-bottom';

        if($settings['banner_type'] == 'type_1') {
            $shape = plugins_url( 'assets/front/img/13.png', __DIR__ );
        }else if($settings['banner_type'] == 'type_2') {
            $shape = plugins_url( 'assets/front/img/bg-1.png', __DIR__ );
        }else if($settings['banner_type'] == 'type_3') {
            $shape = plugins_url( 'assets/front/img/bg-2.png', __DIR__ );
        }else if($settings['banner_type'] == 'type_4') {
            $shape = plugins_url( 'assets/front/img/bg-3.png', __DIR__ );
        } 

        if($settings['banner_type'] == 'type_1') {
            $left_col_class = 'col-lg-6 order-last thumb width-130 '.$animate.' ';
        }else if($settings['banner_type'] == 'type_2') {
            $left_col_class = 'col-lg-7 info';
        }else if($settings['banner_type'] == 'type_3') {
            $left_col_class = 'col-lg-6 col-md-6 info';
        }else if($settings['banner_type'] == 'type_4') {
            $left_col_class = 'col-lg-8 offset-lg-2 info';
        }

        if($settings['banner_type'] == 'type_1') {
            $right_col_class = 'col-lg-6 info';
        }else if($settings['banner_type'] == 'type_2') {
            $right_col_class = 'col-lg-5 thumb width-120 '.$animate.' ';
        }else if($settings['banner_type'] == 'type_3') {
            $right_col_class = 'col-lg-6 col-md-6 thumb width-110 '.$animate.' ';
        }else if($settings['banner_type'] == 'type_4') {
            $right_col_class = 'col-lg-8 offset-lg-2 '.$animate.' ';
        }

        if($settings['banner_type'] == 'type_1') {
            $left_column_inside = '<img src="'.$imageurl.'" alt="'.$imagealt.'">';
        }else if($settings['banner_type'] == 'type_2') {                        
            $left_column_inside = '<h4 class="wow fadeInLeft">'.$banner_title.'</h4>';
            $left_column_inside .= '<h2 class="wow fadeInDown" data-wow-duration="1s">'.$banner_description.'</h2>';
            $left_column_inside .= '<a class="btn circle btn-md btn-gradient eastern-blue wow fadeInUp" data-wow-duration="1.8s" href="'.$href.'">'.$settings['button_text'].'</a>';
        }else if($settings['banner_type'] == 'type_3') {                        
            $left_column_inside = '<h2 class="wow fadeInDown">'.$banner_title.'</h2>';
            $left_column_inside .= '<p class="wow fadeInLeft" data-wow-duration="1.5s">'.$banner_description.'</p>';            
            $left_column_inside .= '<a href="'.$settings['video_link'].'" class="popup-youtube theme video-play-button relative video-inline"> <i class="fa fa-play"></i> </a>';
        }else if($settings['banner_type'] == 'type_4') {                        
            $left_column_inside = '<h2 class="wow fadeInDown" data-wow-duration="1s">'.$banner_title.'</h2>';
            $left_column_inside .= '<a class="btn circle btn-md btn-light effect wow fadeInUp" data-wow-duration="1.8s" href="'.$href.'">'.$settings['button_text'].'</a>';                        
        }

        if($settings['banner_type'] == 'type_1') {                        
            $right_column_inside = '<h2 class="wow fadeInDown" data-wow-duration="1s">'.$banner_title.'</h2>';
            $right_column_inside .= '<p class="wow fadeInLeft" data-wow-duration="1.5s">'.$banner_description.'</p>';
            $right_column_inside .= '<a class="btn circle btn-md btn-gradient wow fadeInUp" data-wow-duration="1.8s" href="'.$href.'">'.$settings['button_text'].'</a>';
        }else if($settings['banner_type'] == 'type_2') {     
            $right_column_inside = '<div class="thumb-innner">';
                $right_column_inside .= '<img src="'.$imageurl.'" alt="'.$imagealt.'">';
                $right_column_inside .= '<div class="icon">';
                    $right_column_inside .= '<img class="item-animated" src="'.$imagemovingurl.'" alt="'.$imagemovingalt.'">';
                $right_column_inside .= '</div>';
            $right_column_inside .= '</div>';
        }else if($settings['banner_type'] == 'type_3') {     
            $right_column_inside = '<img src="'.$imageurl.'" alt="'.$imagealt.'">';
        }else if($settings['banner_type'] == 'type_4') {
            $right_column_inside = '<div class="thumb-innner">';
                $right_column_inside .= '<img src="'.$imageurl.'" alt="'.$imagealt.'">';
            $right_column_inside .= '</div>';            
        }
                
        ?>

        <div class="<?php echo esc_attr($banner_class); ?>" style="<?php echo ($settings['banner_type'] == 'type_3') ? 'background-image: url('.$shape.')' : ''; ?>">
            <div class="<?php echo esc_attr($shape_class); ?>">
                <img src="<?php echo $shape; ?>" alt="Shape">
            </div>
            <div class="container">
                <?php echo ($settings['banner_type'] == 'type_4') ? '<div class="content-box">' : ''; ?>
                    <div class="double-items">
                        <div class="row align-center">
                            <div class="<?php echo esc_attr($left_col_class); ?>" <?php echo ($settings['banner_type'] == 'type_1') ? 'data-wow-duration="1s"' : ''; ?>>
                                <?php
                                    echo $left_column_inside;
                                ?>
                            </div>

                            <div class="<?php echo esc_attr($right_col_class); ?>" <?php echo ($settings['banner_type'] !== 'type_1') ? '' : 'data-wow-duration="1s"'; ?>>
                                <?php
                                    echo $right_column_inside;                                
                                ?>
                            </div>
                        </div>
                    </div>
                <?php echo ($settings['banner_type'] == 'type_4') ? '</div>' : ''; ?>
            </div>
        </div>

    <?php
    }
}
