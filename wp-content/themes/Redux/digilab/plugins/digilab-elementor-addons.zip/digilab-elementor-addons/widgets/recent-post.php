<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Recent_Post extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-recent-post';
    }
    public function get_title() {
        return 'Recent Post (D)';
    }
    public function get_icon() {
        return 'eicon-post-list';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section( 'recent_post_settings',
            [
                'label' => esc_html__( 'Recent Post Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'posts_per_page', [
				'label' => __( 'Posts Per Page', 'digilab' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '2',
				'label_block' => true
			]
		);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Define our WP Query Parameters
        $the_query = new \WP_Query( 'posts_per_page='.$settings['posts_per_page'] );
            
        echo '<div class="f-item recent-post">';
            while ($the_query->have_posts()) : $the_query->the_post(); 
                echo '<div class="item">';
                   echo '<a href="'.get_permalink().'">'.get_the_title().'</a>';

                   printf( '<span><i class="fas fa-calendar-alt"></i> %s - <a href="%s">%s</a></span>',                        
                        get_the_date(),
                        get_author_posts_url( get_the_author_meta( 'ID' ) ),
                        get_the_author()                      
                    );                   
                echo'</div>';
            endwhile;
            wp_reset_postdata();
        echo '</div>';
    }
}
