<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Header_Menu extends Widget_Base {
    use Digilab_Helper;

    public function get_name() {
        return 'digilab-menu';
    }
    public function get_title() {
        return 'Header Menu (D)';
    }
    public function get_icon() {
        return 'eicon-nav-menu';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    // Registering Controls
    protected function register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section('digilab_split_slider_general_settings',
            [
                'label' => esc_html__( 'General', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
                
        $this->add_control( 'register_menus',
            [
                'label' => esc_html__( 'Select Menu', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => false,
                'label_block' => true,
                'options' => $this->digilab_registered_nav_menus()
            ]
        );

        $this->add_control( 'image',
			[
				'label' => __( 'Choose Logo', 'digilab' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => ['url' => plugins_url( 'assets/front/img/logo.png', __DIR__ )],
			]
        );

        $this->add_control( 'color_option',
			[
				'label' => __( 'Color Option', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'dark'  => __( 'Dark', 'digilab' ),               
					'white' => __( 'White', 'digilab' ),               
                ],
                'default' => 'dark'
			]
        );
        
        $this->add_responsive_control( 'alignment',
            [
                'label' => esc_html__( 'Alignment', 'digilab' ),
                'type' => Controls_Manager::CHOOSE,
                'selectors' => ['{{WRAPPER}} .navbar' => 'justify-content: {{VALUE}};align-items: center;'],
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Left', 'digilab' ),
                        'icon' => 'fa fa-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'digilab' ),
                        'icon' => 'fa fa-align-center'
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Right', 'digilab' ),
                        'icon' => 'fa fa-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => 'flex-start',
                'separator' => 'before'
            ]
        );

        $this->add_control( 'header_type',
			[
				'label' => __( 'Header Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'type_1'  => __( 'Type 1', 'digilab' ),
					'type_2'  => __( 'Type 2', 'digilab' ),
                ],
                'default' => 'type_1'
			]
        );

        $this->add_control( 'container_type',
			[
				'label' => __( 'Container Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'container'  => __( 'Container', 'digilab' ),
					'container_full'  => __( 'Container Full', 'digilab' ),
                ],
                'default' => 'container'
			]
        );

        $this->add_control( 'is_sticky',
            [
                'label' => esc_html__( 'Sticky Header?', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control( 'header_sticky_bgcolor',
            [
                'label' => esc_html__( 'Sticky Section Background Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ 'nav.navbar.bootsnav.sticked' => 'background-color:{{VALUE}};' ],
                'condition' => ['is_sticky' => 'yes']
            ]
        );

        $this->add_control( 'header_sticky_a_clr',
            [
                'label' => esc_html__( 'Sticky Menu Item Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ 'nav.navbar.bootsnav.sticked #navbar-menu ul > li > a' => 'color:{{VALUE}};' ],
                'condition' => ['is_sticky' => 'yes']
            ]
        );

        $this->add_control( 'header_sticky_a_hvrclr',
            [
                'label' => esc_html__( 'Sticky Menu Item Color ( Hover )', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '.header.sticky-header.sticked .navbar .navbar-menu > li > a:hover, .widget-sticky-header.sticked .header .navbar .navbar-menu > li > a:hover, .widget-sticky-header-enabled.sticked .header .navbar .navbar-menu > li > a:hover' => 'color:{{VALUE}};' ],
                'condition' => ['is_sticky' => 'yes']
            ]
        );

        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        $this->start_controls_section( 'header_menu_item_style_controls_section',
            [
                'label' => esc_html__( 'Menu Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );

        $this->digilab_style_typo( 'header_menu_item_normal_typo', '{{WRAPPER}} .header .navbar .navbar-menu > li > a' );
        $this->digilab_style_padding( 'header_menu_item_padding', '{{WRAPPER}} .header .navbar .navbar-menu > li' );
        $this->digilab_style_margin( 'header_menu_item_margin', '{{WRAPPER}} .header .navbar .navbar-menu > li ' );
        //  Tabs
        $this->start_controls_tabs('header_menu_item_normal_tabs');
        $this->start_controls_tab( 'header_menu_item_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'digilab' ) ]
        );
        $this->digilab_style_color( 'header_menu_item_normal_color', '{{WRAPPER}} .header .navbar .navbar-menu > li > a' );
        $this->end_controls_tab();
        $this->start_controls_tab('header_menu_item_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'digilab' ) ]
        );
        $this->digilab_style_color( 'header_menu_item_hover_color', '{{WRAPPER}} .header .navbar .navbar-menu > li:hover > a,{{WRAPPER}} .header .navbar .navbar-menu > li > a:hover' );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        //  Tabs
        $this->add_control( 'header_menu_point_color',
            [
                'label' => esc_html__( 'Menu Point Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .header .navbar .navbar-menu > li:hover::before, {{WRAPPER}} .header .navbar .navbar-menu > li .sub-menu li.menu-item-has-children::before' => 'background-color:{{VALUE}};' ],
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        $this->start_controls_section( 'header_dropdown_menu_item_style_controls_section',
            [
                'label' => esc_html__( 'Dropdown Menu Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->add_control( 'header_dropdown_menu_bgcolor',
            [
                'label' => esc_html__( 'Submenu Background Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .navbar .navbar-menu li .sub-menu' => 'background-color:{{VALUE}};' ],
            ]
        );
        $this->add_control( 'header_dropdown_menu_width',
            [
                'label' => esc_html__( 'Submenu Min Width (rem)', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 12,
                'max' => 100,
                'step' => 1,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .navbar .navbar-menu li .sub-menu' => 'min-width:{{SIZE}}rem;' ],
            ]
        );
        $this->digilab_style_border( 'header_dropdown_menu_border', '{{WRAPPER}} .navbar .navbar-menu li .sub-menu' );
        $this->add_control( 'header_dropdown_menu_heading',
            [
                'label' => esc_html__( 'Submenu Item', 'digilab' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );
        $this->digilab_style_typo( 'header_dropdown_menu_item_typo', '{{WRAPPER}} .navbar .navbar-menu > li .sub-menu li a' );
        //  Tabs
        $this->start_controls_tabs('header_dropdown_menu_item_normal_tabs');
        $this->start_controls_tab( 'header_dropdown_menu_item_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'digilab' ) ]
        );
        $this->digilab_style_color( 'header_dropdown_menu_item_normal_color', '{{WRAPPER}} .navbar .navbar-menu > li .sub-menu li a' );
        $this->add_control( 'header_dropdown_menu_item_normal_bgcolor',
            [
                'label' => esc_html__( 'Background Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .navbar .navbar-menu > li .sub-menu li' => 'background-color:{{VALUE}};' ],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab('header_dropdown_menu_item_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'digilab' ) ]
        );
        $this->digilab_style_color( 'header_dropdown_menu_item_hover_color', '{{WRAPPER}} .navbar .navbar-menu > li .sub-menu li a:hover' );
        $this->add_control( 'header_dropdown_menu_item_normal_hvrbgcolor',
            [
                'label' => esc_html__( 'Background Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .navbar .navbar-menu > li .sub-menu li:hover' => 'background-color:{{VALUE}};' ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();        
        $id = $this->get_id();
        $is_sticky_type_1 = ('yes' == $settings['is_sticky'] && $settings['header_type'] == 'type_1') ? 'navbar-fixed' : '';
        $is_sticky_type_2 = ('yes' == $settings['is_sticky'] && $settings['header_type'] == 'type_2') ? 'navbar-sticky' : '';
        $header_type = 'type_1' == $settings['header_type'] ? 'navbar navbar-default attr-bg '.esc_attr( $is_sticky_type_1 ). ' ' . esc_attr( $settings['color_option'] ).'  bootsnav on no-full no-background' : 'navbar navbar-default '.esc_attr( $is_sticky_type_2 ).' dark attr-border bootsnav on no-full';        
        $container_type = 'container_full' == $settings['container_type'] ? 'container-full' : 'container';
        $navbar_position = 'container_full' == $settings['container_type'] ? 'navbar-center' : 'navbar-right';        
        ?>

        <header id="home" class="digilab-header-widget">
            <!-- Start Navigation -->            
            <nav class="<?php echo esc_attr( $header_type ); ?>">

                <!-- Start Top Search -->
                <div class="container">
                    <div class="row">
                        <div class="top-search">
                            <div class="input-group">
                                <form method="get" action="/<?php esc_url( home_url( '/' ) ); ?>">
                                    <input type="text" name="s" class="form-control" placeholder="<?php esc_attr_e( 'Search...', 'digilab' ); ?>">
                                    <button type="submit">
                                        <i class="ti-search"></i>
                                    </button>  
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Top Search -->

                <div class="<?php echo esc_attr( $container_type ); ?>">

                    <!-- Start Atribute Navigation -->
                    <div class="attr-nav extra-color">
                        <ul>
                            <?php
								if(digilab_settings( 'search_button_visibility' ) == '1') {                    
									echo '<li class="search"><a href="#"><i class="fas fa-search"></i></a></li>';
								}
							
								if(digilab_settings( 'side_bar_button_visibility' ) == '1') {
									echo '<li class="side-menu"><a href="#"><i class="fas fa-th-large"></i></a></li>';
								}
							?>
							
							<?php
								if(digilab_settings( 'language_button_visibility' ) == '1') {  ?>                                      
									<li class="language-switcher">
										<div class="dropdown">
											<button class="dropdown-toggle" type="button" data-toggle="dropdown">
												<img src="<?php echo get_template_directory_uri(); ?>/assets/img/lan-eng.png" alt="Flag">
											</button>
											<ul class="dropdown-menu">
												<?php
													foreach(digilab_settings( 'languages' ) as $lang) {                                                                
														echo '<li><a href="'.$lang['url'].'">'.$lang['title'].'</a></li>';
													}
												?>
											</ul>
										</div>
									</li>
							<?php } ?>   
                        </ul>
                    </div>        
                    <!-- End Atribute Navigation -->

                    <!-- Start Header Navigation -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                            <img src="<?php echo $settings['image']['url']; ?>" class="logo" alt="Logo">
                        </a>
                    </div>
                    <!-- End Header Navigation -->

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-menu">
                        <ul class="nav navbar-nav <?php echo esc_attr($navbar_position); ?> " data-in="fadeInDown" data-out="fadeOutUp">
                            <?php
                                if ( $settings['register_menus'] ) {
                                    wp_nav_menu(
                                        array(
                                            'menu' => $settings['register_menus'],
                                            'theme_location' => 'header_menu',
                                            'container' => '',
                                            'container_class' => '',
                                            'container_id' => '',
                                            'menu_class' => '',
                                            'menu_id' => '',
                                            'items_wrap' => '%3$s',
                                            'before' => '',
                                            'after' => '',
                                            'link_before' => '',
                                            'link_after' => '',
                                            'depth' => 4,
                                            'echo' => true,
                                            'fallback_cb' => 'Digilab_Menu::fallback',
                                            'walker' => new \Digilab_Menu()
                                        )
                                    );
                                } else {
                                    echo '<h3>'.esc_html__( 'No menu exists.Please create new menu from here. Dashboard > Appearance > Menus.', 'digilab' ).'<h3>';
                                }
                            ?>
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div>
				
				<?php if ( !empty( digilab_settings( 'side_bar_button_visibility','0' ) == '1' ) ) { ?>
                <!-- Start Side Menu -->
                <div class="side">
                    <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                    <?php
                        if ( !empty( digilab_settings( 'header_elementor_sidebar_templates' ) ) ) {

                            $template_id = digilab_settings( 'header_elementor_sidebar_templates' );
                            $frontend = new \Elementor\Frontend;
                            printf( '%1$s', $frontend->get_builder_content( $template_id, false ) );
    
                        } else {
    
                            printf( '<p class="info text-center ptb-40">%s</p>',
                                esc_html__( 'No template exist for the side bar.', 'digilab' )
                            );
                        }
                    ?>
                </div>
                <!-- End Side Menu -->
				<?php } ?>
            </nav>
            <!-- End Navigation -->

        </header>
        <?php
    }
}
