<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Tabs_Content extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-tabs-content';
    }
    public function get_title() {
        return 'Tabs Content (D)';
    }
    public function get_icon() {
        return 'eicon-tabs';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    // Registering Controls
    protected function register_controls() {

        /*****   Banner Options   ******/
        $this->start_controls_section( 'digilab_tabs_content_settings',
            [
                'label' => esc_html__( 'General Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'tab_title',
            [
                'label' => esc_html__( 'Tab Title', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Our Mission'
            ]
        );

        $repeater->add_control( 'heading',
            [
                'label' => esc_html__( 'Heading', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Data Visualization Research
                technique & Solution'
            ]
        );

        $repeater->add_control( 'content',
            [
                'label' => esc_html__( 'content', 'digilab' ),
                'type' => Controls_Manager::WYSIWYG,
                'label_block' => true,
                'default' => 'Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.',
                'placeholder' => 'Enter content here'
            ]
        );

        $repeater->add_control( 'button_text',
            [
                'label' => __( 'Button Text', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Read More'
            ]
        );

        $repeater->add_control( 'button_link',
            [
                'label' => __( 'Button Link', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => '#'
            ]
        );

        $this->add_control(
			'list',
			[
				'label' => __( 'Tabs List', 'digilab' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
                        'tab_title' => 'Our Mission',
						'heading' => 'Data Visualization Research <br> technique & Solution',
						'content' => 'Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.'
                    ],
                    [
                        'tab_title' => 'Our Vission',
						'heading' => 'Collect Ongoing Big Data <br> Design And Strategy',
						'content' => 'Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.'
                    ]
				],
				'title_field' => '{{{ tab_title }}}',
			]
		);
        
        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        ?>

        <div class="tabs-content-area">
            <div class="center-tabs">
                <div class="row">
                    <div class="col-lg-4">
                        <ul id="tabs" class="nav nav-tabs">
                            <?php foreach( $settings['list'] as $key => $value ) { ?>                                
                                <li class="nav-item">
                                    <a href="" data-target="#tab<?php echo esc_attr($key); ?>" data-toggle="tab" class="<?php echo ($key == 0) ? 'active' : ''; ?> nav-link"><?php echo esc_html($value['tab_title']); ?></a>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <div class="col-lg-8">
                        <div id="tabsContent" class="tab-content wow fadeInUp" data-wow-delay="0.5s">
                            <?php foreach( $settings['list'] as $key => $value ) { ?>
                                <div id="tab<?php echo esc_attr($key); ?>" class="tab-pane fade <?php echo ($key == 0) ? 'active show' : ''; ?>">
                                    <div class="row align-center">
                                        <div class="col-lg-12 info">
                                            <h5><?php echo esc_html($value['tab_title']); ?></h5>
                                            <?php printf( '<h2>%s</h2>',
                                                wp_kses($value['heading'], digilab_allowed_html())                                                
                                            ); ?>
                                            <p><?php echo esc_html($value['content']); ?></p>
                                            <a class="btn-simple" href="<?php echo esc_attr($value['button_link']); ?>"><i class="fas fa-angle-right"></i> <?php echo esc_html($value['button_text']); ?></a>
                                        </div>
                                    </div>
                                </div>     
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php
    }
}
