<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Clients_Area extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-clients-area';
    }
    public function get_title() {
        return 'Clients Area (D)';
    }
    public function get_icon() {
        return 'eicon-user-circle-o';
    }
    public function get_style_depends() {
        return [ 'owl-theme','owl-carousel' ];
    }
    public function get_script_depends() {
        return [ 'owl-carousel' ];
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    protected function register_controls() {

        $this->start_controls_section('clients_area_settings',
            [
                'label' => esc_html__( 'Clients Area Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'clients_area_type',
			[
				'label' => __( 'Clients Area Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'type_1'  => __( 'Type 1', 'digilab' ),
					'type_2'  => __( 'Type 2', 'digilab' ),
                ],
                'default' => 'type_1'
			]
        );

        $this->add_control( 'title',
            [
                'label' => __( 'Title', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => "We've Worked With Them, Now Trust Each Other",
                'pleaceholder' => esc_html__( 'Enter title here', 'digilab' ),
                'label_block' => true
            ]
        );

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control( 'img_url',
            [
                'label' => esc_html__( 'Image', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/01.png', __DIR__ )],
            ]
        );
        
        $this->add_control( 'images',
			[
				'label' => __( 'Images List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'img_url' => plugins_url( 'assets/front/img/01.png', __DIR__ )
					],
					[
						'img_url' => plugins_url( 'assets/front/img/02.png', __DIR__ )
                    ],
                    [
						'img_url' => plugins_url( 'assets/front/img/03.png', __DIR__ )
                    ]
				],
				'title_field' => 'Image'
			]
		);

        $this->end_controls_section();

        /** Slider Owl Settings ***/

        $this->start_controls_section( 'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Options', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'items_md',
            [
                'label' => esc_html__( 'Per View ( Desktop )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 3
            ]
        );
        $this->add_control( 'items_sm',
            [
                'label' => esc_html__( 'Per View ( Tablet )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->add_control( 'items_xs',
            [
                'label' => esc_html__( 'Per View  ( Mobile )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'timeout',
            [
                'label' => esc_html__( 'Autoplay Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control( 'loop',
            [
                'label' => esc_html__( 'Loop', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control( 'margin',
            [
                'label' => esc_html__( 'Space Between Items', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $bg_class = ($settings['clients_area_type'] === 'type_1') ? 'text-light bg-gradient default-padding-mx' : 'reverse default-padding';

        $responsive = '"responsive":{"0":{"items":'.$settings['items_xs'].'},"768":{"items":'.$settings['items_sm'].'},"1024":{"items":'.$settings['items_md'].'}}';
        $data[] = $settings['speed'] ? '"speed": '.$settings['speed'] : '"speed":3000';
        $data[] = 'yes' == $settings['loop'] ? '"loop": true' : '"loop": false';        
        $data[] = 'yes' == $settings['autoplay'] ? '"autoplay": true' : '"autoplay": false';
        $data[] = $settings['timeout'] ? '"autoplayTimeout": '.$settings['timeout'] : '"autoplayTimeout": 5000';
        $data[] = $settings['margin'] ? '"margin": '.$settings['margin'] : '"margin": 10';        
        $data[] = $responsive;
        ?>
            <div class="clients-area <?php echo esc_attr( $bg_class ); ?>">
                <?php
                    if($settings['clients_area_type'] === 'type_1') { ?>
                        <div class="fixed-bg" style="background-image: url(<?php echo plugins_url( 'assets/front/img/map.svg', __DIR__ ); ?>);"></div>
                    <?php }
                ?>

                <div class="container">
                    <div class="row align-center">
                        <?php if($settings['clients_area_type'] == 'type_1') { ?>
                            <div class="col-lg-5 info">
                                <h2><?php echo wp_kses( $settings['title'], digilab_allowed_html() ); ?></h2>
                            </div>
                            
                            <div class="col-lg-7">
                                <?php echo '<div data-owl-options=\'{'.implode( ', ', $data ).'}\' class="clients-carousel owl-carousel owl-theme digilab-carousel">'; ?>
                                    <?php
                                        if ( $settings['images'] ) {
                                            foreach($settings['images'] as $image) {
                                                echo '<div class="item">';
                                                    echo '<img src="'.$image['img_url']['url'].'" alt="Thumb">';
                                                echo '</div>';
                                            } 
                                        } 
                                    ?>
                                </div>
                            </div>
                        <?php }else { ?>
                            <div class="col-lg-7">
                                <?php echo '<div data-owl-options=\'{'.implode( ', ', $data ).'}\' class="clients-carousel owl-carousel owl-theme digilab-carousel">'; ?>
                                    <?php
                                        if ( $settings['images'] ) {
                                            foreach($settings['images'] as $image) {
                                                echo '<div class="item">';
                                                    echo '<img src="'.$image['img_url']['url'].'" alt="Thumb">';
                                                echo '</div>';
                                            } 
                                        } 
                                    ?>
                                </div>
                            </div>
                            
                            <div class="col-lg-5 info">
                                <h2><?php echo wp_kses( $settings['title'], digilab_allowed_html() ); ?></h2>
                            </div>
                        <?php } ?>
                                           
                    </div>
                </div>
                
                <?php
                    if($settings['clients_area_type'] === 'type_1') { ?>
                        <div class="shape-bottom">
                            <img src="<?php echo plugins_url( 'assets/front/img/8.png', __DIR__ ); ?>" alt="Shape">
                        </div>
                    <?php }
                ?>
            </div>
            
        <?php       
    }
}
