<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Choose_Us_Box extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-choose-us-box';
    }
    public function get_title() {
        return 'Choose Us Box (D)';
    }
    public function get_icon() {
        return 'eicon-check-circle';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section('choose_us_box_settings',
            [
                'label' => esc_html__( 'Choose Us Box Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        ); 

		$this->add_control(
			'title', [
				'label' => __( 'Title', 'digilab' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Global Reach' , 'digilab' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'description', [
				'label' => __( 'Description', 'digilab' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Upto 100%' , 'digilab' ),
				'label_block' => true,
			]
		);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
            <div class="choose-us-area">
                <ul>
                    <li>
                        <h5> <?php echo esc_html( $settings['title'] ); ?> </h5>
                        <?php if ( $settings['description'] ) { ?>
                        <p> <?php echo esc_html( $settings['description'] ); ?> </p>
                        <?php } ?>
                    </li>
                </ul>
            </div>
        <?php       
    }
}
