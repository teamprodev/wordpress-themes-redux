<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Testimonials_Area extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-testimonials-area';
    }
    public function get_title() {
        return 'Testimonials Area (D)';
    }
    public function get_icon() {
        return 'eicon-commenting-o';
    }
    public function get_style_depends() {
        return [ 'owl-carousel','owl-theme' ];
    }
    public function get_script_depends() {
        return [ 'owl-carousel' ];
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section( 'testimonials_area_settings',
            [
                'label' => esc_html__( 'Testimonials Area Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control( 'testimonial_heading',
            [
                'label' => __( 'Testimonial Heading', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'What people say<br/>About our Services',
                'label_block' => true
            ]
        );
        
        $repeater = new \Elementor\Repeater();                

        $repeater->add_control( 'comment',
            [
                'label' => __( 'Comment', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Tried known to as my to. Though wished merits or be. Alone visit use these smart rooms ham. No waiting in on enjoyed placing it inquiry. Tried known to as my to. Though wished merits or be. Alone visit use these smart.'
            ]
        );

        $repeater->add_control( 'customer_name',
            [
                'label' => __( 'Customer Name', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Droila Abhi'
            ]
        );

        $repeater->add_control( 'customer_job',
            [
                'label' => __( 'Customer Job', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Marketing manager'
            ]
        );        

        $this->add_control(
			'testimonials',
			[
				'label' => __( 'Testimonials List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[                        
                        'comment' => 'Tried known to as my to. Though wished merits or be. Alone visit use these smart rooms ham. No waiting in on enjoyed placing it inquiry. Tried known to as my to. Though wished merits or be. Alone visit use these smart.',
                        'customer_name' => 'Droila Abhi',
                        'customer_job' => 'Marketing manager',
					],
					[                        
                        'comment' => 'Tried known to as my to. Though wished merits or be. Alone visit use these smart rooms ham. No waiting in on enjoyed placing it inquiry. Tried known to as my to. Though wished merits or be. Alone visit use these smart.',
                        'customer_name' => 'Droila Abhi',
                        'customer_job' => 'Marketing manager',
                    ],
				],
				'title_field' => '{{{ customer_name }}}',
			]
        );
        
        $this->add_control( 'image_top',
            [
                'label' => esc_html__( 'Image Top', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/team1.jpg', __DIR__ )],
            ]
        );

        $this->add_control( 'image_left',
            [
                'label' => esc_html__( 'Image Left', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/team3.jpg', __DIR__ )],
            ]
        );

        $this->add_control( 'image_right',
            [
                'label' => esc_html__( 'Image Right', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/team2.jpg', __DIR__ )],
            ]
        );        

        $this->add_control( 'image_center',
            [
                'label' => esc_html__( 'Image Center', 'digilab' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => plugins_url( 'assets/front/img/team7.jpg', __DIR__ )],
            ]
        );

        $this->end_controls_section();

        /** Slider Owl Settings ***/

        $this->start_controls_section( 'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Options', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT                
            ]
        );
        $this->add_control( 'items_md',
            [
                'label' => esc_html__( 'Per View ( Desktop )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'items_sm',
            [
                'label' => esc_html__( 'Per View ( Tablet )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'items_xs',
            [
                'label' => esc_html__( 'Per View  ( Mobile )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'timeout',
            [
                'label' => esc_html__( 'Autoplay Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control( 'loop',
            [
                'label' => esc_html__( 'Loop', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'                
            ]
        );
        $this->add_control( 'margin',
            [
                'label' => esc_html__( 'Space Between Items', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
            ]
        );
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $animateLeft = \Elementor\Plugin::$instance->editor->is_edit_mode() ? '' : 'wow fadeInLeft';
        $animateRight = \Elementor\Plugin::$instance->editor->is_edit_mode() ? '' : 'wow fadeInRight';

        $image_top      = $this->get_settings( 'image_top' );
        $image_right      = $this->get_settings( 'image_right' );
        $image_left      = $this->get_settings( 'image_left' );
        $image_center      = $this->get_settings( 'image_center' );
        
        $testimonial_heading    = $this->get_settings( 'testimonial_heading' );

        $responsive = '"responsive":{"0":{"items":'.$settings['items_xs'].'},"768":{"items":'.$settings['items_sm'].'},"1024":{"items":'.$settings['items_md'].'}}';
        $data[] = $settings['speed'] ? '"speed": '.$settings['speed'] : '"speed":3000';
        $data[] = 'yes' == $settings['loop'] ? '"loop": true' : '"loop": false';        
        $data[] = 'yes' == $settings['dots'] ? '"dots": true' : '"dots": false';
        $data[] = 'yes' == $settings['autoplay'] ? '"autoplay": true' : '"autoplay": false';
        $data[] = $settings['timeout'] ? '"autoplayTimeout": '.$settings['timeout'] : '"autoplayTimeout": 5000';
        $data[] = $settings['margin'] ? '"margin": '.$settings['margin'] : '"margin": 30';
        $data[] = $responsive;
        ?>
  
            <div class="testimonials-area">
                <div class="container">
                    <div class="testimonial-items">
                        <div class="row align-center">
                            <div class="col-lg-5 <?php echo $animateLeft; ?>">
                                <div class="client-thumb">
                                    <img src="<?php echo esc_url( $image_top['url'] ); ?>" alt="Thumb">
                                    <img src="<?php echo  esc_url( $image_right['url'] ); ?>" alt="Thumb">
                                    <img src="<?php echo  esc_url( $image_left['url'] ); ?>" alt="Thumb">
                                    <img src="<?php echo  esc_url( $image_center['url'] ); ?>" alt="Thumb">
                                </div>
                            </div>

                            <div class="col-lg-6 offset-lg-1 testimonial-content <?php echo $animateRight; ?>">
                                <div class="heading">
                                    <h2><?php echo $testimonial_heading; ?></h2>
                                </div>
                                <?php echo '<div data-owl-options=\'{'.implode( ', ', $data ).'}\' class="testimonials-carousel owl-carousel owl-theme digilab-carousel">'; ?>

                                <?php
                                foreach( $settings['testimonials'] as $testimonial ) {
                                    echo '<div class="item">';
                                        echo '<p>';
                                            echo $testimonial['comment'];
                                        echo '</p>';
                                        echo '<div class="author">';
                                            echo '<div class="info">';
                                                echo '<h5>'.$testimonial['customer_name'].'</h5>';
                                                echo '<span>'.$testimonial['customer_job'].'</span>';
                                            echo '</div>';
                                        echo '</div>';
                                    echo '</div>';
                                } ?>
                                    
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
        <?php
    }
}