<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Fun_Factor_Area extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-fun-factor-area';
    }
    public function get_title() {
        return 'Fun Factor Area (D)';
    }
    public function get_icon() {
        return 'eicon-clock-o';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    public function get_script_depends() {
        return [ 'count-to' ];
    }

    // Registering Controls
    protected function _register_controls() {
        
        $this->start_controls_section('digilab_fun_factor_area_settings',
            [
                'label' => esc_html__( 'General Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'number',
            [
                'label' => esc_html__( 'Number', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '687'
            ]
        );

        $this->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Projects Executed'
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();        
        ?>
            <div class="fun-factor-area">
                <div class="client-items text-center">
                    <div class="item">
                        <div class="fun-fact">
                            <div class="timer" data-to="<?php echo esc_attr( $settings['number'] ); ?>" data-speed="5000"><?php echo esc_html( $settings['number'] ); ?></div>
                            <span class="medium"><?php echo esc_html( $settings['title'] ); ?></span>
                        </div>
                    </div>            
                </div>
            </div>
        <?php
    }
}
