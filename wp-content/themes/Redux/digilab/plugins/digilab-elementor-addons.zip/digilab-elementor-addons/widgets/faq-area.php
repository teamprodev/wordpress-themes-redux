<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Faq_Area extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-faq-area';
    }
    public function get_title() {
        return 'Faq Area (D)';
    }
    public function get_icon() {
        return 'eicon-bullet-list';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    // Registering Controls
    protected function register_controls() {

        /*****   Banner Options   ******/
        $this->start_controls_section( 'digilab_faq_area_settings',
            [
                'label' => esc_html__( 'General Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Where can I get analytics help?'
            ]
        );

        $repeater->add_control( 'description',
            [
                'label' => esc_html__( 'Description', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui consectetur at, sunt maxime, quod alias ullam officiis, ex necessitatibus similique odio aut!'
            ]
        );

        $this->add_control(
			'list',
			[
				'label' => __( 'Faq List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => 'Where can I get analytics help?',
						'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui consectetur at, sunt maxime, quod alias ullam officiis, ex necessitatibus similique odio aut!'
                    ],
                    [
						'title' => 'How much does data analytics costs?',
						'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui consectetur at, sunt maxime, quod alias ullam officiis, ex necessitatibus similique odio aut!'
                    ],
                    [
						'title' => 'What kind of data is needed for analysis?',
						'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui consectetur at, sunt maxime, quod alias ullam officiis, ex necessitatibus similique odio aut!'
                    ]
				],
				'title_field' => '{{{ title }}}',
			]
		);
        
        $this->end_controls_section();
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        ?>

        <div class="faq-area">            
            <div class="faq-items">                    
                <div class="faq-content wow fadeInUp">                                
                    <div class="accordion" id="accordion">
                        <?php
                            $i = 0;
                            foreach( $settings['list'] as $row ) { ?>
                                <div class="card">
                                    <div class="card-header" id="heading<?php echo $i; ?>">
                                        <h4 class="mb-0 <?php echo ( $i==0 ) ? 'collapsed' : ''; ?>" data-toggle="collapse" data-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo $i; ?>">
                                            <?php echo esc_html( $row['title'] ); ?>
                                        </h4>
                                    </div>

                                    <div id="collapse<?php echo $i; ?>" class="collapse <?php echo ( $i==0 ) ? 'show' : ''; ?>" aria-labelledby="heading<?php echo $i; ?>" data-parent="#accordion">
                                        <div class="card-body">
                                            <p>
                                                <?php echo esc_html( $row['description'] ); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            $i++;
                            }
                        ?>
                    </div>
                </div>                                                                
            </div>            
        </div>

    <?php
    }
}
