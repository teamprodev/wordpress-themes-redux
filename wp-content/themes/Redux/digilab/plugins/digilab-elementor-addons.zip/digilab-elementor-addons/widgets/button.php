<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Button extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-button';
    }
    public function get_title() {
        return 'Button (D)';
    }
    public function get_icon() {
        return 'eicon-button';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }

    // Registering Controls
    protected function register_controls() {

        /*****   Button Options   ******/
        $this->start_controls_section('digilab_btn_settings',
            [
                'label' => esc_html__( 'Button', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control( 'text',
            [
                'label' => esc_html__( 'Button Text', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__( 'Button Text', 'digilab' )
            ]
        );
        $this->add_control( 'link',
            [
                'label' => esc_html__( 'Button Link', 'digilab' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => ''
                ],
                'show_external' => true                
            ]
        );
        $this->add_control( 'use_icon',
            [
                'label' => esc_html__( 'Use Icon', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );
        $this->add_control( 'icon',
            [
                'label' => esc_html__( 'Button Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => '',
                    'library' => 'solid'
                ],
                'condition' => ['use_icon' => 'yes']
            ]
        );
        $this->add_control( 'icon_pos',
            [
                'label' => esc_html__( 'Icon Position', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'btn-icon-right',
                'options' => [
                    'btn-icon-left' => esc_html__( 'Before', 'digilab' ),
                    'btn-icon-right' => esc_html__( 'After', 'digilab' )
                ],
                'condition' => ['use_icon' => 'yes']
            ]
        );
        $this->add_control( 'icon_spacing',
            [
                'label' => esc_html__( 'Icon Spacing', 'digilab' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 60
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .digilab-button .btn-icon-left i,{{WRAPPER}} .digilab-button .btn-icon-left svg' => 'margin-right: {{SIZE}}px;',
                    '{{WRAPPER}} .digilab-button .btn-icon-right i,{{WRAPPER}} .digilab-button .btn-icon-right svg' => 'margin-left: {{SIZE}}px;'
                ],
                'condition' => ['use_icon' => 'yes']
            ]
        );
        $this->add_responsive_control( 'alignment',
            [
                'label' => esc_html__( 'Alignment', 'digilab' ),
                'type' => Controls_Manager::CHOOSE,
                'selectors' => ['{{WRAPPER}} .digilab-button:not(.btn-justify)' => 'text-align: {{VALUE}};'],
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'digilab' ),
                        'icon' => 'fa fa-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'digilab' ),
                        'icon' => 'fa fa-align-center'
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'digilab' ),
                        'icon' => 'fa fa-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => 'left'
            ]
        );
        $this->add_control( 'color',
            [
                'label' => esc_html__( 'Button Color Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'btn-primary',
                'options' => [
                    'btn-primary' => esc_html__( 'Primary', 'digilab' ),
                    'btn-secondary' => esc_html__( 'Secondary', 'digilab' ),
                    'btn-white' => esc_html__( 'White', 'digilab' ),
                    'btn-dark' => esc_html__( 'Dark', 'digilab' ),
                    'btn-gradient' => esc_html__( 'Gradient', 'digilab' ),
                    'btn-gradient eastern-blue' => esc_html__( 'Gradient 2', 'digilab' )
                ],
                'separator' => 'before'
            ]
        );
        $this->add_control( 'bgtype',
            [
                'label' => esc_html__( 'Button Background Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'btn-solid',
                'options' => [
                    'btn-solid' => esc_html__( 'Solid', 'digilab' ),
                    'btn-outline' => esc_html__( 'Outline', 'digilab' ),
                ],
                'conditions' => [
                    'relation' => 'and',
                    'terms' => [
                        [
                            'name' => 'color',
                            'operator' => '!==',
                            'value' => 'btn-gradient'
                        ]
                    ]
                ]
            ]
        );
        $this->add_control( 'radius',
            [
                'label' => esc_html__( 'Border Radius Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'btn-radius',
                'options' => [
                    'btn-radius' => esc_html__( 'Default', 'digilab' ),
                    'btn-square' => esc_html__( 'Square', 'digilab' ),
                    'btn circle' => esc_html__( 'Circle', 'digilab' ),
                ]
            ]
        );
        $this->add_control( 'shadow',
            [
                'label' => esc_html__( 'Shadow', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );
        $this->add_control( 'size',
            [
                'label' => esc_html__( 'Size', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__( 'Default', 'digilab' ),
                    'btn-sm' => esc_html__( 'Small', 'digilab' ),
                    'btn-lg' => esc_html__( 'Large', 'digilab' ),
                    'btn-full' => esc_html__( 'Full width', 'digilab' ),
                ]
            ]
        );
        $this->end_controls_section();
        /*****   End Button Options   ******/

        /***** Button Style ******/
        $this->start_controls_section('digilab_btn_animation',
            [
                'label' => esc_html__( 'Button Animations', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'aos_in',
            [
                'label' => esc_html__( 'Entrance Animation', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__( 'none', 'digilab' ),
                    'fade' => esc_html__( 'fade', 'digilab' ),
                    'fade-up' => esc_html__( 'fade up', 'digilab' ),
                    'fade-down' => esc_html__( 'fade-down', 'digilab' ),
                    'fade-left' => esc_html__( 'fade-left', 'digilab' ),
                    'fade-right' => esc_html__( 'fade-right', 'digilab' ),
                    'fade-up-right' => esc_html__( 'fade-up-right', 'digilab' ),
                    'fade-up-left' => esc_html__( 'fade-up-left', 'digilab' ),
                    'fade-down-right' => esc_html__( 'fade-down-right', 'digilab' ),
                    'fade-down-left' => esc_html__( 'fade-down-left', 'digilab' ),
                    'flip-up' => esc_html__( 'flip-up', 'digilab' ),
                    'flip-down' => esc_html__( 'flip-down', 'digilab' ),
                    'flip-left' => esc_html__( 'flip-left', 'digilab' ),
                    'flip-right' => esc_html__( 'flip-right', 'digilab' ),
                    'slide-up' => esc_html__( 'slide-up', 'digilab' ),
                    'slide-down' => esc_html__( 'slide-down', 'digilab' ),
                    'slide-left' => esc_html__( 'slide-left', 'digilab' ),
                    'slide-right' => esc_html__( 'slide-right', 'digilab' ),
                    'zoom-in' => esc_html__( 'zoom-in', 'digilab' ),
                    'zoom-in-up' => esc_html__( 'zoom-in-up', 'digilab' ),
                    'zoom-in-down' => esc_html__( 'zoom-in-down', 'digilab' ),
                    'zoom-in-left' => esc_html__( 'zoom-in-left', 'digilab' ),
                    'zoom-in-right' => esc_html__( 'zoom-in-right', 'digilab' ),
                ],
            ]
        );
        $this->add_control( 'aos_delay',
            [
                'label' => esc_html__( 'Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 50,
                'default' => 100,
                'description'=> esc_html__( 'the delay is in millisecond', 'digilab' ),
            ]
        );
        $this->end_controls_section();
        /*****   End Button Options   ******/

        /***** Button Style ******/
        $this->start_controls_section('digilab_btn_styling',
            [
                'label' => esc_html__( 'Button Custom Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->start_controls_tabs('digilab_btn_tabs');
        $this->start_controls_tab( 'digilab_btn_normal_tab',
            [ 'label' => esc_html__( 'Normal', 'digilab' ) ]
        );
        $this->add_control( 'btn_color',
            [
                'label' => esc_html__( 'Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .btn span' => 'color: {{VALUE}};']
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_typo',
                'label' => esc_html__( 'Typography', 'digilab' ),
                'scheme' => Scheme_Typography::TYPOGRAPHY_1,
                'selector' => '{{WRAPPER}} .digilab-button .btn span'
            ]
        );
        $this->add_responsive_control( 'btn_padding',
            [
                'label' => esc_html__( 'Padding', 'digilab' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => ['{{WRAPPER}} .btn' => 'padding-top: {{TOP}}{{UNIT}};padding-right: {{RIGHT}}{{UNIT}};padding-bottom: {{BOTTOM}}{{UNIT}};padding-left: {{LEFT}}{{UNIT}};'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'separator' => 'before'
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'btn_border',
                'label' => esc_html__( 'Border', 'digilab' ),
                'selector' => '{{WRAPPER}} .btn',
                'separator' => 'before'
            ]
        );
        $this->add_responsive_control( 'btn_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'digilab' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px' ],
                'selectors' => ['{{WRAPPER}} .btn' => 'border-top-left-radius: {{TOP}}{{UNIT}};border-top-right-radius: {{RIGHT}}{{UNIT}};border-bottom-left-radius: {{BOTTOM}}{{UNIT}};border-bottom-right-radius: {{LEFT}}{{UNIT}};'],
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => '',
                    'left' => '',
                ],
                'separator' => 'before'
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'btn_background',
                'label' => esc_html__( 'Background', 'digilab' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .btn',
                'separator' => 'before'
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab('digilab_btn_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'digilab' ) ]
        );
         $this->add_control( 'btn_hvr_color',
            [
                'label' => esc_html__( 'Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => ['{{WRAPPER}} .btn:hover' => 'color: {{VALUE}};']
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'btn_hvr_border',
                'label' => esc_html__( 'Border', 'digilab' ),
                'selector' => '{{WRAPPER}} .btn:hover',
                'separator' => 'before'
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'btn_hvr_background',
                'label' => esc_html__( 'Background', 'digilab' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .btn:hover',
                'separator' => 'before'
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
        /***** End Button Styling *****/
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        $settingsid = $this->get_id();
        $color      = $settings['color'];

        $delay      = $settings['aos_delay'] ? ' data-aos-delay="'.$settings['aos_delay'].'"' : '';
        $aos_in     = $settings['aos_in'] ? ' data-aos="'.$settings['aos_in'].'"'.$delay : '';
        $has_aos    = $settings['aos_in'] ? ' has-aos': '';

        $bgtype     = $settings['bgtype'] ? ' '.$settings['bgtype'] : '';
        $bgtype     = 'btn-gradient' == $color ? '' : $bgtype;
        $radius     = $settings['radius'] ? ' '.$settings['radius'] : '';
        $shadow     = 'yes' == $settings['shadow'] ? ' btn-sh' : '';
        $size       = $settings['size'] ? ' '.$settings['size'] : '';
        $iconpos    = !empty( $settings['icon']['value'] ) ? ' '.$settings['icon_pos'] : '';
        $btnicon    = $settings['use_icon'] == 'yes' ? ' has-icon' : '';
        $target     = $settings['link']['is_external'] ? ' target="_blank"' : '';
        $nofollow   = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
        $href       = $settings['link']['url'];
        $data       = $target.$nofollow;

        echo '<div class="digilab-button'.$btnicon.$has_aos.'"'.$aos_in.'>';
            if ( $settings['icon_pos'] == 'btn-icon-left' ) {
                echo '<a class="btn '.$color.$bgtype.$radius.$shadow.$size.$iconpos.'" href="'.$href.'"'.$data.'><span class="button_text">'; if ( !empty( $settings['icon']['value'] ) ) { Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); } echo $settings['text'].'</span></a>';
            } else {
                echo '<a class="btn '.$color.$bgtype.$radius.$shadow.$size.$iconpos.'" href="'.$href.'"'.$data.'><span class="button_text">'.$settings['text'].' ';
                if ( !empty( $settings['icon']['value'] ) ) { Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); } echo '</span></a>';
            }
        echo '</div>';
    }
}
