<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.
class Digilab_Contact_Form_7 extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-contact-form-7';
    }
    public function get_title() {
        return 'Contact Form 7 (D)';
    }
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {
        $this->start_controls_section( 'digilab_cf7_global_controls',
            [
                'label'=> esc_html__( 'Form Data', 'digilab' ),
                'tab'=> Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control('digilab_cf7_form_id_control',
            [
                'label'=> esc_html__( 'Select Form', 'digilab' ),
                'type'=> Controls_Manager::SELECT,
                'multiple'=> false,
                'options'=> $this->digilab_get_cf7(),
                'description'=> 'Select Form to Embed'
            ]
        );
        $this->end_controls_section();
        /*****   START CONTROLS SECTION   ******/

        /*****   END CONTROLS SECTION   ******/
        $this->start_controls_section( 'digilab_cf7_form_element_width_controls',
            [
                'label'=> esc_html__( 'Form Element Column Width', 'digilab' ),
                'tab'=> Controls_Manager::TAB_CONTENT,
                'condition'=> [ 'digilab_cf7_form_id_control!' => '' ]
            ]
        );
        $this->end_controls_section();
        /*****   START CONTROLS SECTION   ******/



        $this->start_controls_section('cf7_form_style_section',
            [
                'label'=> esc_html__( 'Form Content Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_slider_width( 'cf7_form_width',array('{{WRAPPER}} .nt-cf7-form-wrapper form' => 'width: {{SIZE}}px;max-width: {{SIZE}}px;'), $min=0, $max=2000 );
        $this->digilab_style_flex_alignment( 'cf7_form_alignment','{{WRAPPER}} .nt-cf7-form-wrapper' );
        $this->digilab_style_padding( 'cf7_form_padding','{{WRAPPER}} .nt-cf7-form-wrapper form' );
        $this->digilab_style_margin( 'cf7_form_margin','{{WRAPPER}} .nt-cf7-form-wrapper form' );
        $this->digilab_style_border( 'cf7_form_border','{{WRAPPER}} .nt-cf7-form-wrapper form' );
        $this->digilab_style_box_shadow( 'cf7_form_boxshadow','{{WRAPPER}} .nt-cf7-form-wrapper form' );

        $this->end_controls_section();

        $this->start_controls_section('cf7_form_label_style_section',
            [
                'label'=> esc_html__( 'Label Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'cf7_label_typo','{{WRAPPER}} .nt-cf7-form-wrapper form label' );
        $this->digilab_style_color( 'cf7_label_color','{{WRAPPER}} .nt-cf7-form-wrapper form label' );
        $this->digilab_style_flex_alignment( 'alignment','{{WRAPPER}} .nt-cf7-form-wrapper form label' );
        $this->digilab_style_padding( 'cf7_label_padding','{{WRAPPER}} .nt-cf7-form-wrapper form label' );
        $this->digilab_style_margin( 'cf7_label_margin','{{WRAPPER}} .nt-cf7-form-wrapper form label' );
        $this->digilab_style_border( 'cf7_flabel_border','{{WRAPPER}} .nt-cf7-form-wrapper form label' );

        $this->end_controls_section();

        $this->start_controls_section('cf7_form_input_style_section',
            [
                'label'=> esc_html__( 'Input Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'cf7_input_typo','{{WRAPPER}} input:not(.wpcf7-submit),{{WRAPPER}} textarea,{{WRAPPER}} form select' );
        $this->digilab_style_color( 'cf7_input_color','{{WRAPPER}} input:not(.wpcf7-submit),{{WRAPPER}} textarea,{{WRAPPER}} form select' );
        $this->digilab_style_slider_height( 'cf7_input_height',array('{{WRAPPER}} input:not(.wpcf7-submit), {{WRAPPER}} input[type="file"], {{WRAPPER}} form select' => 'height: {{SIZE}}px;line-height: {{SIZE}}px;','{{WRAPPER}} input[type="file"]' => 'padding-top: calc( ({{SIZE}}px / 2) - 18px )!important;padding-bottom: calc( ({{SIZE}}px / 2) - 18px )!important;height: inherit!important;line-height: inherit!important;' ), 30, 100 );
        $this->digilab_style_slider_width( 'cf7_input_width',array('{{WRAPPER}} input:not(.wpcf7-submit), {{WRAPPER}} .input-wrapper' => 'width: {{SIZE}}%;' ), 0, 100, '%' );
        $this->digilab_style_padding( 'cf7_input_padding','{{WRAPPER}} input:not(.wpcf7-submit), {{WRAPPER}} form select' );
        $this->digilab_style_margin( 'cf7_input_margin','{{WRAPPER}} input:not(.wpcf7-submit), {{WRAPPER}} form select,{{WRAPPER}} .nt-cf7-form-wrapper .wpcf7-form-control.wpcf7-checkbox,{{WRAPPER}} .nt-cf7-form-wrapper .wpcf7-form-control.wpcf7-radio,{{WRAPPER}} .nt-cf7-form-wrapper .wpcf7-form-control.wpcf7-acceptance' );
        $this->digilab_style_box_shadow( 'cf7_input_boxshadow','{{WRAPPER}} input:not(.wpcf7-submit), {{WRAPPER}} form select' );

        $this->start_controls_tabs( 'cf7_form_input_tabs');
        $this->start_controls_tab( 'cf7_form_input_normal_tab',
            [ 'label'  => esc_html__( 'Normal', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_background( 'cf7_input_background','{{WRAPPER}} input:not(.wpcf7-submit)',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_input_border','{{WRAPPER}} input:not(.wpcf7-submit)' );
        $this->digilab_style_opacity( 'cf7_input_opacity','{{WRAPPER}} input:not(.wpcf7-submit)' );

        $this->end_controls_tab();

        $this->start_controls_tab( 'cf7_form_input_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_background( 'cf7_input_hvr_background','{{WRAPPER}} input:not(.wpcf7-submit):hover',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_input_hvr_border','{{WRAPPER}} input:not(.wpcf7-submit):hover' );
        $this->digilab_style_opacity( 'cf7_input_hvr_opacity','{{WRAPPER}} input:not(.wpcf7-submit):hover' );

        $this->end_controls_tab();

        $this->start_controls_tab( 'cf7_form_focus_tab',
            [ 'label'  => esc_html__( 'Focus', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_background( 'cf7_input_focus_background','{{WRAPPER}} input:not(.wpcf7-submit):focus',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_input_focus_border','{{WRAPPER}} input:not(.wpcf7-submit):focus' );
        $this->digilab_style_opacity( 'cf7_input_focus_opacity','{{WRAPPER}} input:not(.wpcf7-submit):focus' );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section('cf7_form_textarea_style_section',
            [
                'label'=> esc_html__( 'Textarea Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'cf7_textarea_typo','{{WRAPPER}} .nt-cf7-form-wrapper form textarea' );
        $this->digilab_style_slider_width( 'cf7_textarea_width',array('{{WRAPPER}} .nt-cf7-form-wrapper form textarea' => 'width: {{SIZE}}%;max-width: {{SIZE}}%;'), $min=0, $max=2000, $unit='%' );
        $this->digilab_style_slider_height( 'cf7_textarea_height',array('{{WRAPPER}} .nt-cf7-form-wrapper form textarea' => 'height: {{SIZE}}px;' ) );
        $this->digilab_style_padding( 'cf7_textarea_padding','{{WRAPPER}} .nt-cf7-form-wrapper form textarea' );
        $this->digilab_style_margin( 'cf7_textarea_margin','{{WRAPPER}} .nt-cf7-form-wrapper form textarea' );
        $this->digilab_style_box_shadow( 'cf7_textarea_boxshadow','{{WRAPPER}} .nt-cf7-form-wrapper form textarea' );

        $this->start_controls_tabs( 'cf7_form_textarea_tabs');
        $this->start_controls_tab( 'cf7_form_textarea_normal_tab',
            [ 'label'  => esc_html__( 'Normal', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_color( 'cf7_textarea_color','{{WRAPPER}} textarea' );
        $this->digilab_style_background( 'cf7_textarea_background','{{WRAPPER}} .nt-cf7-form-wrapper form textarea',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_textarea_border','{{WRAPPER}} .nt-cf7-form-wrapper form textarea' );
        $this->digilab_style_opacity( 'cf7_textarea_opacity','{{WRAPPER}} .nt-cf7-form-wrapper form textarea' );

        $this->end_controls_tab();

        $this->start_controls_tab( 'cf7_form_textarea_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_color( 'cf7_textarea_hvr_color','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:hover' );
        $this->digilab_style_background( 'cf7_textarea_hvr_background','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:hover',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_textarea_hvr_border','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:hover' );
        $this->digilab_style_opacity( 'cf7_textarea_hvr_opacity','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:hover' );

        $this->end_controls_tab();

        $this->start_controls_tab( 'cf7_form_textarea_focus_tab',
            [ 'label'  => esc_html__( 'Focus', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_color( 'cf7_textarea_focus_color','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:focus' );
        $this->digilab_style_background( 'cf7_textarea_focus_background','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:focus',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_textarea_focus_border','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:focus' );
        $this->digilab_style_opacity( 'cf7_textarea_focus_opacity','{{WRAPPER}} .nt-cf7-form-wrapper form textarea:focus' );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section('cf7_formbtn_style_section',
            [
                'label' => esc_html__( 'Submit Button Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_flex_alignment( 'cf7_submit_alignment','{{WRAPPER}} form .submit-wrapper' );
        $this->digilab_style_typo( 'cf7_submit_typo','{{WRAPPER}} input.wpcf7-submit' );
        $this->digilab_style_slider_width( 'cf7_submit_width',array('{{WRAPPER}} input.wpcf7-submit' => 'text-align:center;width: {{SIZE}}%;min-width: {{SIZE}}%;'), $min=0, $max=2000, $unit='%' );
        $this->digilab_style_slider_height( 'cf7_submit_height',array('{{WRAPPER}} input.wpcf7-submit' => 'height: {{SIZE}}px;line-height: {{SIZE}}px;', ) );
        $this->digilab_style_padding( 'cf7_submit_padding','{{WRAPPER}} input.wpcf7-submit' );
        $this->digilab_style_margin( 'cf7_submit_margin','{{WRAPPER}} input.wpcf7-submit' );

        $this->start_controls_tabs( 'cf7_formbtn_tabs');
        $this->start_controls_tab( 'cf7_formbtn_normal_tab',
            [ 'label'  => esc_html__( 'Normal', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_color( 'cf7_submit_color','{{WRAPPER}} input.wpcf7-submit' );
        $this->digilab_style_background( 'cf7_submit_background','{{WRAPPER}} input.wpcf7-submit',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_submit_border','{{WRAPPER}} input.wpcf7-submit' );
        $this->digilab_style_box_shadow( 'cf7_submit_boxshadow','{{WRAPPER}} input.wpcf7-submit' );
        $this->end_controls_tab();

        $this->start_controls_tab( 'cf7_formbtn_hover_tab',
            [ 'label' => esc_html__( 'Hover', 'digilab' ) ]
        );
        // Style function
        $this->digilab_style_color( 'cf7_submit_hvr_color','{{WRAPPER}} input.wpcf7-submit:hover' );
        $this->digilab_style_background( 'cf7_submit_hvr_background','{{WRAPPER}} input.wpcf7-submit:hover',array('classic','gradient') );
        $this->digilab_style_border( 'cf7_submit_hvr_border','{{WRAPPER}} input.wpcf7-submit:hover' );
        $this->digilab_style_box_shadow( 'cf7_submit_hvr_boxshadow','{{WRAPPER}} input.wpcf7-submit:hover' );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

    }

    protected function render() {
        $settings  = $this->get_settings_for_display();
        $elementid = $this->get_id();
        $formid = $settings['digilab_cf7_form_id_control'];

        if (!empty($settings['digilab_cf7_form_id_control'])){
            echo '<div class="nt-cf7-form-wrapper form_'.$elementid.'">';
                echo do_shortcode( '[contact-form-7 id="'.$formid.'"]' );
            echo '</div>';
        } else {
            echo "Please Select a Form";
        }

    }
}
