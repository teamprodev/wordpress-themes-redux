<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Feature_Box extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-feature-box';
    }
    public function get_title() {
        return 'Feature Box (D)';
    }
    public function get_icon() {
        return 'eicon-flip-box';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section('feature_box_settings',
            [
                'label' => esc_html__( 'Feature Box Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'icon_color',
			[
				'label' => __( 'Icon Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
					'{{WRAPPER}} .icon' => 'color: {{VALUE}}',
				],
			]
        );
        
        $this->add_control( 'icon_bg_color',
			[
				'label' => __( 'Icon Background Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
			]
		);

        $this->add_control( 'ficon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid'
                ]
            ]
        );

        $this->add_control( 'ftitle',
            [
                'label' => esc_html__( 'Title', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'pleaceholder' => esc_html__( 'Enter name or title here', 'digilab' ),
                'default' => 'Link Building',
                'label_block' => true,
            ]
        );

        $this->add_control( 'ftag',
            [
                'label' => esc_html__( 'Tag', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'h4',
                'options' => [
                    'h1' => esc_html__( 'h1', 'digilab' ),
                    'h2' => esc_html__( 'h2', 'digilab' ),
                    'h3' => esc_html__( 'h3', 'digilab' ),
                    'h4' => esc_html__( 'h4', 'digilab' ),
                    'h5' => esc_html__( 'h5', 'digilab' ),
                    'h6' => esc_html__( 'h6', 'digilab' ),
                    'div' => esc_html__( 'div', 'digilab' ),
                    'p' => esc_html__( 'p', 'digilab' )
                ]
            ]
        );
        
        $this->add_control( 'fdesc',
            [
                'label' => esc_html__( 'Short Description', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'pleaceholder' => esc_html__( 'Enter description here', 'digilab' ),
                'default' => 'Favourite tolerably engrossed. Truth short folly court why she their balls Excellence super power.',
                'label_block' => true,
            ]
        );

        $this->end_controls_section();        
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
            <div class="features-area">
                <div class="feature-box text-center">
                    <!-- Single Item -->
                    <div class="single-item">
                        <div class="item">
                            <?php
                                if ( ! empty($settings['ficon']['value']) ) {
                                    echo '<div class="icon" style="background: ' . $settings['icon_bg_color'] . '">';
                                        Icons_Manager::render_icon( $settings['ficon'], [ 'aria-hidden' => 'true' ] );
                                    echo '</div>';
                                }

                                if ( $settings['ftitle'] ) {
                                    echo '<'.$settings['ftag'].'>'.$settings['ftitle'].'</'.$settings['ftag'].'>';
                                }

                                if ( $settings['fdesc'] ) {
                                    echo '<p>'.$settings['fdesc'].'</p>';
                                }
                            ?>
                        </div>
                    </div>
                    <!-- End Single Item -->
                </div>
            </div>
        <?php       
    }
}
