<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_What_We_Do extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-what-we-do';
    }
    public function get_title() {
        return 'What We Do (D)';
    }
    public function get_icon() {
        return 'eicon-nerd';
    }
    public function get_style_depends() {
        return [ 'owl-theme','owl-carousel' ];
    }
    public function get_script_depends() {
        return [ 'owl-carousel' ];
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section('what_we_do_settings',
            [
                'label' => esc_html__( 'What We Do Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'type',
			[
				'label' => __( 'Select Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'type_1'  => __( 'Type 1', 'digilab' ),
                    'type_2'  => __( 'Type 2', 'digilab' ),
                    'type_3'  => __( 'Type 3', 'digilab' ),
                ],
                'default' => 'type_1'
			]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'icon_color',
			[
				'label' => __( 'Icon Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
					'{{WRAPPER}} .icon' => 'color: {{VALUE}}',
				],
			]
        );
        
        $repeater->add_control( 'icon_bg_color',
			[
				'label' => __( 'Icon Background Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
			]
		);

        $repeater->add_control( 'icon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid'
                ]
            ]
        );

		$repeater->add_control( 'title', [
				'label' => __( 'Title', 'digilab' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Social Media Marketing' , 'digilab' ),
				'label_block' => true,
			]
		);

		$repeater->add_control( 'content', [
				'label' => __( 'Content', 'digilab' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Except had sex limits county enough the figure former add. Do sang my he next mr soon. It merely waited do unable.' , 'digilab' ),
				'label_block' => true,
			]
        );
        
        $repeater->add_control( 'button_text', [
				'label' => __( 'Button Text', 'digilab' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Read More' , 'digilab' ),
				'label_block' => true,
			]
        );

        $repeater->add_control( 'button_link', [
            'label' => __( 'Button Link', 'digilab' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( '#' , 'digilab' ),
            'label_block' => true,
            ]
        );
            
        $this->add_control(
			'list',
			[
				'label' => __( 'Repeater List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => __( 'Social Media Marketing', 'digilab' ),
						'content' => __( 'Except had sex limits county enough the figure former add. Do sang my he next mr soon. It merely waited do unable.', 'digilab' ),
					],
					[
						'title' => __( 'Keyward Research', 'digilab' ),
						'content' => __( 'Except had sex limits county enough the figure former add. Do sang my he next mr soon. It merely waited do unable.', 'digilab' ),
                    ],
                    [
						'title' => __( 'Content Marketing', 'digilab' ),
						'content' => __( 'Except had sex limits county enough the figure former add. Do sang my he next mr soon. It merely waited do unable.', 'digilab' ),
                    ],
                    [
						'title' => __( 'PPC Advertising', 'digilab' ),
						'content' => __( 'Except had sex limits county enough the figure former add. Do sang my he next mr soon. It merely waited do unable.', 'digilab' ),
                    ],
                    [
						'title' => __( 'Competitor Research', 'digilab' ),
						'content' => __( 'Except had sex limits county enough the figure former add. Do sang my he next mr soon. It merely waited do unable.', 'digilab' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->end_controls_section();

        /** Slider Owl Settings ***/

        $this->start_controls_section( 'slider_settings_section',
            [
                'label' => esc_html__( 'Slider Options', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'items_md',
            [
                'label' => esc_html__( 'Per View ( Desktop )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 3
            ]
        );
        $this->add_control( 'items_sm',
            [
                'label' => esc_html__( 'Per View ( Tablet )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 2
            ]
        );
        $this->add_control( 'items_xs',
            [
                'label' => esc_html__( 'Per View  ( Mobile )', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 10,
                'step' => 1,
                'default' => 1
            ]
        );
        $this->add_control( 'timeout',
            [
                'label' => esc_html__( 'Autoplay Delay', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'speed',
            [
                'label' => esc_html__( 'Speed', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 5000,
                'step' => 100,
                'default' => 3000,
                'separator' => 'before',
            ]
        );
        $this->add_control( 'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control( 'loop',
            [
                'label' => esc_html__( 'Loop', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control( 'nav',
            [
                'label' => esc_html__( 'Navs', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => ['type' => 'type_1']
            ]
        );
        $this->add_control( 'dots',
            [
                'label' => esc_html__( 'Dots', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => ['type' => 'type_2']
            ]
        );
        $this->add_control( 'margin',
            [
                'label' => esc_html__( 'Space Between Items', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => '',
            ]
        );
        $this->end_controls_section();
        
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $services_area = ($settings['type'] == 'type_3') ? 'services-area' : 'services-area carousel-shadow';

        $animate = \Elementor\Plugin::$instance->editor->is_edit_mode() ? '' : 'wow fadeInUp';
        
        if($settings['type'] == 'type_1') {
            $services_items = 'services-items '.$animate.' services-carousel owl-carousel owl-theme digilab-carousel';
        }else if($settings['type'] == 'type_2') {
            $services_items = 'services-items '.$animate.' services-stage-carousel owl-carousel owl-theme text-center digilab-carousel';
        }else {
            $services_items = 'services-items text-center';
        }

        $item_div = ($settings['type'] == 'type_3') ? '<div class="item '.$animate.' " data-wow-delay="500ms">' : '<div class="item">';

        $responsive = '"responsive":{"0":{"items":'.$settings['items_xs'].'},"768":{"items":'.$settings['items_sm'].'},"1024":{"items":'.$settings['items_md'].'}}';
        $data[] = $settings['speed'] ? '"speed": '.$settings['speed'] : '"speed":3000';
        $data[] = 'yes' == $settings['loop'] ? '"loop": true' : '"loop": false';
        $data[] = 'yes' == $settings['nav'] ? '"nav": true' : '"nav": false';
        $data[] = $settings['type'] == 'type_2' && 'yes' == $settings['dots'] ? '"dots": true' : '"dots": false';
        $data[] = 'yes' == $settings['autoplay'] ? '"autoplay": true' : '"autoplay": false';
        $data[] = $settings['timeout'] ? '"autoplayTimeout": '.$settings['timeout'] : '"autoplayTimeout": 5000';
        $data[] = $settings['margin'] ? '"margin": '.$settings['margin'] : '"margin": 30';
        'yes' == $settings['nav'] ? $data[] = '"navText": ["<i class=\"fa fa-angle-left\"></i>", "<i class=\"fa fa-angle-right\"></i>"]' : NULL;
        $data[] = $responsive;

    
        echo '<div class="'.esc_attr( $services_area ).'">';
            
            if( $settings['type'] == 'type_2' ) {
                echo '<div class="container-lg">';
            }
                                                    
                echo '<div class="'.esc_attr( $services_items ).'" data-owl-options=\'{'.implode( ', ', $data ).'}\'>';

                    if( $settings['type'] == 'type_3' ) {
                        echo '<div class="row">';
                    }
                        
                        if ( $settings['list'] ) {
                            foreach (  $settings['list'] as $item ) {
                                if( $settings['type'] == 'type_3' ) {
                                    echo '<div class="single-item col-lg-4 col-md-6">';
                                }
                                    echo $item_div;
                                        if ( ! empty($item['icon']['value']) ) {
                                            echo '<div class="icon" ' . ( (!empty($item['icon_bg_color'])) ? 'style="background: ' . $item["icon_bg_color"] . '">' : '>');
                                                Icons_Manager::render_icon( $item['icon'], [ 'aria-hidden' => 'true' ] );
                                            echo '</div>';
                                        }

                                        echo '<div class="info">';
                                            echo '<h4> <a href="'.$item['button_link'].'">'.esc_html( $item['title'] ).'</a> </h4>';
                                            echo '<p> '.esc_html( $item['content'] ).' </p>';
                                            echo '<a href="'.$item['button_link'].'"><i class="fas fa-arrow-right"></i> '.esc_html( $item['button_text'] ).' </a>';
                                        echo "</div>";
                                    echo '</div>';
                                if( $settings['type'] == 'type_3' ) {
                                    echo '</div>';
                                }
                            }
                        }

                    if( $settings['type'] == 'type_3' ) {
                        echo '</div>';
                    }

                echo '</div>';
            
            if( $settings['type'] == 'type_2' ) {
                echo '</div>';                
            }
                
        echo '</div>';
    }
}