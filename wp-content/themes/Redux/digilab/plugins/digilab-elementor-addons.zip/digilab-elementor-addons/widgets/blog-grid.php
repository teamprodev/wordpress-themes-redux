<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Blog_Grid extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-blog-grid';
    }
    public function get_title() {
        return 'Blog Grid (D)';
    }
    public function get_icon() {
        return 'eicon-gallery-grid';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'tf_post_general',
            [
                'label' => esc_html__( 'General', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'column',
            [
                'label' => esc_html__( 'Column', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => '4',
                'options' => [
                    '' => esc_html__( 'Select Column', 'digilab' ),
                    '3' => esc_html__( '4 Column', 'digilab' ),
                    '4' => esc_html__( '3 Column', 'digilab' ),
                    '6' => esc_html__( '2 Column', 'digilab' ),
                    '12' => esc_html__( '1 Column', 'digilab' )
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'separator' => 'none',
            ]
        );

        $this->add_control( 'pagination',
            [
                'label' => esc_html__( 'Pagination', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'separator' => 'before'
            ]
        );

        $this->add_control( 'pag_prev',
            [
                'label' => esc_html__( 'Pagination Prev Text', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'PREV',
                'condition' => ['pagination' => 'yes']
            ]
        );

        $this->add_control( 'pag_next',
            [
                'label' => esc_html__( 'Pagination Next Text', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'NEXT',
                'condition' => ['pagination' => 'yes']
            ]
        );

        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/
        
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'tf_post_query',
            [
                'label' => esc_html__( 'Query', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'author_filter_heading',
            [
                'label' => esc_html__( 'Author Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control( 'author_filter',
            [
                'label' => esc_html__( 'Author', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_users(),
                'description' => 'Select Author(s)'
            ]
        );

        $this->add_control( 'author_exclude_filter',
            [
                'label' => esc_html__( 'Exclude Author', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_users(),
                'description' => 'Select Author(s) to Exclude',
                'separator' => 'after'
            ]
        );

        $this->add_control( 'category_filter_heading',
            [
                'label' => esc_html__( 'Category Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_control( 'category_filter',
            [
                'label' => esc_html__( 'Category', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_categories(),
                'description' => 'Select Category(s)'
            ]
        );

        $this->add_control( 'category_exclude_filter',
            [
                'label' => esc_html__( 'Exclude Category', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_categories(),
                'description' => 'Select Category(s) to Exclude',
                'separator' => 'after'
            ]
        );

        $this->add_control( 'tag_filter_heading',
            [
                'label' => esc_html__( 'Tag Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_control( 'tag_filter',
            [
                'label' => esc_html__( 'Tag', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_tags(),
                'description' => 'Select Tag(s)'
            ]
        );

        $this->add_control( 'tag_exclude_filter',
            [
                'label' => esc_html__( 'Exclude Tag', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_tags(),
                'description' => 'Select Tag(s) to Exclude',
                'separator' => 'after'
            ]
        );

        $this->add_control( 'post_filter_heading',
            [
                'label' => esc_html__( 'Post Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_control( 'post_filter',
            [
                'label' => esc_html__( 'Specific Post(s)', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_posts(),
                'description' => 'Select Specific Post(s)'
            ]
        );

        $this->add_control( 'post_exclude_filter',
            [
                'label' => esc_html__( 'Exclude Post', 'digilab' ),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->digilab_get_posts(),
                'description' => 'Select Post(s) to Exclude',
                'separator' => 'after'
            ]
        );

        $this->add_control( 'post_other_heading',
            [
                'label' => esc_html__( 'Other Filter', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );

        $this->add_control('post_per_page',
            [
                'label' => esc_html__( 'Posts Per Page', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 1000,
                'default' => 6
            ]
        );

        $this->add_control('offset',
            [
                'label' => esc_html__( 'Offset', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1000
            ]
        );

        $this->add_control( 'order',
            [
                'label' => esc_html__( 'Select Order', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => 'Ascending',
                    'DESC' => 'Descending'
                ],
                'default' => 'ASC'
            ]
        );
        
        $this->add_control( 'orderby',
            [
                'label' => esc_html__( 'Order By', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => 'None',
                    'ID' => 'Post ID',
                    'author' => 'Author',
                    'title' => 'Title',
                    'name' => 'Slug',
                    'date' => 'Date',
                    'modified' => 'Last Modified Date',
                    'parent' => 'Post Parent ID',
                    'rand' => 'Random',
                    'comment_count' => 'Number of Comments',
                ],
                'default' => 'none'
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'digilab_post_options',
            [
                'label' => esc_html__( 'Post Options', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'hidetitle',
            [
                'label' => esc_html__( 'Hide Title', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'hidemeta',
            [
                'label' => esc_html__( 'Hide Meta', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'before_author',
            [
                'label' => esc_html__( 'Before Author', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'By'
            ]
        );
        $this->add_control( 'hideexcerpt',
            [
                'label' => esc_html__( 'Hide Excerpt', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'
            ]
        );
        $this->add_control( 'excerpt_limit',
            [
                'label' => esc_html__( 'Excerpt Word Limit', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'default' => 20
            ]
        );
        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/


        $this->start_controls_section( 'post_box_style_section',
            [
                'label'=> esc_html__( 'Box Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_background( 'post_box_typo','{{WRAPPER}} .blog-area .blog-items' );
        $this->digilab_style_padding( 'post_box_padding','{{WRAPPER}} .blog-area .blog-items .title-blog' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_title_style_section',
            [
                'label'=> esc_html__( 'Title Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_title_typo','{{WRAPPER}} .blog-area .blog-items .title-blog' );
        $this->digilab_style_color( 'post_title_color','{{WRAPPER}} .blog-area .blog-items .title-blog' );
        $this->digilab_style_padding( 'post_title_padding','{{WRAPPER}} .blog-area .blog-items .title-blog' );
        $this->digilab_style_margin( 'post_title_margin','{{WRAPPER}} .blog-area .blog-items .title-blog' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_text_style_section',
            [
                'label'=> esc_html__( 'Excerpt Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_text_typo','{{WRAPPER}} .desc-blog' );
        $this->digilab_style_color( 'post_text_color','{{WRAPPER}} .desc-blog' );
        $this->digilab_style_padding( 'post_text_padding','{{WRAPPER}} .desc-blog' );
        $this->digilab_style_margin( 'post_text_margin','{{WRAPPER}} .desc-blog' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_meta_style_section',
            [
                'label'=> esc_html__( 'Author Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_meta_typo','{{WRAPPER}} .blog-area .blog-items .meta .author a' );
        $this->digilab_style_color( 'post_meta_color','{{WRAPPER}} .blog-area .blog-items .meta .author a' );
        $this->digilab_style_padding( 'post_meta_padding','{{WRAPPER}} .blog-area .blog-items .meta .author a' );
        $this->digilab_style_margin( 'post_meta_margin','{{WRAPPER}} .blog-area .blog-items .meta .author a' );
        $this->end_controls_section();

        $this->start_controls_section( 'post_tags_style_section',
            [
                'label'=> esc_html__( 'Date Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_STYLE
            ]
        );
        $this->digilab_style_typo( 'post_tags_typo','{{WRAPPER}} .blog-area .blog-items .meta .date' );
        $this->digilab_style_color( 'post_tags_color','{{WRAPPER}} .blog-area .blog-items .meta .date' );
        $this->digilab_style_padding( 'post_tags_padding','{{WRAPPER}} .blog-area .blog-items .meta .date' );
        $this->digilab_style_margin( 'post_tags_margin','{{WRAPPER}} .blog-area .blog-items .meta .date' );
        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
        $args = array(
            'post_type'        => 'post',
            'author__in'       => $settings['author_filter'],
            'author__not_in'   => $settings['author_exclude_filter'],
            'category__in'     => $settings['category_filter'],
            'category__not_in' => $settings['category_exclude_filter'],
            'tag__in'          => $settings['tag_filter'],
            'tag__not_in'      => $settings['tag_exclude_filter'],
            'post__in'         => $settings['post_filter'],
            'post__not_in'     => $settings['post_exclude_filter'],
            'posts_per_page'   => $settings['post_per_page'],
            'offset'           => $settings['offset'],
            'order'            => $settings['order'],
            'orderby'          => $settings['orderby'],
            'paged'            => $paged 
        );

        $the_query = new \WP_Query( $args );

        if( $the_query->have_posts() ) {
            echo '<div class="blog-area bottom-less">';
                echo '<div class="container-off">';
                    echo '<div class="blog-items content-less">';
                        echo '<div class="row">';
                            while ($the_query->have_posts()) {
                                $the_query->the_post();
                                    echo '<div class="single-item col-lg-'.$settings['column'].'">';
                                        echo '<div class="item wow fadeInUp" data-wow-delay="600ms">';

                                            if( has_post_thumbnail() ) {
                                                echo '<div class="thumb">';
                                                    $image_id  = get_post_thumbnail_id();
                                                    $id        = get_the_ID();
                                                    $imagealt  = esc_attr( get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
                                                    $imagealt  = $imagealt ? $imagealt : basename ( get_attached_file( $image_id ) );
                                                    $image_url = Group_Control_Image_Size::get_attachment_image_src( $image_id, 'thumbnail', $settings );

                                                    if ( 'custom' == $settings['thumbnail_size'] ) {

                                                        $width  = $settings['thumbnail_custom_dimension']['width'];
                                                        $width  = $width ? ' width="'.$width.'"' : '';
                                                        $height = $settings['thumbnail_custom_dimension']['height'];
                                                        $height = $height ? ' height="'.$height.'"' : '';
                                                        $thumb  = '<img src="'.esc_url( $image_url ).'"'.$width.$height.' alt="'.$imagealt.'">';

                                                    } else {

                                                        $thumb = get_the_post_thumbnail( $id, $settings['thumbnail_size'], array( 'class' => 'img-blog' ) );

                                                    }
                                                    
                                                    echo '<div class="overlay">';
                                                        echo '<a href="'.get_permalink().'">'.$thumb.'</a>';
                                                    echo '</div>';
                                                echo '</div>';                                        
                                            }

                                            echo '<div class="info">';
                                                
                                                digilab_blog_post_tags();

                                                if ( 'yes' != $settings[ 'hidemeta' ] ) {
                                                    $by = '' != $settings[ 'before_author' ] ? $settings[ 'before_author' ] : '';
                                                    echo '<div class="meta">';
                                                        $post_author = get_author_posts_url( get_the_author_meta( 'ID' ) );
                                                        echo '<ul>';
                                                            echo '<li><i class="fas fa-calendar-alt"></i> '.get_the_date().' </li>';
                                                            echo '<li>'.$by.' <a href="'.$post_author.'">'.get_the_author().'</a></li>';                                                        
                                                        echo '</ul>';
                                                    echo '</div>';
                                                }
                                                
                                                if ( 'yes' != $settings[ 'hidetitle' ] ) {
                                                    echo '<h4 class="title-blog"><a href="'.get_permalink().'">'.get_the_title().'</a></h4>';
                                                }

                                                if ( 'yes' != $settings[ 'hideexcerpt' ] ) {
                                                    if ( has_excerpt() ){
                                                        echo '<p>'.wp_trim_words( get_the_excerpt(), $settings['excerpt_limit'] ).'</p>';
                                                    } else {
                                                        echo '<p>'.wp_trim_words( trim( strip_tags( get_the_content() ) ), $settings['excerpt_limit'] ).'</p>';
                                                    }
                                                }    
                                                
                                                digilab_blog_post_button();
                                                 
                                            echo '</div>';
                                        echo '</div>';
                                    echo '</div>';
                                    }
                                    wp_reset_postdata();                            
                        echo '</div>';

                        if ( $settings['pagination'] == 'yes' ) {
                            echo '<div class="row d-flex justify-content-center align-center justify-center tf-posts-pagination mt-30">';
                                $total_pages = $the_query->max_num_pages;
                                $big = 999999999;
                                if ( $total_pages > 1) {
                                    echo paginate_links(array(
                                        'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                        'format'    => '?paged=%#%',
                                        'current'   => max(1, $paged),
                                        'total'     => $total_pages,
                                        'type'      => '',
                                        'prev_text' => $settings['pag_prev'] ? esc_html( $settings['pag_prev'] ) : 'Prev',
                                        'next_text' => $settings['pag_next'] ? esc_html( $settings['pag_next'] ) : '<i class="tf-pagination-icon fa fa-angle-right"></i>',
                                        'before_page_number' => '<span class="tf-page-link">',
                                        'after_page_number' => '</span>'
                                    ));
                                }
                            echo '</div>';
                        }

                    echo '</div>';
                echo '</div>';
            echo '</div>';
        } else {
            echo '<p class="text">' . esc_html__( 'No post found!', 'digilab' ) . '</p>';
        }
    }
}
