<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Page_Hero extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-page-hero';
    }
    public function get_title() {
        return 'Post Page Hero (D)';
    }
    public function get_icon() {
        return 'eicon-columns';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {
        /*****   START CONTROLS SECTION   ******/
        $this->start_controls_section( 'digilab_page_hero_settings',
            [
                'label'=> esc_html__( 'General', 'digilab' ),
                'tab'=> Controls_Manager::TAB_CONTENT
            ]
        );

        $this->add_control( 'title_type',
            [
                'label' => esc_html__( 'Title Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => 'page',
                'options' => [
                    'page' => esc_html__( 'Page Title', 'digilab' ),
                    'custom' => esc_html__( 'Custom Text', 'digilab' )
                ]
            ]
        );

        $this->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => get_the_title(),
                'label_block' => true,
                'condition' => [ 'title_type' => 'custom' ]
            ]
        );

        $this->add_control( 'desc',
            [
                'label' => esc_html__( 'Page Description', 'digilab' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'We believe that every <b>project</b> existing in <b>digital world</b> is a result of an <b>idea</b> and every idea has a cause.',
                'label_block' => true
            ]
        );

        $this->add_responsive_control( 'desc_width',
            [
                'label' => esc_html__( 'Description Max Width', 'digilab' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 10,
                'max' => 2000,
                'step' => 1,
                'default' => 45,
                'selectors' => [ '{{WRAPPER}} .head-description' => 'max-width:{{SIZE}}rem;' ]
            ]
        );

        $this->add_control( 'hide_bread',
            [
                'label' => esc_html__( 'Hide Breadcrumbs', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'separator' => 'before'
            ]
        );

        $this->add_responsive_control( 'alignment',
            [
                'label' => esc_html__( 'Alignment', 'digilab' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'digilab' ),
                        'icon' => 'fa fa-align-left'
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'digilab' ),
                        'icon' => 'fa fa-align-center'
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'digilab' ),
                        'icon' => 'fa fa-align-right'
                    ]
                ],
                'toggle' => true,
                'default' => 'center',
                'separator' => 'before'
            ]
        );

        $this->end_controls_section();
        /*****   END CONTROLS SECTION   ******/

        
        $this->start_controls_section( 'page_hero_style',
            [
                'label' => esc_html__( 'Style', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT
            ]
        );
        $this->add_control( 'page_hero_bg_heading',
            [
                'label' => esc_html__( 'Background', 'digilab' ),
                'type' => Controls_Manager::HEADING
            ]
        );
        $this->add_control( 'hero_bg_type',
            [
                'label' => esc_html__( 'Background Image Type', 'digilab' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => 'true',
                'default' => 'def',
                'options' => [
                    'def' => esc_html__( 'Default Image', 'digilab' ),
                    'custom' => esc_html__( 'Custom', 'digilab' )
                ]
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'page_hero_bg',
				'label' => esc_html__( 'Background', 'digilab' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .fixed-bg',
				'condition' => ['hero_bg_type' => 'custom']
			]
		);
        $this->digilab_style_padding( 'page_hero_padding','{{WRAPPER}} .header-wrap' );

        $this->add_control( 'page_hero_title_heading',
            [
                'label' => esc_html__( 'TITLE', 'elementories' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->digilab_style_typo( 'page_hero_title_typo','{{WRAPPER}} .head-title' );
        $this->digilab_style_color( 'page_hero_title_color','{{WRAPPER}} .head-title' );
        $this->digilab_style_margin( 'page_hero_title_margin','{{WRAPPER}} .head-title' );

        $this->add_control( 'page_hero_desc_heading',
            [
                'label' => esc_html__( 'DESCRIPTION', 'elementories' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->digilab_style_typo( 'page_hero_desc_typo','{{WRAPPER}} .head-description' );
        $this->digilab_style_color( 'page_hero_desc_color','{{WRAPPER}} .head-description' );
        $this->add_control( 'page_hero_desc_bold_color',
            [
                'label' => esc_html__( 'Strong Text Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .head-description b, {{WRAPPER}} .head-description strong' => 'color:{{VALUE}};' ]
            ]
        );

        $this->digilab_style_margin( 'page_hero_desc_margin','{{WRAPPER}} .head-description' );

        $this->add_control( 'page_hero_bread_heading',
            [
                'label' => esc_html__( 'BREADCRUMBS', 'elementories' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before'
            ]
        );

        $this->digilab_style_typo( 'page_hero_bread_typo','{{WRAPPER}} .breadcrumbs' );
        $this->digilab_style_color( 'page_hero_bread_color','{{WRAPPER}} .breadcrumbs' );
        $this->add_control( 'page_hero_bread_link_color',
            [
                'label' => esc_html__( 'Link Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .breadcrumbs a' => 'color:{{VALUE}};' ]
            ]
        );

        $this->add_control( 'page_hero_bread_sep_color',
            [
                'label' => esc_html__( 'Separator Color', 'digilab' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [ '{{WRAPPER}} .breadcrumb_link_seperator' => 'color:{{VALUE}};' ]
            ]
        );
        
        $this->digilab_style_margin( 'page_hero_bread_margin','{{WRAPPER}} .breadcrumbs' );

        $this->end_controls_section();
        
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        $elementid  = $this->get_id();
        $herobg = 'custom' != $settings[ 'hero_bg_type' ] ? ' style="background-image: url('.plugins_url( 'assets/front/img/bg-4.png', __DIR__ ).' );"' : '';
        echo '<div class="breadcrumb-area bg-gradient text-center">';            
            echo '<div class="fixed-bg"'.$herobg.'></div>';
            echo '<div class="header-wrap text-'.$settings[ 'alignment' ].'">';

                echo '<div class="container">';
                    echo '<div class="row">';
                        echo '<div class="col-lg-8 offset-lg-2">';
                            if ( 'custom' == $settings['title_type'] ) {
                                if ( $settings[ 'title' ] ) {
                                    echo '<h1 class="head-title">'.$settings[ 'title' ].'</h1>';
                                }
                            } else {
                                echo '<h1 class="head-title">'.get_the_title().'</h1>';
                            }
                            if ( $settings[ 'desc' ] ) {
                                echo '<p class="head-description">'.$settings[ 'desc' ].'</p>';
                            }
                            if ( $settings[ 'hide_bread' ] != 'yes' ) {
                                digilab_breadcrumbs();
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

            echo '</div>';
        echo '</div>';

    }
}
