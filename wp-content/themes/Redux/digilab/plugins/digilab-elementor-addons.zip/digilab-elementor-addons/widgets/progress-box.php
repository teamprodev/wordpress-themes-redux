<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Progress_Box extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-progress-box';
    }
    public function get_title() {
        return 'Progress Box (D)';
    }
    public function get_icon() {
        return 'eicon-skill-bar';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    public function get_script_depends() {
        return [ 'progress-bar' ];
    }
    // Registering Controls
    protected function _register_controls() {

        $this->start_controls_section( 'digilab_progress_box_settings',
            [
                'label'=> esc_html__( 'General Settings', 'digilab' ),
                'tab'=> Controls_Manager::TAB_CONTENT
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'digilab' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Search Engine Optimization',
                'separator' => 'before'
            ]
        );

        $repeater->add_control( 'percent',
			[
				'label' => __( 'Percent', 'digilab' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				]
			]
		);      

        $repeater->add_control( 'bar_bg_color',
			[
				'label' => __( 'Bar Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .progress-items .progress-box .progress .progress-bar' => 'background: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'progress',
			[
				'label' => __( 'Progress List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => __( 'Search Engine Optimization', 'digilab' ),
						'percent' => '50'
					]
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->end_controls_section();
        
    }

    protected function render() {
        $settings   = $this->get_settings_for_display();
        ?>

        <div class="progress-items">

            <?php
                foreach( $settings['progress'] as $bar ) { ?>
                    <div class="progress-box">
                        <h5><?php echo esc_html( $bar['title'] ); ?> <span class="float-right"><?php echo $bar['percent']['size']; ?>%</span></h5>
                        <div class="progress">
                            <div class="progress-bar" <?php echo ( (!empty($item['bar_bg_color'])) ? 'style="background: ' . $item["bar_bg_color"] . '"' : '')  ?> role="progressbar" data-width="<?php echo $bar['percent']['size']; ?>"></div>
                        </div>
                    </div>
                <?php
                }
            ?>

        </div>
        <?php
    }
}
