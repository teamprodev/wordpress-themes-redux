<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Our_Process_Area extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-our-process-area';
    }
    public function get_title() {
        return 'Our Process Area (D)';
    }
    public function get_icon() {
        return 'eicon-sidebar';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section('our_process_area_settings',
            [
                'label' => esc_html__( 'Our Process Area Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control( 'design_type',
			[
				'label' => __( 'Design Type', 'digilab' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'multiple' => true,
				'options' => [
					'list'  => __( 'List', 'digilab' ),
                    'row'  => __( 'Row', 'digilab' ),
                ],
                'default' => 'list'
			]
        );

        $this->add_control( 'title',
            [
                'label' => __( 'Title', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Research'
            ]
        ); 

        $this->add_control( 'icon_color',
            [
                'label' => __( 'Icon Color', 'digilab' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .process-box .icon i' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
                'condition' => [ 'design_type' => 'row' ],
                'default' => '#4154f1'
            ]
        );

        $this->add_control( 'icon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid'
                ],
                'condition' => [ 'design_type' => 'row' ]
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control( 'icon_color',
            [
                'label' => __( 'Icon Color', 'digilab' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'scheme' => [
                    'type' => \Elementor\Scheme_Color::get_type(),
                    'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .our-process-area .process-box .icon i' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
                'default' => '#4154f1'
            ]
        );

        $repeater->add_control( 'icon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid'
                ]
            ]
        );

        $repeater->add_control( 'title',
            [
                'label' => __( 'Title', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Research'
            ]
        );          

        $repeater->add_control( 'description',
            [
                'label' => __( 'Description', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'Welcome fat who window. Removing welcomed civility or hastened.'
            ]
        );
        
        $this->add_control(
			'process',
			[
				'label' => __( 'Process List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
                        'icon' => [ 'value' => 'fa fa-chart-line', 'library' => 'solid' ],
                        'title' => 'Research',
                        'description' => 'Welcome fat who window. Removing welcomed civility or hastened.'
					],
					[
                        'icon' => [ 'value' => 'fas fa-hdd', 'library' => 'solid' ],
                        'title' => 'Data Collection',
                        'description' => 'Welcome fat who window. Removing welcomed civility or hastened.'
                    ],
                    [
                        'icon' => [ 'value' => 'fa fa-bullseye', 'library' => 'solid' ],
                        'title' => 'Targeting',
                        'description' => 'Welcome fat who window. Removing welcomed civility or hastened.'
                    ],
                    [
                        'icon' => [ 'value' => 'fa fa-list-alt', 'library' => 'solid' ],
                        'title' => 'Result',
                        'description' => 'Welcome fat who window. Removing welcomed civility or hastened.'
					]
				],
                'title_field' => '{{{ title }}}',
                'condition' => [ 'design_type' => 'list' ]
			]
		);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if($settings['design_type'] == 'list') {
            echo '<div class="our-process-area bottom-less">';
                echo '<div class="container-off">';
                    echo '<div class="process-box text-center">';
                        echo '<div class="row">';
                            foreach( $settings['process'] as $process ) {
                                echo '<div class="single-item col-lg-3 col-md-6">';
                                    echo '<div class="item wow fadeInUp" data-wow-delay="500ms">';
                                        echo '<div class="icon" style="color: '.$process['icon_color'].'">';
                                            Icons_Manager::render_icon( $process['icon'], [ 'aria-hidden' => 'true' ] );
                                        echo '</div>';
                                        echo '<h4>'.$process['title'].'</h4>';
                                        echo '<p>';
                                            echo ''.$process['description'].'';
                                        echo '</p>';
                                    echo '</div>';
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        }else {
            echo '<div class="about-features-area about-area">';
                echo '<div class="process-box text-center">';
                    echo '<div class="item-grid">';
                        echo '<div class="item wow fadeInUp" data-wow-delay="500ms">';
                            echo '<div class="icon" style="color: '.$settings['icon_color'].'">';
                                Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );
                            echo '</div>';
                            echo '<h4>'.$settings['title'].'</h4>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        }        
    }
}
