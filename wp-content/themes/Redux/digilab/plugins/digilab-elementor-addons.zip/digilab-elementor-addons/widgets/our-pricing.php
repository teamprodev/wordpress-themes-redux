<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Our_Pricing extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-our-pricing';
    }
    public function get_title() {
        return 'Our Pricing (D)';
    }
    public function get_icon() {
        return 'eicon-basket-light';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section('our_pricing_settings',
            [
                'label' => esc_html__( 'Our Pricing Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );        

        $this->add_control( 'title',
            [
                'label' => __( 'Title', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Trial Version'
            ]
        );

        $this->add_control( 'price',
            [
                'label' => __( 'Price', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Free'
            ]
        );

        $this->add_control( 'currency',
            [
                'label' => __( 'Price Currency', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ''
            ]
        );

        $this->add_control( 'payment_type',
            [
                'label' => __( 'Payment Type', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ''
            ]
        );

        $this->add_control( 'is_active',
            [
                'label' => esc_html__( 'Is Active?', 'digilab' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no'                
            ]
		);

        $this->add_control( 'icon_color',
			[
				'label' => __( 'Icon Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
                'selectors' => [
					'{{WRAPPER}} .icon' => 'color: {{VALUE}}',
                ],
                'separator' => 'before'
			]
        );
        
        $this->add_control( 'icon_bg_color',
			[
				'label' => __( 'Icon Background Color', 'digilab' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
                ],
			]
		);

        $this->add_control( 'icon',
            [
                'label' => esc_html__( 'Icon', 'digilab' ),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'solid'
                ]
            ]
        );

        $this->add_control( 'button_text',
            [
                'label' => __( 'Button Text', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Try For Free'
            ]
        );

        $this->add_control( 'button_link',
            [
                'label' => __( 'Button Link', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#'
            ]
        );

        $this->add_control( 'button_class',
            [
                'label' => __( 'Button Custom Class', 'digilab' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ''
            ]
        );

        $this->add_control( 'description',
			[
				'label' => __( 'Descriptions', 'digilab' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '<li>12 Keywords Optimized  <i class="fas fa-check-circle"></i></li> <li>6 Top 10 Ranking  <i class="fas fa-check-circle"></i></li> <li>Web site Analysis  <i class="fas fa-times-circle"></i></li> <li>Keyword Research  <i class="fas fa-check-circle"></i></li> <li>Content Optimization  <i class="fas fa-check-circle"></i></li> <li>Data Controll  <i class="fas fa-times-circle"></i></li>', 'digilab' ),
				'placeholder' => __( 'Type your description here', 'digilab' ),
			]
		); 

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        echo '<div class="pricing-area">';
            echo '<div class="pricing-items wow fadeInUp text-center">';                 
                echo '<div class="single-item">';
                    echo ($settings['is_active'] === "yes") ? '<div class="pricing-item active">' : '<div class="pricing-item">';
                        echo '<ul>';
                            echo '<li class="pricing-header">';
                                echo '<h4>'.$settings['title'].'</h4>';
                            echo '</li>';

                            echo '<li class="price">';
                                echo '<h2><sup>'.$settings['currency'].'</sup>'.$settings['price'].'<sub>'.$settings['payment_type'].'</sub></h2>';
                            echo '</li>';

                            echo '<li class="icon">';
                                Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] );
                            echo '</li>';

                            echo $settings['description'];

                            echo '<li class="footer">';                                                
                                echo ($settings['is_active'] === "yes") ? '<a href="'.$settings['button_link'].'" class="btn circle btn-theme '.$settings['button_class'].' effect btn-sm">'.$settings['button_text'].'</a>' : '<a href="'.$settings['button_link'].'" class="btn circle btn-dark border btn-sm">'.$settings['button_text'].'</a>';
                            echo '</li>';
                        echo '</ul>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';        
    }
}
