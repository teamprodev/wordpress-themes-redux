<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Digilab_Process_Area extends Widget_Base {
    use Digilab_Helper;
    public function get_name() {
        return 'digilab-process-area';
    }
    public function get_title() {
        return 'Process Area (D)';
    }
    public function get_icon() {
        return 'eicon-editor-list-ol';
    }
    public function get_categories() {
        return [ 'digilab' ];
    }
    // Registering Controls
    protected function register_controls() {

        $this->start_controls_section('process_area_settings',
            [
                'label' => esc_html__( 'Process Area Settings', 'digilab' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();


		$repeater->add_control( 'list_title', [
				'label' => __( 'Title', 'digilab' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( '<strong>01.</strong> Research' , 'digilab' ),
				'label_block' => true,
			]
		);

		$repeater->add_control( 'list_content', [
				'label' => __( 'Content', 'digilab' ),
				'type' => Controls_Manager::TEXT,
				'default' => __( 'Welcome fat who window extent either formal. Removing welcomed civility or hastened is. Justice elderly but perhaps expense.' , 'digilab' ),
				'label_block' => true,
			]
        );
        
        $this->add_control(
			'list',
			[
				'label' => __( 'Repeater List', 'digilab' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( '<strong>01.</strong> Research', 'digilab' ),
						'list_content' => __( 'Welcome fat who window extent either formal. Removing welcomed civility or hastened is. Justice elderly but perhaps expense.', 'digilab' ),
                    ],
                    [
						'list_title' => __( '<strong>02.</strong> Data Collection', 'digilab' ),
						'list_content' => __( 'Welcome fat who window extent either formal. Removing welcomed civility or hastened is. Justice elderly but perhaps expense.', 'digilab' ),
                    ],
                    [
						'list_title' => __( '<strong>03.</strong> Targeting', 'digilab' ),
						'list_content' => __( 'Welcome fat who window extent either formal. Removing welcomed civility or hastened is. Justice elderly but perhaps expense.', 'digilab' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

        $this->end_controls_section();
        
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
            <div class="process-items">
                    <div class="info">
                        <div class="content">
                            <?php
                                if ( $settings['list'] ) {
                                    
                                    foreach (  $settings['list'] as $item ) {
                                        echo '<div class="item">';
                                            echo '<div class="icon">';
                                                echo '<i class="fas fa-angle-right"></i>';
                                            echo '</div>';

                                            echo '<h4>'.$item['list_title'].'</h4>';
                                            echo '<p>'.$item['list_content'].'</p>';
                                            
                                        echo '</div>';
                                    }
                                }
                            ?>
                        </div>
                </div>
            </div>
        <?php       
    }
}
