/*=================================*/

/* Section Parallax

/*=================================*/

!(function ($) {

    

    var NtParticlesHandler = function ($scope, $) {

        var target = $scope,

            sectionId = target.data("id"),

            settings = false,

            editMode = elementorFrontend.isEditMode();

    

        if (editMode) {

            settings = generateEditorSettings(sectionId);

        }

    

        if (!editMode || !settings) {

            return false;

        }

    

        if ( "none" != settings[1]) {

            target.addClass('digilab-particles');

            $('<div id="particles-js_' + sectionId + '" class="digilab-particles-effect"></div>').prependTo(target);

            generateParticles();

        }

    

        function generateEditorSettings(targetId) {

            var editorElements = null,

                sectionData = {},

                sectionMultiData = {},

                settings = [];

    

            if (!window.elementor.hasOwnProperty("elements")) {

                return false;

            }

    

            editorElements = window.elementor.elements;

    

            if (!editorElements.models) {

                return false;

            }

    

            $.each(editorElements.models, function(index, elem) {

    

                if (targetId == elem.id) {

    

                    sectionData = elem.attributes.settings.attributes;

                } else if ( elem.id == target.closest(".elementor-top-section").data("id") ) {

    

                    $.each(elem.attributes.elements.models, function(index, col) {

                        $.each(col.attributes.elements.models, function(index,subSec) {

                            sectionData = subSec.attributes.settings.attributes;

                        });

                    });

                }

            });

    

            if (!sectionData.hasOwnProperty("digilab_particles_type") || "none" == sectionData["digilab_particles_type"]) {

                return false;

            }

    

            settings.push(sectionData["digilab_particles_switcher"]);  // settings[0]

            settings.push(sectionData["digilab_particles_type"]);      // settings[1]

            settings.push(sectionData["digilab_particles_shape"]);     // settings[2]

            settings.push(sectionData["digilab_particles_number"]);    // settings[3]

            settings.push(sectionData["digilab_particles_color"]);     // settings[4]

            settings.push(sectionData["digilab_particles_opacity"]);   // settings[5]

            settings.push(sectionData["digilab_particles_size"]);      // settings[5]

    

            if (0 !== settings.length) {

                return settings;

            }

    

            return false;

        }

    

    

        function generateParticles() {

    

            var type     = settings[1] ? settings[1] : 'deafult';

            var shape    = settings[2] ? settings[2] : 'buble';

            var number   = settings[3] ? settings[3] : '';

            var color    = settings[4] ? settings[4] : '#fff';

            var opacity  = settings[5] ? settings[5] : '';

            var d_size   = settings[6] ? settings[6] : '';

            //var n_size   = settings[8] ? settings[8] : '';

            //var s_size   = settings[9] ? settings[9] : '';

            var snumber = number ? number : 6;

            var nbsides = shape == 'star' ? 5 : 6;

            var size    = d_size ? d_size : 100;

            setTimeout(function() {

    

                if ( type == 'bubble' ) {

                    snumber = number ? number : 6;

                    nbsides = shape == 'star' ? 5 : 6;

                    size    = d_size ? d_size : 100;

                    particlesJS("particles-js_" + sectionId, { "fps_limit": 0, "particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": color }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": nbsides }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": true, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": size, "random": false, "anim": { "enable": true, "speed": 10, "size_min": 40, "sync": false } }, "line_linked": { "enable": false, "distance": 200, "color": "#ffffff", "opacity": 1, "width": 2 }, "move": { "enable": true, "speed": 8, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": false, "mode": "grab" }, "onclick": { "enable": false, "mode": "push" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 400, "size": 40, "duration": 2, "opacity": 8, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else if( type == 'nasa' ) {

                    snumber = number ? number : 160;

                    size    = d_size ? d_size : 3;

                    particlesJS("particles-js_" + sectionId, { "fps_limit": 0, "particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": color }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": true, "anim": { "enable": true, "speed": 1, "opacity_min": 0, "sync": false } }, "size": { "value": size, "random": true, "anim": { "enable": false, "speed": 4, "size_min": 0.3, "sync": false } }, "line_linked": { "enable": false, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 }, "move": { "enable": true, "speed": 1, "direction": "none", "random": true, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 600 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "bubble" }, "onclick": { "enable": true, "mode": "repulse" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 250, "size": 0, "duration": 2, "opacity": 0, "speed": 3 }, "repulse": { "distance": 400, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else if( type == 'snow' ) {

                    snumber = number ? number : 400;

                    size    = d_size ? parseFloat(d_size) : 10;

                    particlesJS("particles-js_" + sectionId, { "fps_limit": 0, "particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": color }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": true, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": size, "random": true, "anim": { "enable": false, "speed": 40, "size_min": 0.1, "sync": false } }, "line_linked": { "enable": false, "distance": 500, "color": "#ffffff", "opacity": 0.4, "width": 2 }, "move": { "enable": true, "speed": 6, "direction": "bottom", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "bubble" }, "onclick": { "enable": true, "mode": "repulse" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 0.5 } }, "bubble": { "distance": 400, "size": 4, "duration": 0.3, "opacity": 1, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else if( type == 'default' ) {

                    snumber = number ? number : 80;

                    size    = d_size ? d_size : 3;

                    particlesJS("particles-js_" + sectionId, { "fps_limit": 0, "particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": color }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": false, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": size, "random": true, "anim": { "enable": false, "speed": 40, "size_min": 0.1, "sync": false } }, "line_linked": { "enable": true, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 }, "move": { "enable": true, "speed": 6, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "repulse" }, "onclick": { "enable": true, "mode": "push" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 400, "size": 40, "duration": 2, "opacity": 8, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else {

                    target.find('.digilab-particles-effect').remove();

                    target.removeClass('digilab-particles');

                }

            }, 500);

    

        }

    }



    // ntrParticles Preview function

    function ntrParticles() {

    

        $(".elementor-section[data-particles-settings]").each(function (i, el) {

            var myParticles = $(el);

            var myParticlesId = myParticles.attr('data-particles-id');

            var myElementTtype = myParticles.attr('data-element_type');

            if ( myElementTtype == 'section' ) {



                $('<div id="particles-js_' + myParticlesId + '" class="digilab-particles-effect"></div>').prependTo(myParticles);

                

                var settings = myParticles.data('particles-settings');

                console.log( typeof settings);

                var type     = settings.type;

                var color    = settings.color ? settings.color : '#fff';

                var opacity  = settings.opacity ? settings.opacity : 0.4;

                var shape    = settings.shape ? settings.shape : 'circle';

                var snumber = settings.number ? settings.number : 6;

                var nbsides = settings.shape == 'star' ? 5 : 6;

                var size    = settings.size ? settings.size : 100;

                //console.log(settings.type);

                if ( type == 'bubble' ) {

                    snumber = settings.number ? settings.number : 6;

                    nbsides = settings.shape == 'star' ? 5 : 6;

                    size = settings.size ? settings.size : 100;

                    particlesJS("particles-js_" + myParticlesId,{ "fps_limit": 0,"particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": color }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000" }, "polygon": { "nb_sides": nbsides }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": true, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": size, "random": false, "anim": { "enable": true, "speed": 10, "size_min": 40, "sync": false } }, "line_linked": { "enable": false, "distance": 200, "color": "#ffffff", "opacity": 1, "width": 2 }, "move": { "enable": true, "speed": 8, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": false, "mode": "grab" }, "onclick": { "enable": false, "mode": "push" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 400, "size": 40, "duration": 2, "opacity": 8, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else if( type == 'nasa' ) {

                    snumber = settings.number ? settings.number : 160;

                    size = settings.size ? settings.size : 3;

                    particlesJS("particles-js_" + myParticlesId, { "fps_limit": 0,"particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": color }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": true, "anim": { "enable": true, "speed": 1, "opacity_min": 0, "sync": false } }, "size": { "value": size, "random": true, "anim": { "enable": false, "speed": 4, "size_min": 0.3, "sync": false } }, "line_linked": { "enable": false, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 }, "move": { "enable": true, "speed": 1, "direction": "none", "random": true, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 600 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "bubble" }, "onclick": { "enable": true, "mode": "repulse" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 250, "size": 0, "duration": 2, "opacity": 0, "speed": 3 }, "repulse": { "distance": 400, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else if( type == 'snow' ) {

                    snumber = settings.number ? settings.number : 400;

                    size = settings.size ? settings.size : 10;

                    particlesJS("particles-js_" + myParticlesId, { "fps_limit": 0,"particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": "#fff" }, "shape": { "type": shape, "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": opacity, "random": true, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": size, "random": true, "anim": { "enable": false, "speed": 40, "size_min": 0.1, "sync": false } }, "line_linked": { "enable": false, "distance": 500, "color": "#ffffff", "opacity": 0.4, "width": 2 }, "move": { "enable": true, "speed": 6, "direction": "bottom", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "bubble" }, "onclick": { "enable": true, "mode": "repulse" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 0.5 } }, "bubble": { "distance": 400, "size": 4, "duration": 0.3, "opacity": 1, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else if( type == 'default' ) {

                    snumber = settings.number ? settings.number : 80;

                    size = settings.size ? settings.size : 3;

                    particlesJS("particles-js_" + myParticlesId, { "fps_limit": 0,"particles": { "number": { "value": snumber, "density": { "enable": true, "value_area": 800 } }, "color": { "value": "#ffffff" }, "shape": { "type": "circle", "stroke": { "width": 0, "color": "#000000" }, "polygon": { "nb_sides": 5 }, "image": { "src": "img/github.svg", "width": 100, "height": 100 } }, "opacity": { "value": 0.5, "random": false, "anim": { "enable": false, "speed": 1, "opacity_min": 0.1, "sync": false } }, "size": { "value": 3, "random": true, "anim": { "enable": false, "speed": 40, "size_min": 0.1, "sync": false } }, "line_linked": { "enable": true, "distance": 150, "color": "#ffffff", "opacity": 0.4, "width": 1 }, "move": { "enable": true, "speed": 6, "direction": "none", "random": false, "straight": false, "out_mode": "out", "bounce": false, "attract": { "enable": false, "rotateX": 600, "rotateY": 1200 } } }, "interactivity": { "detect_on": "canvas", "events": { "onhover": { "enable": true, "mode": "repulse" }, "onclick": { "enable": true, "mode": "push" }, "resize": true }, "modes": { "grab": { "distance": 400, "line_linked": { "opacity": 1 } }, "bubble": { "distance": 400, "size": 40, "duration": 2, "opacity": 8, "speed": 3 }, "repulse": { "distance": 200, "duration": 0.4 }, "push": { "particles_nb": 4 }, "remove": { "particles_nb": 2 } } }, "retina_detect": true });

                } else {

                    

                }

            }

    

        });

    

    }



    jQuery(window).on("elementor/frontend/init", function() {

        var editMode = elementorFrontend.isEditMode();

        if (editMode) {

            elementorFrontend.hooks.addAction('frontend/element_ready/global', NtParticlesHandler);

        } else {

            ntrParticles();

        }

    });



})(jQuery);

