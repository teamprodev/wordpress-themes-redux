/* NT Addons for Elementor v1.0 */

!(function ($) {

    /* digilabTestimonialsSlider */
    function digilabTestimonialsSlider( $scope, $ ) {
        $scope.find( '.section-testi' ).each( function () {
            var myTarget     = $( this ),
                mySlick      = myTarget.find( '.testi-boxes-slick' ),
                myData       = mySlick.data( 'digilab-slick' ),
                myperview    = myData.perview,
                mymdperview  = myData.mdperview,
                mysmperview  = myData.smperview,
                myxsperview  = myData.xsperview,
                myspeed      = myData.speed,
                myautoplay   = myData.autoplay,
                myloop       = myData.loop,
                mydots       = myData.dots;

            mySlick.slick({
                infinite       : myloop,
                slidesToShow   : myperview,
                slidesToScroll : 1,
                dots           : mydots,
                autoplay       : myautoplay,
                autoplaySpeed  : myspeed,
                arrows         : false,
                responsive     : [
                    {
                        breakpoint : 992,
                        settings   : {
                            slidesToShow   : mymdperview,
                            slidesToScroll : mymdperview
                        }
                    },
                    {
                        breakpoint : 768,
                        settings   : {
                            slidesToShow   : mysmperview,
                            slidesToScroll : mysmperview
                        }
                    },
                    {
                        breakpoint : 480,
                        settings   : {
                            slidesToShow   : myxsperview,
                            slidesToScroll : myxsperview
                        }
                    }
                ]
            });
        });
    }

    /* digilabBlogSlider */
    function digilabBlogSlider( $scope, $ ) {
        $scope.find( '.blog-boxes-slick' ).each( function () {
            var mySlick      = $( this ),
                myData       = mySlick.data( 'digilab-slick' ),
                myperview    = myData.perview,
                mymdperview  = myData.mdperview,
                mysmperview  = myData.smperview,
                myxsperview  = myData.xsperview,
                myspeed      = myData.speed,
                myautoplay   = myData.autoplay,
                myloop       = myData.loop,
                mydots       = myData.dots;

            mySlick.slick({
                infinite       : myloop,
                slidesToShow   : myperview,
                slidesToScroll : 1,
                dots           : mydots,
                autoplay       : myautoplay,
                autoplaySpeed  : myspeed,
                arrows         : false,
                responsive     : [
                    {
                        breakpoint : 992,
                        settings   : {
                            slidesToShow   : mymdperview,
                            slidesToScroll : mymdperview
                        }
                    },
                    {
                        breakpoint : 768,
                        settings   : {
                            slidesToShow   : mysmperview,
                            slidesToScroll : mysmperview
                        }
                    },
                    {
                        breakpoint : 480,
                        settings   : {
                            slidesToShow   : myxsperview,
                            slidesToScroll : myxsperview
                        }
                    }
                ]
            });
        });
    }

    /* digilabWorkSlider */
    function digilabWorkSlider( $scope, $ ) {
        $scope.find( '.work-boxes-slick' ).each( function () {
            var mySlick      = $( this ),
                myData       = mySlick.data( 'digilab-slick' ),
                myperview    = myData.perview,
                mymdperview  = myData.mdperview,
                mysmperview  = myData.smperview,
                myxsperview  = myData.xsperview,
                myspeed      = myData.speed,
                myautoplay   = myData.autoplay,
                myloop       = myData.loop,
                mydots       = myData.dots;

            mySlick.slick({
                infinite       : myloop,
                slidesToShow   : myperview,
                slidesToScroll : 1,
                dots           : mydots,
                autoplay       : false,
                autoplaySpeed  : myspeed,
                arrows         : false,
                responsive     : [
                    {
                        breakpoint : 992,
                        settings   : {
                            slidesToShow   : mymdperview,
                            slidesToScroll : mymdperview
                        }
                    },
                    {
                        breakpoint : 768,
                        settings   : {
                            slidesToShow   : mysmperview,
                            slidesToScroll : mysmperview
                        }
                    },
                    {
                        breakpoint : 480,
                        settings   : {
                            slidesToShow   : myxsperview,
                            slidesToScroll : myxsperview
                        }
                    }
                ]
            });
        });
    }

    /* digilabWorkSlider */
    function relatedSlider( $scope, $ ) {
        $scope.find( '.related-slider' ).each( function () {
            var mySlick      = $( this ),
                myData       = mySlick.data( 'related-settings' ),
                myperview    = myData.items;
                //mymdperview  = myData.mdperview,
                //mysmperview  = myData.smperview,
                //myxsperview  = myData.xsperview,
                //myspeed      = myData.speed,
                //myautoplay   = myData.autoplay,
                //myloop       = myData.loop,
                //mydots       = myData.dots;

                mySlick.slick({
                    infinite       : true,
                    slidesToShow   : myperview,
                    slidesToScroll : 1,
                    dots           : true,
                    autoplay       : true,
                    autoplaySpeed  : 2000,
                    arrows         : false,
                    responsive     : [
                        {
                            breakpoint : 1024,
                            settings   : {
                                slidesToShow   : 3,
                                slidesToScroll : 1
                            }
                        },
                        {
                            breakpoint : 992,
                            settings   : {
                                slidesToShow   : 2,
                                slidesToScroll : 2
                            }
                        },
                        {
                            breakpoint : 768,
                            settings   : {
                                slidesToShow   : 1,
                                slidesToScroll : 1
                            }
                        },
                        {
                            breakpoint : 480,
                            settings   : {
                                slidesToShow   : 1,
                                slidesToScroll : 1
                            }
                        }
                    ]
                });
        });
    }

    function digilabLightbox( $scope, $ ) {
        $scope.find( '[data-digilab-lightbox]' ).each(function () {
            var myLightboxes = $( this );
            if ( myLightboxes.length ) {
                myLightboxes.each( function( i, el ) {
                    var myLightbox = $(el);
                    var myData = myLightbox.data( 'digilabLightbox' );
                    var myOptions = {};
                    if ( !myData || !myData.type ) {
                        return true; // next iteration
                    }
                    if ( myData.type === 'gallery' ) {
                        if ( !myData.selector ) {
                            return true; // next iteration
                        }
                        myOptions = {
                            delegate: myData.selector,
                            type: 'image',
                            gallery: {
                                enabled: true
                            }
                        };
                    }
                    if ( myData.type === 'image' ) {
                        myOptions = {
                            type: 'image'
                        };
                    }
                    if ( myData.type === 'iframe' ) {
                        myOptions = {
                            type: 'iframe'
                        };
                    }
                    if ( myData.type === 'inline' ) {
                        myOptions = {
                            type: 'inline',
                        };
                    }
                    if ( myData.type === 'modal' ) {
                        myOptions = {
                            type: 'inline',
                            modal: false
                        };
                    }
                    if ( myData.type === 'ajax' ) {
                        myOptions = {
                            type: 'ajax',
                            overflowY: 'scroll'
                        };
                    }
                    myLightbox.magnificPopup( myOptions );
                });
            }
        });
    }

    function digilabPopupVideo( $scope, $ ) {
        $scope.find( 'a.popup-video' ).each(function () {
            var myPopup = $( this );
            myPopup.magnificPopup( {
                type: 'iframe'
            } );
        });
    }

    // digilabBackground2
    function digilabBackground($scope, $) {
        $scope.find( '[data-digilab-background]' ).each(function () {
            var myElements = $( '[data-digilab-background]' );
            if (myElements.length) {
                myElements.each(function (i, el) {
                    var myElement    = $(el);
                    var myBackground = myElement.data( 'digilabBackground' );
                    if (!myBackground) {
                        return true; // next iteration
                    }
                    myElement.css( {'background-image': 'url("'+ myBackground +'")'} );
                    myElement.removeAttr( 'data-digilab-background' );
                });
            }
        });
    }


   // digilabJarallax
    function digilabJarallax() {
        var myParallaxs     = $( '.digilab-parallax' );
        //var myParallaxVideo = $('[data-jarallax-video]');
        myParallaxs.each(function (i, el) {
            var myParallax  = $(el);
            var myData      = myParallax.data( 'digilabParallax' );
            if (!myData) {
                return true; // next iteration
            }

            myParallax.jarallax({
                type            : myData.type,
                speed           : myData.speed,
                imgSize         : myData.imgsize,
                imgSrc          : myData.imgsrc,
                disableParallax : myData.mobile ? /iPad|iPhone|iPod|Android/ : null,
                keepImg         : false,
            });

        });
    }

   // digilabJarallax
    function digilabImageJarallax($scope, $) {
        $scope.each(function () {

            var myElement = $(this);
            var myId      = myElement.data( 'id' );
            var myData    = myElement.data( 'image-parallax-settings' );

            if ( myElement.hasClass( 'digilab-image-parallax' ) && myData ) {

                var myParallax = myElement.find( 'img' ).addClass( 'parallax-image-'+myId );
                var image      = document.getElementsByClassName( 'parallax-image-'+myId );
                new simpleParallax(image, {
                    orientation: myData.orientation,
                    scale: myData.scale,
                    overflow: myData.overflow,
                    delay: myData.delay,
                    maxTransition: myData.maxtrans
                });
            }
        });
    }

    var parentBody = window.parent.document.getElementsByClassName( "elementor-editor-wp-page" );
    var parentBod = $(parentBody);


    function updatePageSettings(newValue) {
        var settings = false,
            editMode = elementorFrontend.isEditMode();
        if (!editMode ) {
            return false;
        }
        console.log( newValue );
        if ( editMode ) {
            
            var hide_header = elementor.settings.page.model.attributes.digilab_elementor_hide_page_header;
            var hide_footer = elementor.settings.page.model.attributes.digilab_elementor_hide_page_footer;

            if ( hide_header && 'yes' === hide_header ) {
                $( '.header.tf-header' ).hide();
            } else {
                $( '.header.tf-header' ).show();
            }
            if ( hide_footer && 'yes' === hide_footer ) {
                $( '.footer.has-style1' ).hide();
            } else {
                $( '.footer.has-style1' ).show();
            }
        }
    }


    var sectionSettings = function ($scope, $) {
        var target = $scope,
        sectionId  = target.data("id"),
        settings   = false,
        editMode   = elementorFrontend.isEditMode();

        if ( editMode ) {
            settings = generateEditorSettings( sectionId );
        }

        if ( !editMode || !settings ) {
            return false;
        }


        function generateEditorSettings( targetId ) {
            var editorElements  = null,
            sectionData         = {},
            sectionMultiData    = {},
            settings            = [];

            if (!window.elementor.hasOwnProperty( "elements" ) ) {
                return false;
            }

            editorElements = window.elementor.elements;

            if ( !editorElements.models ) {
                return false;
            }

            $.each( editorElements.models, function( index, elem ) {

                if ( targetId == elem.id ) {

                    var sectionGap = elem.attributes.settings.attributes.gap;
                    target.addClass( 'digilab-gap-'+sectionGap );

                } else if ( elem.id == target.closest( ".elementor-top-section" ).data( "id" ) ) {

                    $.each( elem.attributes.elements.models, function( index, col ) {
                        $.each( col.attributes.elements.models, function( index,subSec ) {
                            sectionGap = subSec.attributes.settings.attributes.gap;
                            if ( subSec ) {
                                target.addClass( 'digilab-gap-'+sectionGap );
                            }
                        });
                    });
                }
            });

            return false;
        }

    }

    /* digilabPortfolioIsotope */
    function digilabPortfolioIsotope( $scope, $ ) {
        $scope.find( '.portfolio:not(.editor)' ).each(function () {
            var myGallery = $( this );
            var myIsotope = myGallery.find(".gallery");
            var myFilters = myGallery.find(".filtering");
            if ( myIsotope ) {
                myIsotope.isotope({
                    itemSelector: '.items'
                });
                var $gallery = myIsotope.isotope();
                myFilters.on('click', 'span', function () {
                    var filterValue = $(this).attr('data-filter');
                    $gallery.isotope({ filter: filterValue });
                });
                myFilters.on('click', 'span', function () {
                    $(this).addClass('active').siblings().removeClass('active');
                });
            }
        });
    }

    function digilabOwlCarousel($scope, $) {
        $scope.find('.digilab-carousel').each(function () {            
            const options = JSON.parse(this.dataset.owlOptions);
            $(this).owlCarousel( options );
        });
    }


    jQuery(window).on('elementor/frontend/init', function () {

        if ( typeof elementor != "undefined" && typeof elementor.settings.page != "undefined") {

            elementor.settings.page.addChangeCallback( 'digilab_elementor_hide_page_header', updatePageSettings );
            elementor.settings.page.addChangeCallback( 'digilab_elementor_hide_page_footer', updatePageSettings );

        }

        // elementor default widgets
        elementorFrontend.hooks.addAction( 'frontend/element_ready/section', sectionSettings );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/section', digilabJarallax );        
        elementorFrontend.hooks.addAction( 'frontend/element_ready/image.default', digilabImageJarallax );

        // digilab custom widgets                
        elementorFrontend.hooks.addAction( 'frontend/element_ready/digilab-blog-slider.default', digilabBlogSlider );
        elementorFrontend.hooks.addAction( 'frontend/element_ready/digilab-works-carousel.default', digilabWorkSlider );        
        elementorFrontend.hooks.addAction( 'frontend/element_ready/digilab-post-data.default', relatedSlider );
        elementorFrontend.hooks.addAction('frontend/element_ready/digilab-what-we-do.default', digilabOwlCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/digilab-clients-area.default', digilabOwlCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/digilab-our-team.default', digilabOwlCarousel);
        elementorFrontend.hooks.addAction('frontend/element_ready/digilab-testimonials-area.default', digilabOwlCarousel);

    });

})(jQuery);
