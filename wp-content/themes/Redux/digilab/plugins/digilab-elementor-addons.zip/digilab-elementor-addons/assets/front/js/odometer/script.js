(function(window, document, $) {

    "use strict";

    function digilabOdometer() {
        var wow = new WOW({
            boxClass: 'odometer',
            animateClass: 'digilab-odometer',
            offset: 100,
            callback: function ( el ){
                var myOdometers = $(el),
                    myID = myOdometers.attr('id'),
                    myData = myOdometers.data('digilab-odometer'),
                    myTheme = myData.theme,
                    myNumber = myData.number,
                    myNumber2 = myData.number2,
                    myTimeout = myData.timeout,
                    myFormat = myData.format,
                    myOdometer = document.getElementById(myID),
                    od = new Odometer({
                      el: myOdometer,
                      value: myNumber,
                      format: myFormat,
                      theme: myTheme,
                      //animation: 'count'
                    });

                od.update(myNumber2);
            }
        });
        wow.init();
    }

    jQuery(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/digilab-odometer.default', digilabOdometer);
    });

})(window, document, jQuery);
